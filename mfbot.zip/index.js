import MadfutClient1, { ProfileProperty } from './madfutclient.js';
import { bot } from "./discord.js";
import db from "./db.js";
import config, { saveConfig } from "./config.js";
import { formatNum, normalize, sleep, getRandomInt, extractAmount } from "./util.js";
const cooldowns = new Map();
import { Constants } from 'eris';
import { once } from 'events';
let claimedUsers = {};
import { ObjectSet } from './util.js';
import { accounts } from './accounts.js';
function randomAccount() {
    return accounts[Math.floor(Math.random() * accounts.length)];
}
function getRandInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
}
let madfutclient = async () => {
    const madfutClient = new MadfutClient1(config.appCheckToken);
    while (!madfutClient.loggedIn) {
        await madfutClient.login(randomAccount().email).catch(async (err) => {
            madfutClient.logout();
        });
    }
    return madfutClient;
};
function getRandomIntMy(max) {
    return Math.floor(Math.random() * max);
}
function randomPlayer() {
  return players[Math.floor(Math.random() * players.length)];
}
function randomurl() {
    return players[Math.floor(Math.random() * players.length)];
}
function randomPacks() {
    const packs = [
        "silver_special",
        "bf_nine_special",
        "bf_five_special",
        "totw",
        "fatal_rare",
        "bf_93_special",
        "bf_95_special",
        "fatal_special",
        "double_special",
        "triple_special",
        "gold",
        "random",
        "gold_super",
        "rare",
        "bf_94_special",
        "bf_eight_special",
        "free",
        "silver_plus",
        "no_totw_special",
        "fatal_silver",
        "85_special",
        "bf_89_special",
        "bf_88_special",
        "bf_four_special",
        "bf_seven_special",
        "gold_mega",
        "special",
        "rainbow",
        "bf_six_special",
        "bf_92_special",
        "80+",
        "bf_86_special",
        "fatal_nonrare",
        "bf_91_special",
        "bf_87_special",
        "silver",
        "op_special",
        "bf_90_special",
        "fatal_rare_silver",
        "pp_sbc_real_madrid_icons",
        "pp_new_87_91",
        "pp_fut_champs",
        "pp_new_81_84",
        "pp_special",
        "pp_special_88_92",
        "pp_best_1",
        "pp_new_83_86",
        "pp_new_77_82",
        "pp_new_85_88",
        "pp_bad_1",
        "pp_totw",
        "pp_new_special",
        "pp_icons_86_92",
        "pp_mega",
        "pp_good_1",
        "pp_icon",
        "pp_special_83_86",
        "pp_special_81_84",
        "pp_special_85_88",
        "pp_special_86_89"
    ];
    return packs[Math.floor(Math.random() * packs.length)];
}
const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
process.on('unhandledRejection', async (error) => {
});
function generateString(length) {
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;

}
let packs1 = [
    {
        pack: "95_special",
        amount: 1
    },
    {
        pack: "rainbow",
        amount: 1
    },
    {
        pack: "random",
        amount: 1
    },
];
function getRandomInt1(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
bot.on("free-trades", async (interaction) => {
    const userId = interaction.member.id;
    const now = Date.now();
    const cooldownTime = 30 * 60 * 1000;

    if (cooldowns.has(userId)) {
        const lastSpinTime = cooldowns.get(userId);

        if (now - lastSpinTime < cooldownTime) {
            const remainingTime = cooldownTime - (now - lastSpinTime);
            const hours = Math.floor(remainingTime / 3600000);
            const minutes = Math.floor((remainingTime % 3600000) / 60000);

            interaction.createMessage({
                embeds: [
                    {
                        color: 0xFFD700,
                        description: `You still have a cooldown for ${hours} hours and ${minutes} minutes.`,
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                    },
                ],
            });
            return;
        }
    }

    const username = await db.getMadfutUserByDiscordUser(userId);
    const stResult = db.startTransaction(userId);
    
    if (!stResult.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    title: `${username} You cannot spin because ${stResult.error}.`,
                    description: "try ... /mf force-end-transaction-me",
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                },
            ],
        });
        return;
    }

    try {
        await interaction.acknowledge();
        const linked = await db.getMadfutUserByDiscordUser(userId);

        if (!linked) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFFD700,
                        description:
                            "There is no MADFUT account linked to your Discord account, so you cannot claim free trades. To link one, use `/mf link <username>`.",
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                    },
                ],
            });
            return;
        } else {
                const rewards = [
                    "1 BOT TRADE",
                ];
                const rewardsName = Math.floor(Math.random() * rewards.length);
    
    
    
                if (rewardsName === 0) await db.addBotTrades(userId, 1); // pay 80m coins

            const transactions = [];
            await Promise.all(transactions);
            interaction.createFollowup({
                embeds: [
                    {
                        title: "madfut24 | Free Trades",
                        color: 0xFFD700,
                        description: `You won **${rewards[rewardsName]}**! To Redeem Them Use /mf-redeem-bt`,
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                    }
                ]
            });            
        }

        cooldowns.set(userId, now);

        setTimeout(() => {
            cooldowns.delete(userId);
        }, cooldownTime);
    } finally {
        db.endTransaction(userId);
    }
});
async function botCodeListenerSwitcher() {
    const madfut = new MadfutClient(config.appCheckToken, getRandomInt(1000000));

    try {
        await madfut.login();
    } catch (error) {
        console.log(`Error logging in: ${error}`);
        return botCodeListenerSwitcher();
    }
    return madfut;
}
let botCodeTimeout = false;
let invitename2 = "madfut24";
async function botCodePacks(interaction, username, amount) {
    console.log(`sent ${username} ${amount} trades`);
    let ftRunning = "2";
    let times = amount;
    intervalfuncft();
    let count = 0;
    async function intervalfuncft() {
        let madfutClient;
        madfutClient = await madfutclient();
        for(let i = 0; i < times;){
            
            let tradeRef;
            if (ftRunning === "1") {
                return madfutClient.logout();
            }
            let traderName;
            try {
              //traderName = await madfutClient.returnUserInfo(username);
            } catch (error) {
                return null;
            }
            console.log(traderName);
            try {
                tradeRef = await madfutClient.inviteUser(username, invitename2);
                console.log(`${username} accepted invite.`);
            } catch  {
                if (++count > 4) return;
                console.log(`${username} rejected invite.`);
                continue;
            }
            try {
                await madfutClient.doTrade(tradeRef, async (profile)=>({
                        receiveCoins: false,
                        receiveCards: false,
                        receivePacks: false,
                        giveCards: [],
                        giveCoins: 10000000,
                        givePacks: packs
                    })
                );
                --times;
                console.log(`${username} ${times} trades left`);
                count > 0 && count--;
                //console.log(`Completed trade with ${userId}`);
                await madfutClient.logout();
                //console.log(`Completed trade with ${username}`);
                ftRunning = "1";
                setTimeout(()=>{
                    i++;
                    ftRunning = "2";
                    intervalfuncft();
                }, 4000);
            } catch (_err) {
                await madfutClient.logout();
                console.log(`Unlimited trade with ${username} failed: Player left`);
            }
        }
        madfutClient && madfutClient?.logout();
    }
}

async function botCodeCards(interaction, username, amount) {
    console.log(`sent ${username} ${amount} trades`);
    let ftRunning = "2";
    let times = amount;
    intervalfuncft();
    let count = 0;
    async function intervalfuncft() {
        let madfutClient;
        madfutClient = await madfutclient();
        for(let i = 0; i < times;){
            
            let tradeRef;
            if (ftRunning === "1") {
                return madfutClient.logout();
            }
            let traderName;
            try {
              //traderName = await madfutClient.returnUserInfo(username);
            } catch (error) {
                return null;
            }
            console.log(traderName);
            try {
                tradeRef = await madfutClient.inviteUser(username, invitename2);
                console.log(`${username} accepted invite.`);
            } catch  {
                if (++count > 4) return;
                console.log(`${username} rejected invite.`);
                continue;
            }
            try {
                await freetradev2(username, 1)
                --times;
                console.log(`${username} ${times} trades left`);
                count > 0 && count--;
                await madfutClient.logout();
                ftRunning = "1";
                setTimeout(()=>{
                    i++;
                    ftRunning = "2";
                    intervalfuncft();
                }, 4000);
            } catch (_err) {
                await madfutClient.logout();
                console.log(`Unlimited trade with ${username} failed: Player left`);
            }
        }
        madfutClient && madfutClient?.logout();
    }
}

async function addListener(interaction, codename, tradeType, timeoutMinutes, MSG) {
    let madfutClient = await botCodeListenerSwitcher();

    try {
        let userId = madfutClient.uid;
        console.log(`Starting Code: ${codename}`);
        await madfutClient.setBotCodeUsername(codename);
        console.log(`Started: ${codename}`);

        if (tradeType === "packs") {
            madfutClient.addInviteListener(async (uid, codename, timeoutMinutes, tradeType) => {
                console.log(`User invited ${codename}: ${uid}`);
                try {
                    await botCodePacks(interaction, uid, 5);
                } catch (error) {
                    console.log(`Error in makeTrade: ${error}`);
                }
            }, userId, codename);
        } else if (tradeType === "cards") {
            madfutClient.addInviteListener(async (uid, codename, timeoutMinutes, tradeType) => {
                console.log(`User invited ${codename}: ${uid}`);
                try {
                    await botCodeCards(interaction, uid, 5);
                } catch (error) {
                    console.log(`Error in makeTrade: ${error}`);
             
                }
            }, userId, codename);
        }
        setTimeout(async () => {
            console.log(`Timeout reached. Stopping listener for ${codename}`);
            botCodeTimeout = true;
            await madfutClient.logout();
        }, timeoutMinutes * 60 * 1000);
    } catch (err) {
        console.log(`We encountered an error with this account, switching.`);
        addListener(interaction, codename, tradeType);
    }
}

bot.on("code", async (interaction, codename, tradeType, duration)=>{
    if (duration > 15) {
        interaction.createMessage({
            embeds: [
                {
                    color: 10156042,
                    description: "Maximum duration is 15 minutes!"
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    if(tradeType === "packs") {
    if(codename.length > '12') {
 interaction.createMessage({
        embeds: [
            {
                color: 10156042,
                description: `12 is the max amount of characters the code name can be!`,
                  
            }
        ],
     flags: Constants.MessageFlags.EPHEMERAL,
    });
} else if(codename.length < "5") {
     interaction.createMessage({
        embeds: [
            {
                color: 10156042,
                description: `5 is the lowest amount of characters the code name can be!`,
                  
            }
        ],
         flags: Constants.MessageFlags.EPHEMERAL,
    });
} else {
    let msg = interaction.createMessage({
        embeds: [
            {
                title: "Success",
                color: 10156042,
                description: `Created Packs code: ${codename}\n`,  
            }
        ]
        
    });

    // Run indefinitely
    try {
        await addListener(interaction, codename, "packs", duration, msg);
    } catch (error) {
        console.log(`Error in code listener: ${error}`);
    }
}
    }
    if(tradeType === "wishlist"){
            if(codename.length > '12') {
 interaction.createMessage({
     embeds: [
            {
                color: 10156042,
                description: `12 is the max amount of characters the code name can be!`,
                 
            }
        ],
     flags: Constants.MessageFlags.EPHEMERAL,
    });
} else if(codename.length < "5") {
     interaction.createMessage({
        embeds: [
            {
                color: 10156042,
                description: `5 is the lowest amount of characters the code name can be!`,
               
            }
        ],
         flags: Constants.MessageFlags.EPHEMERAL,
    });
} else {
    let msg = interaction.createMessage({
        embeds: [
            {
                title: "Success",
                color: 10156042,
                description: `Created wishlist code: ${codename}\n`,  
            }
        ]
        
    });
    try {
        await addListener(interaction, codename, "cards", duration, msg);
    } catch (error) {
        console.log(`Error in code listener: ${error}`);
    }
}
    }
});
bot.on("buy", async (interaction) => {
    if (interaction.channel.id !== config.shopChannelId) {
        interaction.createMessage({
            content: `You can only use this command in <#${config.shopChannelId}> `,
                flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
}
    await interaction.acknowledge(); //pass number(64) to mark ephemeral
    const userId = interaction.member.id;

    //reject if not at least one command option was selected
    if (!interaction.data.options[0].options || !interaction.data.options[0].options.length) {
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFFD700,
                    title: `<:no:1126251054380613783> No option selected!`,
                    description: "You didn't select anything from the shop..",
                    thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                }
            ]
        });
        return;
    }

    //get amount of items
    let bottrades = 0;
    let packs = 0;
    for (const option of interaction.data.options[0].options) {
        if (option.name === 'bottrades') {
            bottrades = option.value;
        }
        else if (option.name === 'packs') {
            packs = option.value;
        }
    }

    const totalItemCost = (bottrades * 16000000);

    //check wallet balance
    const currentBalance = await db.getCoins(userId);
    if (!currentBalance || currentBalance < totalItemCost) {
    interaction.createMessage({
        embeds: [
            {
                color: 0xFFD700,
                title: `<:no:1126251054380613783> Not enough funds!`,
                description: "You don't have enough coins <:coins:1210897847923380254> to buy this item.",
                    thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
            }
        ]
    });
    return;
    }

    //withdraw funds from wallet and add items to database
    try {
        const transactions = [];
        transactions.push(db.addCoins(userId, (-1 * totalItemCost)));
        if (bottrades > 0) transactions.push(db.addBotTrades(userId, bottrades));
        if (packs > 0) transactions.push(db.addPacks(userId, "95_special", packs));
        await Promise.all(transactions);
    }
    catch (err) {
        console.log('error with transaction in shop command: ' + err);
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    title: `<:no:1126251054380613783> Transaction error!`,
                    description: "There was an error during the transaction.",
                    thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                }
            ]
        });
    }
    finally {
        db.endTransaction(userId);

        //reply
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    title: `<a:Verified:1101241810568884324> Purchase successful!`,
                    description: `**Successfully purchased ${bottrades} bottrades for mf coins**`,
                    thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                }
            ]
        });
    }

});
bot.on("sell", async (interaction) => {
    if (interaction.channel.id !== config.shopChannelId) {
        interaction.createMessage({
            content: `You can only use this command in <#${config.shopChannelId}> `,
                flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
}
    await interaction.acknowledge(); //pass number(64) to mark ephemeral
    const userId = interaction.member.id;

    //reject if not at least one command option was selected
    if (!interaction.data.options[0].options || !interaction.data.options[0].options.length) {
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFFD700,
                    title: `<:no:1126251054380613783> No option selected!`,
                    description: `**You didn't select anything from the shop..**`,
                    thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                }
            ]
        });
        return;
    }

    //get amount of items
    let bottrades = 0;
    let packs = 0;
    for (const option of interaction.data.options[0].options) {
        if (option.name === 'bottrades') {
            bottrades = option.value;
        }
        else if (option.name === 'packs') {
            packs = option.value;
        }
    }

    const totalItemCost = (bottrades * 5000000);

    //check wallet balance
    const currentBalance = await db.getBotTrades(userId);
    if (!currentBalance || currentBalance < bottrades) {
    interaction.createMessage({
        embeds: [
            {
                color: 0xFFD700,
                title: `<:no:1126251054380613783> You are too poor!`,
                description: `**You don't have enough bottrades <:bot:1210897888486359060> to sell.**`,
                    thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
            }
        ]
    });
    return;
    }

    //withdraw funds from wallet and add items to database
    try {
        const transactions = [];
        transactions.push(db.addCoins(userId, (totalItemCost)));
        if (bottrades > 0) transactions.push(db.removeBotTrades(userId, bottrades));
        if (packs > 0) transactions.push(db.addPacks(userId, "95_special", packs));
        await Promise.all(transactions);
    }
    catch (err) {
        console.log('error with transaction in shop command: ' + err);
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    title: `<:no:1126251054380613783> Transaction error!`,
                    description: "There was an error during the transaction.",
                    thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                }
            ]
        });
    }
    finally {
        db.endTransaction(userId);

        //reply
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    title: `<a:Verified:1101241810568884324> Sale successful!`,
                    description: `Successfully sold ${bottrades} bottrades for <:coins:1210897847923380254> mf coins`,
                    thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                }
            ]
        });
    }
});
bot.on("dailyspin", async (interaction) => {
    const userId = interaction.member.id;
    const now = Date.now();
    const cooldownTime = 24 * 60 * 60 * 1000;

    if (cooldowns.has(userId)) {
        const lastSpinTime = cooldowns.get(userId);

        if (now - lastSpinTime < cooldownTime) {
            const remainingTime = cooldownTime - (now - lastSpinTime);
            const hours = Math.floor(remainingTime / 3600000);
            const minutes = Math.floor((remainingTime % 3600000) / 60000);

            interaction.createMessage({
                embeds: [
                    {
                        color: 15158332,
                        description: `You still have a cooldown for ${hours} hours and ${minutes} minutes.`,
                    },
                ],
            });
            return;
        }
    }

    const username = await db.getMadfutUserByDiscordUser(userId);
    const stResult = db.startTransaction(userId);
    
    if (!stResult.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 15158332,
                    title: `${username} You cannot spin because ${stResult.error}.`,
                    description: "try ... /mf force-end-transaction-me",
                },
            ],
        });
        return;
    }

    try {
        await interaction.acknowledge();
        const linked = await db.getMadfutUserByDiscordUser(userId);

        if (!linked) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 15158332,
                        description:
                            "There is no MADFUT account linked to your Discord account, so you cannot use your Daily Spin. To link one, use `/mf link <username>`.",
                    },
                ],
            });
            return;
        } else {
                const rewards = [
                    "10 MILLION COINS",
                    "5 MILLION COINS",
                    "1 MILLION COINS",
                    "2 BOT TRADES",
                    "4 BOT TRADES",
                    "6 BOT TRADES"
                ];
                const rewardsName = Math.floor(Math.random() * rewards.length);
    
    
    
                if (rewardsName === 0) await db.addCoins(userId, 10000000); // pay 80m coins
                else if (rewardsName === 1) await db.addCoins(userId, 5000000); // pay 100m coins
                else if (rewardsName === 2) await db.addCoins(userId, 1000000); // pay 10m coins
                else if (rewardsName === 3) await db.addBotTrades(userId, 2); // pay 20 bot trades
                else if (rewardsName === 4) await db.addBotTrades(userId, 4); // pay 30 bot trades
                else if (rewardsName === 5) await db.addBotTrades(userId, 6); // pay 69 bot trades

            const transactions = [];
            await Promise.all(transactions);
            interaction.createFollowup({
                embeds: [
                    {
                        title: "madfut24 | Dailyspin",
                        color: 3319890,
                        description: `You won **${rewards[rewardsName]}**!`,
                        author: {
                            name: "Cooldown 24H",
                        },
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                    },
                ],
            });            
        }

        cooldowns.set(userId, now);

        setTimeout(() => {
            cooldowns.delete(userId);
        }, cooldownTime);
    } finally {
        db.endTransaction(userId);
    }
});
import fs from 'fs';

let Rtoken;

// Load Rtoken from file if it exists
try {
    const data = fs.readFileSync('rtoken.txt', 'utf8');
    Rtoken = data.trim();
} catch (err) {
    console.error('Error reading Rtoken from file:', err.message);
}
bot.on("token", async (interaction, tokenname,) => {
    if (!interaction.member?.roles.includes("1205263342722224128")) {
        interaction.createMessage({
            content: "brudda rly tried lmao.",
        });
        return;
    } else {
        Rtoken = tokenname;
        console.log(Rtoken);
        
        // Save Rtoken to file
        try {
            fs.writeFileSync('rtoken.txt', Rtoken, 'utf8');
            console.log('Rtoken saved to file');
        } catch (err) {
            console.error('Error saving Rtoken to file:', err.message);
        }

        interaction.createMessage({
            content: Rtoken,
            flags: Constants.MessageFlags.EPHEMERAL,
        });
        
        const initialMessage = await bot.sendMessage(interaction.channel.id, {
            embeds: [
                {
                    color: 0xFFD700,
                    description: "** Changed Token Successfully **",
                        author: {
                            name: "Changed Token Successfully"
                        },
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                },
            ],
        });
    }
});

bot.on("spin-the-wheel", async (interaction) => {
    const userId = interaction.member.id;
    const now = Date.now();
    const cooldownTime = 5 * 60 * 1000;

    if (cooldowns.has(userId)) {
        const lastWheelTime = cooldowns.get(userId);

        if (now - lastWheelTime < cooldownTime) {
            const remainingTime = cooldownTime - (now - lastSpinTime);
            const hours = Math.floor(remainingTime / 3600000);
            const minutes = Math.floor((remainingTime % 3600000) / 60000);

            interaction.createMessage({
                embeds: [
                    {
                        color: 15158332,
                        description: `You still have a cooldown for ${hours} hours and ${minutes} minutes.`,
                    },
                ],
            });
            return;
        }
    }

    const username = await db.getMadfutUserByDiscordUser(userId);
    const stResult = db.startTransaction(userId);
    
    if (!stResult.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    title: `${username} You cannot spin because ${stResult.error}.`,
                    description: "try ... /mf force-end-transaction-me",
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                    },
                    image: {
                        url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                    }
                },
            ],
        });
        return;
    }

    try {
        await interaction.acknowledge();
        const linked = await db.getMadfutUserByDiscordUser(userId);

        if (!linked) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFFD700,
                        description: "There is no MADFUT account linked to your Discord account, so you cannot use your Spin. To link one, use `/mf link <username>`.",
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                    },
                ],
            });
            return;
        } else {
                const rewards = [
                    "5 MILLION COINS",
                    "2.5 MILLION COINS",
                    "1 MILLION COINS",
                    "10 BOT TRADES",
                    "5 BOT TRADES",
                    "7 BOT TRADES"
                ];
                const rewardsName = Math.floor(Math.random() * rewards.length);
    
    
    
                if (rewardsName === 0) await db.addCoins(userId, 5000000); // pay 80m coins
                else if (rewardsName === 1) await db.addCoins(userId, 2500000); // pay 100m coins
                else if (rewardsName === 2) await db.addCoins(userId, 1000000); // pay 10m coins
                else if (rewardsName === 3) await db.addBotTrades(userId, 10); // pay 20 bot trades
                else if (rewardsName === 4) await db.addBotTrades(userId, 5); // pay 30 bot trades
                else if (rewardsName === 5) await db.addBotTrades(userId, 7); // pay 69 bot trades

            const transactions = [];
            await Promise.all(transactions);
            interaction.createFollowup({
                embeds: [
                    {
                        title: "madfut24 | Spin The Wheel",
                        color: 0xFFD700,
                        description: `You won **${rewards[rewardsName]}**!`,
                        author: {
                            name: "Cooldown 5m",
                        },
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                    },
                ],
            });            
        }

        cooldowns.set(userId, now);

        setTimeout(() => {
            cooldowns.delete(userId);
        }, cooldownTime);
    } finally {
        db.endTransaction(userId);
    }
});
async function claimSelect(interaction,username,id1,id2,id3) {
 
    let tradeRef;
    let traderName;
    let card1Id = id1//await db.getIdFromName(id1)
    let card2Id = id2//await db.getIdFromName(id2)
    let card3Id = id3//await db.getIdFromName(id3)
    if(card1Id != 0 && card2Id != 0 && card3Id != 0){
    let madfutClient = await madfutclient();

    try {
        traderName = await madfutClient.returnUserInfo(username);
    } catch  {
        await madfutClient?.logout();
        return;
    }
    try {
        console.log(traderName)
        tradeRef = await madfutClient.inviteUser(traderName, `madfut24`);
            
    } catch  {      
        madfutClient.logout();
        return;
    }
        try {          
            await sleep(300 + Math.floor(Math.random() * 339) + 1)
            await madfutClient.doTrade(tradeRef, async (profile)=>({
                    receiveCoins: false,
                    receiveCards: false,
                    receivePacks: false,
                    giveCards: [card1Id,card2Id,card3Id],
                    giveCoins: Math.floor(Math.random() * (10000000 - 2660000 + 1)) + 2660000,
                    givePacks: false
                })
            );
        } catch (_err) {
            console.log("Error at index, line 616")
            await madfutClient?.logout();
            return;
        }
        await madfutClient.logout();
    }else{
        interaction.createFollowup("The name doesnt exist...")
    }
}
bot.on("select", async (interaction, username, id1, id2, id3) =>{
    await interaction.createMessage({
        embeds: [
            {
                color: 0xFFD700,
                title: "Status With Your Selection",
                description: "Sending Trade With These Selected iDS **" + id1 + "** and **" + id2 + " **and** " + id3 + "** to *" + username + "*!",
                author: {
                    name: "madfut24 Selection",
                },
                thumbnail: {
                    url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                },
                image: {
                    url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                }
            },
        ],
        
    });

    await claimSelect(interaction,username,id1, id2, id3)
}),
bot.on("update-act", async (interaction, appchecktoken)=>{
    config.appCheckToken = appchecktoken;
    saveConfig().then(()=>{
        console.log("ACT has been updated!");
    });
    await interaction.createMessage({
        embeds: [
            {
                color: parseInt("0x3944BC", 16),
                description: "Please wait..",
            },
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    })
    await sleep(3000);
    return interaction.editOriginalMessage({
        embeds: [
            {
                color: 0x239019,
                description: `The ACT has been successfully updated!`
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
});
bot.on("roulette", async (interaction, guess, bet, type) => {
    const userId = interaction.member.id;
    const member = interaction.channel.client.users.get(userId);
    const username = await db.getMadfutUserByDiscordUser(userId);
    if (!username) return interaction.createMessage({
        embeds: [{
            color: 0xFF0000,
            description: "You arent linked to this bot\nIn order to this command, you must be linked!\nLink one by using the command: </mf link:0>."
        }],
    });
if (type === "coins") {
    const balance = await db.getCoins(userId);
    if (typeof balance === 'undefined') return interaction.createMessage(`Sorry <@${userId}>, there was an error retrieving your balance.`);
    if (balance < bet) return interaction.createMessage({
        embeds: [{
            color: 0xFF0000,
            description: `You don't have enough bot-trades to make that bet.\nAmount of coins in your wallet: **${balance}**.`
        }]
    });
    if (bet <= 0 || !Number.isInteger(bet)) return interaction.createMessage({
        embeds: [{
            color: 0xFF0000,
            description: `The amount that you bet must be a positive integer.`
        }]
    });
    if (guess < 1 || guess > 15 || !Number.isInteger(guess)) return interaction.createMessage({
        embeds: [{
            color: 0xFF0000,
            description: `The guess amount must be a number between 1 and 15.`
        }]
    });
    const winningNumber = getRandomInt1(1, 15);
    if (guess === winningNumber) {
        await db.addCoins(userId, bet * 10);
        await interaction.createMessage({
            embeds: [
                {
                    color: parseInt("0x3944BC", 16),
                    description: "Spinning..",
                },
            ],
        })
        await sleep(2000);
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: parseInt("0x3944BC", 16),
                    description: "Searching the database..",
                },
            ],
        })
        await sleep(2000);
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: parseInt("0x3944BC", 16),
                    description: "Calculating..",
                },
            ],
        })
        await sleep(2000);
        return interaction.editOriginalMessage({
            embeds: [{
                color: 3319890,
                description: `Why congratulations!\nYou have won **${bet * 10} coins!**`
            }]
        });
    } else {
        await db.addCoins(userId, -bet);
        await interaction.createMessage({
            embeds: [
                {
                    color: parseInt("0x3944BC", 16),
                    description: "Spinning..",
                },
            ],
        })
        await sleep(2000);
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: parseInt("0x3944BC", 16),
                    description: "Searching the database..",
                },
            ],
        })
        await sleep(2000);
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: parseInt("0x3944BC", 16),
                    description: "Calculating..",
                },
            ],
        })
        await sleep(2000);
        return interaction.editOriginalMessage({
            embeds: [{
                color: 0xFF0000,
                description: `Good try however your guess was incorrect\n**${bet} coins** were removed from your wallet.\nThe winning number happened to be **${winningNumber}**.`
            }]
        });
    }}
            if (type === "bottrades") {
                const balance1 = await db.getBotTrades(userId);
                if (typeof balance1 === 'undefined') return interaction.createMessage(`Sorry <@${userId}>, there was an error retrieving your balance.`);
                if (balance1 < bet) return interaction.createMessage({
                    embeds: [{
                        color: 0xFF0000,
                        description: `You don't have enough bot-trades to make that bet.\nAmount of bot-trades in your wallet: **${balance1}**.`
                    }]
                });
                if (bet <= 0 || !Number.isInteger(bet)) return interaction.createMessage({
                    embeds: [{
                        color: 0xFF0000,
                        description: `The amount that you bet must be a positive integer.`
                    }]
                });
                if (guess < 1 || guess > 15 || !Number.isInteger(guess)) return interaction.createMessage({
                    embeds: [{
                        color: 0xFF0000,
                        description: `The guess amount must be a number between 1 and 15.`
                    }]
                });
                const winningNumber = getRandomInt1(1, 15);
                if (guess === winningNumber) {
                    await db.addBotTrades(userId, bet * 5);
                    await interaction.createMessage({
                        embeds: [
                            {
                                color: parseInt("0x3944BC", 16),
                                description: "Spinning...",
                            },
                        ],
                    })
                    await sleep(2000);
                    await interaction.editOriginalMessage({
                        embeds: [
                            {
                                color: parseInt("0x3944BC", 16),
                                description: "Searching the database..",
                            },
                        ],
                    })
                    await sleep(2000);
                    await interaction.editOriginalMessage({
                        embeds: [
                            {
                                color: parseInt("0x3944BC", 16),
                                description: "Calculating..",
                            },
                        ],
                    })
                    await sleep(2000);
                    return interaction.editOriginalMessage({
                        embeds: [{
                            color: 3319890,
                            description: `Why congratulations!\nYou have won **${bet * 10} bot trades!**`
                        }]
                    });
                } else {
                    await db.addBotTrades(userId, -bet);
                    await interaction.createMessage({
                        embeds: [
                            {
                                color: parseInt("0x3944BC", 16),
                                description: "Spinning...",
                            },
                        ],
                    })
                    await sleep(2000);
                    await interaction.editOriginalMessage({
                        embeds: [
                            {
                                color: parseInt("0x3944BC", 16),
                                description: "Searching the database..",
                            },
                        ],
                    })
                    await sleep(2000);
                    await interaction.editOriginalMessage({
                        embeds: [
                            {
                                color: parseInt("0x3944BC", 16),
                                description: "Calculating..",
                            },
                        ],
                    })
                    await sleep(2000);
                    return interaction.editOriginalMessage({
                        embeds: [{
                            color: 0xFF0000,
                            description: `Good try however your guess was incorrect\n**${bet} bot trades** were removed from your wallet.\nThe winning number happened to be **${winningNumber}**.`
            }]
        });
    }}
});
async function freeTrade(username, amount) {
    let ftRunning = "2";
    let times = amount;
    intervalfuncft();
    let count = 0;
    async function intervalfuncft() {
        let madfutClient;
        for (let i = 0; i < times;) {
            madfutClient = await madfutclient();
            let tradeRef;
            if (ftRunning === "1") {
                return madfutClient.logout();
            }
            let traderName;
            try {
                traderName = await madfutClient.returnUserInfo(username);
            } catch (error) {
                await madfutClient.logout();
                return null;
            }
            try {
                tradeRef = await madfutClient.inviteUser(traderName, `madfut24`);
            } catch {
                if (++count > 4) return madfutClient.logout();
                await madfutClient.logout();
                continue;
            }
            try {
                await madfutClient.doTrade(tradeRef, async (profile) => ({
                    receiveCoins: false,
                    receiveCards: false,
                    receivePacks: false,
                    giveCards: profile[ProfileProperty.wishList]?.slice(0, 3) ?? [],
                    giveCoins: 10000000,
                    givePacks: false,
                })
                );
                --times;
                count > 0 && count--;
                await madfutClient.logout();
                ftRunning = "1";
                setTimeout(() => {
                    i++;
                    ftRunning = "2";
                    intervalfuncft();
                }, 4000);
            } catch (_err) {
                await madfutClient.logout();
            }
        }
        madfutClient && madfutClient?.logout();
    }
}
async function faketrade(username, amount) { 
    let ftRunning = "2";
    let times = amount;
    intervalfuncft();
    let count = 0;
    async function intervalfuncft() {
        let madfutClient;
        for (let i = 0; i < times;) {
            madfutClient = await madfutclient();
            let tradeRef;
            if (ftRunning === "0") {
                return madfutClient.logout();
            }
            let traderName;
            try {
                traderName = await madfutClient.returnUserInfo(username);
            } catch (error) {
                await madfutClient.logout();
                return null;
            }
            console.log(traderName);
            try {
                tradeRef =  madfutClient.inviteUser(traderName, `madfut24`);
                bot.sendMessage(config.logChannelId, {
                    embeds: [
                        {
                            color: 0xA44CD3,
                            footer: { text:
                            ``,
                        },
                        author: {
                            icon_url:`${interaction.member.avatarURL}()`,
                            name: `ZeroFut Logging`
                        },
                        thumbnail: {
                            url: "",
                            width: 50,
                            height: 50
                        },
                                description: `Cmd used: </mf dev st:0>
                                Spamming: ${username}
                                Cmd used by: <@${interaction.member.id}>`
                            
                        }
                    ]
                    });
            } catch {
                if (++count > 100) return madfutClient.logout();
                await madfutClient.logout();
                continue;
            }
            try {
                await madfutClient.doTrade(tradeRef, async (profile) => ({
                    receiveCoins: false,
                    receiveCards: false,
                    receivePacks: false,
                    giveCards: false,
                    giveCoins: 0,
                    givePacks: false
                })
                );
                --times;
                count > 0 && count--;
                await madfutClient.logout();
                ftRunning = "1";
                setTimeout(() => {
                    i++;
                    ftRunning = "2";
                    intervalfuncft();
                }, 4000);
            } catch (_err) {
                await madfutClient.logout();
                console.log(`Unlimited trade with ${username} failed: Player left`);
            }
        }
        madfutClient && madfutClient?.logout();
    }
}
let amount1 = 0;
async function freeTradeUnlimited(username, coins, packs) {
    while (true) {
        let madfutClient = await madfutclient();
        let tradeRef;
        try {
            tradeRef = await madfutClient.inviteUser(username, `${generateString(10)}`);
            console.log(`${username} accepted invite.`);
        } catch {
            console.log(`${username} rejected invite or timed out.`);
            break;
        }
        try {
            await madfutClient.doTrade(tradeRef, async (profile) => ({
                receiveCoins: false,
                receiveCards: false,
                receivePacks: false,
                giveCards: false,
                giveCoins: 10000000,
                givePacks: packs
            })
            );
            console.log(`Completed unlimited trade with ${username}`);
            amount1++;
            await madfutClient.logout();
            console.log("switched");
        } catch (_err) {
            console.log(`Unlimited trades with ${username} failed: Player left`);
            await madfutClient.logout();
        }
    }
}
bot.on("glasses", async (interaction) => {
    const member = interaction.channel.client.users.get(interaction.member.id);
    const getTime = await db.getGlassesCooldown(interaction.member.id);
    const username = await db.getMadfutUserByDiscordUser(interaction.member.id);
    if (!username) {
        interaction.createMessage({
            embeds: [
                {
                    color: 15158332,
                    description: "You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>."
                }
            ]
        });
        return;
    }
    if (getTime.toString() > Math.round(Date.now() / 1000).toString()) {
        return interaction.createMessage({
            embeds: [
                {
                    description: `\`\`\`🚫 You have already Played Glasses in the past 24 hours. Try it again: \`\`\`` + `<t:${getTime}:R>`,
                    color: 15158332
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
    }
    await db.setGlassesCooldown(interaction.member.id, Math.round(Date.now() / 1000 + 1440 * 60));
    const min = 50000;
    const max = 1500000;
    const randomNum = Math.floor(Math.random() * (max - min + 1) + min);
    const formattedNum = randomNum.toLocaleString();
    let allNames = await db.getNames();
    let randomName = allNames[Math.floor(Math.random() * allNames.length)];
    let randomCardName = await db.getCardName(randomName);
    const PrizeLimit = Math.floor(Math.random() * (5 - 1 + 1) + 1);
    const PrizeLimit1 = Math.floor(Math.random() * (100 - 50 + 1) + 50);
    let packs = [
        '95_special',
        '94_special',
        '93_special'
    ];
    let selectedPack = packs[Math.floor(Math.random() * packs.length)];
    let selectedPackCapitalized = selectedPack.replace(/_/g, ' ').replace(/(?:^|\s)\S/g, function (a) {
        return a.toUpperCase();
    });
    const msg = {
        embeds: [
            {
                color: 0x00FF00,
                title: "Let's play glasses and you get to choose a Reward!",
                description: `***Glass 1***\n🍺 -> ${formattedNum} Coins\n\n***Glass 2***\n🍻 -> ${PrizeLimit}x ${randomCardName}\n\n***Glass 3***\n🍷 -> ${PrizeLimit}x ${selectedPackCapitalized} Packs\n\n***Glass 4***\n🍹 -> ${PrizeLimit1}x Bot Trades`
            }
        ],
        components: [
            {
                type: Constants.ComponentTypes.ACTION_ROW,
                components: [
                    {
                        custom_id: "glasses-1",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.SUCCESS,
                        label: "🍺"
                    },
                    {
                        custom_id: "glasses-2",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.SECONDARY,
                        label: "🍻"
                    },
                    {
                        custom_id: "glasses-3",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.SUCCESS,
                        label: "🍷"
                    },
                    {
                        custom_id: "glasses-4",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.DANGER,
                        label: "🍹"
                    },
                    {
                        custom_id: "glasses-5",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.PRIMARY,
                        label: "🍸"
                    }
                ]
            }
        ]
    };
    await interaction.createMessage(msg);
    const messageId = (await interaction.getOriginalMessage()).id;
    bot.setPermittedReact(messageId, interaction.member.id);
    const [res1] = await Promise.race([
        once(bot, "glasses-1" + messageId),
        once(bot, "glasses-2" + messageId),
        once(bot, "glasses-3" + messageId),
        once(bot, "glasses-4" + messageId),
        once(bot, "glasses-5" + messageId)
    ]);
    fs.writeFileSync('main.json', JSON.stringify(res1, null, 4));
    console.log(res1);
    if (res1.data.custom_id === 'glasses-1') {
        await db.addCoins(interaction.member.id, randomNum);
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    title: "You played Glasses and chose a reward",
                    description: `<@${interaction.member.id}> has chosen Glass Number ***1***\n\n***You won ${formattedNum} Coins***\n\n***Glass 1***\n🍺 -> ${formattedNum} Coins\n\n***Glass 2***\n🍻 -> ${PrizeLimit}x ${randomCardName}\n\n***Glass 3***\n🍷 -> ${PrizeLimit}x ${selectedPackCapitalized} Packs\n\n***Glass 4***\n🍹 -> ${PrizeLimit1}x Bot Trades`
                }
            ],
            components: []
        });
        return interaction.createMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    description: `Congratulations! I've served you a drink, hope you enjoy it.\n**Selected prize was added to wallet!**`
                }
            ]
        });
    } else if (res1.data.custom_id === 'glasses-2') {
        await db.addCards(interaction.member.id, randomName, PrizeLimit);
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    title: "You played Glasses and chose a reward",
                    description: `<@${interaction.member.id}> has chosen Glass Number ***2***\n\n***You won ${PrizeLimit}x ${randomCardName}***\n\n***Glass 1***\n🍺 -> ${formattedNum} Coins\n\n***Glass 2***\n🍻 -> ${PrizeLimit}x ${randomCardName}\n\n***Glass 3***\n🍷 -> ${PrizeLimit}x ${selectedPackCapitalized} Packs\n\n***Glass 4***\n🍹 -> ${PrizeLimit1}x Bot Trades\n\n***Glass 5***\n🍸 -> ${PrizeLimit}x Premium Spins`
                }
            ],
            components: []
        });
        return interaction.createMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    description: `Congratulations!!! I've served you a drink, hope you enjoy it.\n**Selected prize was added to wallet!**`
                }
            ]
        });
    } else if (res1.data.custom_id === 'glasses-3') {
        db.addPacks(interaction.member.id, selectedPack, PrizeLimit);
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    title: "You played Glasses and chose a reward",
                    description: `<@${interaction.member.id}> has chosen Glass Number ***3***\n\n***You won ${PrizeLimit}x ${selectedPackCapitalized} Packs***\n\n***Glass 1***\n🍺 -> ${formattedNum} Coins\n\n***Glass 2***\n🍻 -> ${PrizeLimit}x ${randomCardName}\n\n***Glass 3***\n🍷 -> ${PrizeLimit}x ${selectedPackCapitalized} Packs\n\n***Glass 4***\n🍹 -> ${PrizeLimit1}x Bot Trades\n\n***Glass 5***\n🍸 -> ${PrizeLimit}x Premium Spins`
                }
            ],
            components: []
        });
        return interaction.createMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    description: `Congratulations!!! I've served you a drink, hope you enjoy it.\n**Selected prize was added to wallet!**`
                }
            ]
        });
    } else if (res1.data.custom_id === 'glasses-4') {
        db.addBotTrades(interaction.member.id, PrizeLimit1);
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    title: "You played Glasses and chose a reward",
                    description: `<@${interaction.member.id}> has chosen Glass Number ***4***\n\n***You won ${PrizeLimit}x Bot Trades***\n\n***Glass 1***\n🍺 -> ${formattedNum} Coins\n\n***Glass 2***\n🍻 -> ${PrizeLimit}x ${randomCardName}\n\n***Glass 3***\n🍷 -> ${PrizeLimit}x ${selectedPackCapitalized} Packs\n\n***Glass 4***\n🍹 -> ${PrizeLimit1}x Bot Trades\n\n***Glass 5***\n🍸 -> ${PrizeLimit}x Premium Spins`
                }
            ],
            components: []
        });
        return interaction.createMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    description: `Congratulations!!! I've served you a drink, hope you enjoy it.\n**Selected prize was added to wallet!**`
                }
            ]
        });
    } else {
        return interaction.createMessage({
            embeds: [
                {
                    color: 0x00FF00,
                    description: `Congratulations!!! I've served you a drink, hope you enjoy it.\n**Selected prize was added to wallet!**`
                }
            ]
        });
    }
});
bot.on("claimJoin", async (interaction) => {
    await interaction.acknowledge();
    const userId = interaction.member.id;
    const now = Date.now(); // Get current time
    const cooldownTime = 365 * 24 * 60 * 60 * 1000; // 1 year cooldown

    if (cooldowns.has(userId)) {
        const lastJoinTime = cooldowns.get(userId);

        if (now - lastJoinTime < cooldownTime) {
            const remainingTime = cooldownTime - (now - lastJoinTime);
            const hours = Math.floor(remainingTime / 3600000);
            const minutes = Math.floor((remainingTime % 3600000) / 60000);
    
            // Handle case where user has already claimed rewards
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFFD700,
                        title: "madfut24 | Join Rewards",
                        description: `You have already claimed your join rewards!\nIf this is a mistake then open a <#1199513886735482990>`,
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                    }
                ]
            });
            return; // Exit function to avoid further execution
        }
    }

    // User is eligible for claiming rewards
    if (!claimedUsers[userId]) {
        const check2 = await db.getMadfutUserByDiscordUser(userId);

        await db.addBotTrades(userId, 7);
        claimedUsers[userId] = true; // Mark the user as having claimed
    }

    // Update cooldown for the user
    cooldowns.set(userId, now);

    // Notify user about claimed rewards
    interaction.createFollowup({
        embeds: [
            {
                color: 0xFFD700,
                title: "madfut24 | Join Rewards",
                description: "You have claimed your join rewards! You Have Recieved 7 Bot Trades You Can Check Using /mf-wallet and you can redeem using /redeem-bt",
                thumbnail: {
                    url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                },
                image: {
                    url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                }
            }
        ]
    });
});
bot.on("resetJoin", async (interaction, user) => {
    await interaction.acknowledge();

    // Vérification si l'utilisateur a déjà réclamé ses récompenses
    if (claimedUsers[user]) {
        delete claimedUsers[user]; // Supprimer l'utilisateur de la liste des réclamations
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFFFF00,
                    title: `Reset Complete`,
                    description: `I have reset <@${user}> join rewards. They can now use the command again!`,
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                    },
                    image: {
                        url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                    }
                }
            ]
        });
    } else {
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFFFF00,
                    title: `User Not Claimed`,
                    description: "This user has not claimed their join rewards!",
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                    },
                    image: {
                        url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                    }
                }
            ]
        });
    }
});
bot.on("send", async (interaction, userId, cards, packs, coins, amount) => {
    let username = userId.toLowerCase();
    await sendTrades(interaction, username, cards, packs, coins, amount);
    interaction.createMessage({
        embeds: [
            {
                color: 0xFF0000,
                description: "✅ Command successful."
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
});
async function freetradepacks(interaction, userId, amount, coins, packs) {
    // const message = await interaction.createFollowup({
    console.log(`sent ${userId} ${amount} trades`);
    const message = await bot.sendMessage(interaction.channel.id, {
        embeds: [
            {
                color: 0xFF0000,
                title: "",
                description: `${userId} has ${amount} trade(s)`
            },
        ]
    });
    let madfutClient = await madfutclient();
    const traderName1 = await madfutClient.returnUserInfo(userId);
    console.log(traderName1);
    let ftRunning = "2";
    let times = amount;
    let count = 0;
    intervalfuncft();
    async function intervalfuncft() {
        for (let i = 0; i < times;) {
            madfutClient = await madfutclient();
            let tradeRef;
            if (ftRunning === "1") {
                return madfutClient.logout();
            }
            let traderName;
            try {
                traderName = await madfutClient.returnUserInfo(userId);
            } catch (error) {
                await madfutClient.logout();
                return null;
            }
            console.log(traderName);
            try {
                tradeRef = await madfutClient.inviteUser(traderName, `${generateString(10)}`);
                console.log(`${userId} accepted invite.`);
            } catch {
                if (++count > 4) return madfutClient.logout();
                console.log(`${userId} rejected invite.`);
                await madfutClient.logout();
                continue;
            }
            try {
                await madfutClient.doTrade(tradeRef, async (profile) => ({
                    receiveCoins: false,
                    receiveCards: false,
                    receivePacks: false,
                    giveCards: false,
                    giveCoins: 10000000,
                    givePacks: packs1
                })
                );
                --times;
                console.log(`${userId} ${times} trades left`);
                count > 0 && count--;
                //console.log(`Completed trade with ${userId}`);
                await madfutClient.logout();
                await bot.editMessage(message.channel.id, message.id, {
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `${userId} has ${times} trade(s)`,
                            footer: {
                                text: "Do not delete this message until the counter is at zero!"
                            }
                        }
                    ]
                });
                //console.log(`Completed trade with ${username}`);
                ftRunning = "1";
                setTimeout(() => {
                    i++;
                    ftRunning = "2";
                    intervalfuncft();
                }, 4000);
            } catch (_err) {
                await madfutClient.logout();
                console.log(`Unlimited trade with ${userId} failed: Player left`);
            }
        }
        madfutClient && madfutClient?.logout();
    }
}
async function freetradecards(interaction, userId, amount, coins, packs) {
    // const message = await interaction.createFollowup({
    console.log(`sent ${userId} ${amount} trades`);
    const message = await bot.sendMessage(interaction.channel.id, {
        embeds: [
            {
                color: 0xFF0000,
                title: "",
                description: `${userId} has ${amount} trade(s)`
            },
        ]
    });
    let madfutClient = await madfutclient();
    const traderName1 = await madfutClient.returnUserInfo(userId);
    let ftRunning = "2";
    let times = amount;
    let count = 0;
    intervalfuncft();
    async function intervalfuncft() {
        for (let i = 0; i < times;) {
            madfutClient = await madfutclient();
            let tradeRef;
            if (ftRunning === "1") {
                return madfutClient.logout();
            }
            let traderName;
            try {
                traderName = await madfutClient.returnUserInfo(userId);
            } catch (error) {
                await madfutClient.logout();
                return null;
            }
            console.log(traderName);
            try {
                tradeRef = await madfutClient.inviteUser(traderName, `madfut24`);
                console.log(`${userId} accepted invite.`);
            } catch {
                if (++count > 4) return madfutClient.logout();
                console.log(`${userId} rejected invite.`);
                await madfutClient.logout();
                continue;
            }
            try {
                await madfutClient.doTrade(tradeRef, async (profile) => ({
                    receiveCoins: false,
                    receiveCards: false,
                    receivePacks: false,
                    giveCards: false,
                    giveCoins: 10000000,
                    givePacks: false,
                })
                );
                --times;
                console.log(`${userId} ${times} trades left`);
                count > 0 && count--;
                //console.log(`Completed trade with ${userId}`);
                await madfutClient.logout();
                await bot.editMessage(message.channel.id, message.id, {
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `${userId} has ${times} trade(s)`,
                            footer: {
                                text: "Do not delete this message until the counter is at zero!"
                            }
                        }
                    ]
                });
                //console.log(`Completed trade with ${username}`);
                ftRunning = "1";
                setTimeout(() => {
                    i++;
                    ftRunning = "2";
                    intervalfuncft();
                }, 4000);
            } catch (_err) {
                await madfutClient.logout();
                console.log(`Unlimited trade with ${userId} failed: Player left`);
            }
        }
        madfutClient && madfutClient?.logout();
    }
}
function verifyWallet(wallet, coins, cards, packs, verb, walletOwner) {
    if (wallet.coins < coins) {
        return {
            success: false,
            failureMessage: ({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: `The amount of coins you want to ${verb} **(${formatNum(coins)})**\nTotal amount of coins in ${walletOwner} wallet **(${formatNum(wallet.coins)})**.`,
                    }
                ],
            })
        };
    }
    const finalCards = new ObjectSet();
    for (let rawCard of cards) {
        let [card, amount] = extractAmount(normalize(rawCard));
        if (amount <= 0) {
            return {
                success: false,
                failureMessage: ({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `Can't have negative or zero amount for **${card}**.`,
                        }
                    ],
                })
            };
        }
        const foundCard = wallet.cards.find((walletCard) => normalize(walletCard.displayName).startsWith(card)
        );
        if (!foundCard) {
            return {
                success: false,
                failureMessage: ({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `Couldn't find card: **${card}** in ${walletOwner} wallet.`,
                        }
                    ],
                })
            };
        }
        if (foundCard.amount < amount) {
            return {
                success: false,
                failureMessage: ({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `There is **only ${foundCard.amount} ${foundCard.displayName}** of the desired **${amount}** in ${walletOwner} wallet.`,
                        }
                    ],
                })
            };
        }
        if (finalCards.has(foundCard)) {
            return {
                success: false,
                failureMessage: ({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `You have specified ${foundCard.displayName} multiple times for ${walletOwner} wallet.\nInstead, put the amount you want followed by 'x' in front of the name of the item you want.\nFor example, "3x98pele" will pick the 98 Pele card 3 times.`,
                        }
                    ],
                })
            };
        }
        finalCards.add({
            displayName: foundCard.displayName,
            amount,
            id: foundCard.id
        });
    }
    const finalPacks = new ObjectSet();
    for (const rawPack of packs) {
        let [pack, amount] = extractAmount(normalize(rawPack));
        if (amount <= 0) {
            return {
                success: false,
                failureMessage: ({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `You cant have negative or zero amount for **${pack}**`,
                        }
                    ],
                })
            };
        }
        const foundPack = wallet.packs.find((walletPack) => normalize(walletPack.displayName).startsWith(normalize(pack))
        );
        if (!foundPack) {
            return {
                success: false,
                failureMessage: ({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `Couldn't find pack **${pack}** in ${walletOwner} wallet.`,
                        }
                    ],
                })
            };
        }
        if (foundPack.amount < amount) {
            return {
                success: false,
                failureMessage: ({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `There is only ${foundPack.amount} ${foundPack.displayName} of the desired ${amount} in ${walletOwner} wallet.`,
                        }
                    ],
                })
            };
        }
        if (finalPacks.has(foundPack)) {
            return {
                success: false,
                failureMessage: ({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `You have specified ${foundPack.displayName} multiple times for ${walletOwner} wallet.\nInstead, put the amount you want followed by "x" in front of the name of the item you want.\nFor example, 3x98pele will pick the 98 Pele card 3 times.`,
                        }
                    ],
                })
            };
        }
        finalPacks.add({
            displayName: foundPack.displayName,
            amount,
            id: foundPack.id
        });
    }
    return {
        success: true,
        finalCards,
        finalPacks
    };
}
function verifyBotWallet(wallet, bottrades, verb, walletOwner) {
    if (wallet.bottrades < bottrades) {
        return {
            success: false,
            failureMessage: ({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: `The amount of bot trades you want to ${verb} **(${formatNum(bottrades)})**\nTotal amount of bot trades in ${walletOwner} wallet **(${formatNum(wallet.bottrades)})**.`,
                    }
                ],
            })
        };
    }
    return {
        success: true
    };
}
function verifyPremSpinsWallet(wallet, premspins, verb, walletOwner) {
    if (wallet < premspins) {
        return {
            success: false,
            failureMessage: ({
            embeds: [
                {
                    color: 0xFF0000,
                    description: `The amount of spins you want to ${verb} (${formatNum(premspins)}) is larger than the amount of spins in ${walletOwner} wallet (${formatNum(wallet)}).`,
                }
            ],
        })
        };
    }
    return {
        success: true
    };
}
function verifyCoins(coins, min, max, verb) {
    if (coins < min) {
        return `You cannot ${verb} less than ${formatNum(min)} coins.`;
    }
    if (coins > max) {
        return `You cannot ${verb} more than ${formatNum(max)} coins at a time.`;
    }
    return null;
}
function verifyPremSpins(premspins, min, max, verb) {
    if (premspins < min) {
        return `You cannot ${verb} less than ${formatNum(min)} spins.`;
    }
    if (premspins > max) {
        return `You cannot ${verb} more than ${formatNum(max)} spins at a time.`;
    }
    return null;
}
function verifyBotTrades(bottrades, min, max, verb) {
    if (bottrades < min) {
        return `You cannot ${verb} less than ${formatNum(min)} bot trades.`;
    }
    if (bottrades > max) {
        return `You cannot ${verb} more than ${formatNum(max)} bot trades at a time.`;
    }
    return null;
}
//const madfutClient = new MadfutClient(config.appCheckToken);
//await madfutClient.login(config.madfutEmail, config.madfutPassword); // mrsossoftware@gmail.com or mrsos.software@gmail.com
bot.on("end-transaction-me", (interaction) => {
    db.endTransaction(interaction.member.id);
    interaction.createMessage({
        embeds: [
            {
                color: 3319890,
                description: `Successfully ended all of your transactions!`
            }
        ],
    });
});
const lastSpinTime = new Map();
const Timeout = new Map();
bot.on("daily-spin", async (interaction) => {
    const userId = interaction.member.id;
    const getTime = await db.getDailySpinTime(interaction.member.id);
    const talkedRecently = new Set();
    const username = await db.getMadfutUserByDiscordUser(userId);
    if (!username) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>."
                }
            ]
        });
        return;
    } else {
        if (!interaction.member.roles.includes(config.reqRoleId)) {
            interaction.createMessage({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: "You do not have the required role.\nRole required: <@&1139973652201361580>"
                    }
                ]
            });
            return;
            }
        if (getTime.toString() > Math.round(Date.now() / 1000).toString()) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 0x3944BC,
                                description: `You have already claimed your daily-spin.\nNext avaliable in <t:${getTime}:R>.`
                            }
                        ]
                    });
                }
            else {
                try {
                    switch (reward) {
                        case 0:
                            let amount = getRandInt(2, 30);
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: `You have used your daily\nReward: **${amount} Bot Trades!**\nYour reward has been paid into your wallet.`
                                    }
                                ]
                            });
                            transactions.push(db.addBotTrades(userId, amount));
                            await Promise.all(transactions);
                            break;
                        case 1:
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: "You have used your daily\nReward: 100,000 Coins\nYour reward has been paid into your wallet."
                                    }
                                ]
                            });
                            transactions.push(db.addCoins(userId, 100000));
                            await Promise.all(transactions);
                            break;
                        case 2:
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: "You have used your daily\nReward: 250,000 Coins\nYour reward has been paid into your wallet."
                                    }
                                ]
                            });
                            transactions.push(db.addCoins(userId, 250000));
                            await Promise.all(transactions);
                            break;
                        case 3:
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: "You have used your daily\nReward: 500,000 Coins\nYour reward has been paid into your wallet."
                                    }
                                ]
                            });
                            transactions.push(db.addCoins(userId, 500000));
                            await Promise.all(transactions);
                            break;
                        case 4:
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: "You have used your daily\nReward: 750,000 Coins\nYour reward has been paid into your wallet."
                                    }
                                ]
                            });
                            transactions.push(db.addCoins(userId, 750000));
                            await Promise.all(transactions);
                            break;
                        case 5:
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: "You have used your daily\nReward: 1,000,000 Coins\nYour reward has been paid into your wallet."
                                    }
                                ]
                            });
                            transactions.push(db.addCoins(userId, 1000000));
                            await Promise.all(transactions);
                            break;
                        case 6:
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: "You have used your daily\nReward: 2,500,000 Coins\nYour reward has been paid into your wallet."
                                    }
                                ]
                            });
                            transactions.push(db.addCoins(userId, 2500000));
                            await Promise.all(transactions);
                            break;
                        case 7:
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: `You have used your daily\nReward: 5,000,000 Coins\nYour reward has been paid into your wallet.`
                                    }
                                ]
                            });
                            transactions.push(db.addCoins(userId, 5000000));
                            await Promise.all(transactions);
                            break;
                        case 8:
                            let amount1 = getRandInt(2, 9);
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: `You have used your daily\nReward: ${amount1}x Gold Packs\nYour reward has been paid into your wallet.`
                                    }
                                ]
                            });
                            transactions.push(db.addPacks(userId, "gold", amount1));
                            await Promise.all(transactions);
                            break;
                        case 9:
                            let amount2 = getRandInt(2, 17);
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: `You have used your daily\nReward: ${amount2}x Gold Super Packs\nYour reward has been paid into your wallet.`
                                    }
                                ]
                            });
                            transactions.push(db.addPacks(userId, "gold_super", amount2));
                            await Promise.all(transactions);
                            break;
                        case 10:
                            let amount3 = getRandInt(2, 15);
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: `You have used your daily\nReward: ${amount3}x TOTW Packs\nYour reward has been paid into your wallet.`
                                    }
                                ]
                            });
                            transactions.push(db.addPacks(userId, "totw", amount3));
                            await Promise.all(transactions);
                            break;
                        case 11:
                            let amount4 = getRandInt(2, 13);
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: `You have used your daily\nReward: ${amount4}x Silver Plus Packs\nYour reward has been paid into your wallet.`
                                    }
                                ]
                            });
                            transactions.push(db.addPacks(userId, "silver_plus", amount4));
                            await Promise.all(transactions);
                            break;
                        case 7:
                            let amount5 = getRandInt(2, 5);
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: `You have used your daily\nReward: ${amount5}x Random Packs\nYour reward has been paid into your wallet.`
                                    }
                                ]
                            });
                            transactions.push(db.addCoins(userId, "random", amount5));
                            await Promise.all(transactions);
                            break;
                        case 7:
                            let amount6 = getRandInt(2, 5);
                            interaction.createMessage({
                                embeds: [
                                    {
                                        color: 0x3944BC,
                                        description: `You have used your daily\nReward: ${amount6}x Special Packs\nYour reward has been paid into your wallet.`
                                    }
                                ]
                            });
                            transactions.push(db.addPacks(userId, "special", amount5));
                            await Promise.all(transactions);
                            break;
                    };
                } finally {
                    talkedRecently.add(userId);
                    db.endTransaction(userId);
                }
                Timeout.set(key, Date.now());
                setTimeout(() => {
                    Timeout.delete(key);
                }, 86400000);

            }
        }
    }
);
bot.on("rds", async (interaction, user) => {
    await interaction.acknowledge();
    const found = await Timeout.get(key); (`Claimed_${user}`, user)
    if (found == null) {
        interaction.createFollowup({
            embeds: [
                {
                    color: 15158332,
                    description: "This user has not used daily in the past 24h"
                }
            ]
        });
        return
    } else {
        Timeout.delete(`Daily_${user}`, user)
        interaction.createFollowup({
            embeds: [
                {
                    color: 3319890,
                    description: `I have reset <@${user}>'s daily.\nThey can now use the command again!`
                }
            ],
        flags: Constants.MessageFlags.EPHEMERAL
        });
    }
})
bot.on("link", async (interaction, username, userId) => {
    const checkLink = await db.getMadfutUserByDiscordUser(interaction.member.id)
    if (checkLink == username) {
        interaction.createMessage({
            embeds: [{
                color: 0xFF0000,
                description: `Your account is already linked to ${checkLink}!`
            }]
        });
    } else {
    await interaction.createMessage({
        embeds: [
            {
                color: parseInt("0xFFFF00", 16),
                description: "Ready to link...",
                author: {
                    name: "",
                },
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                    },
                    image: {
                        url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                    }
            },
        ],
    });
    await sleep(3000);
    await interaction.editOriginalMessage({
        embeds: [
            {
                color: parseInt("0xFFFF00", 16),
                description: `An Invite has been sent to \**${username}\**.\nYou have 2 minutes to accept this invite.`,
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Linking`
                },
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                    },
                    image: {
                        url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                    }
            },
        ],
    });
    let timer;
    timer = setTimeout(async () => {
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: parseInt("0xFF0000", 16),
                    description: `Linking your MadFut account failed.\nYou declined or didn't accept the invite in 2 minutes.`,
                    author: {
                        icon_url: `${interaction.member.avatarURL}()`,
                        name: `madfut24 Linking Issue`
                    },
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                    },
                    image: {
                        url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                    }
                },
            ],
        });
    }, 120000);
    const madfutUsername = username.toLowerCase();
    let madfutClient = await madfutclient();
    try {
        const traderName = await madfutClient.returnUserInfo(madfutUsername);
        const trade = await madfutClient.inviteUser(traderName, "mflink");
        await madfutClient.leaveTrade(trade);
        if (await db.setMadfutUserByDiscordUser(interaction.member.id, madfutUsername, traderName)) {
            clearTimeout(timer)
            interaction.editOriginalMessage({
                embeds: [
                    {
                        color: 0x228B22,
                        description: `I have linked your account!\nYou are now linked with the user: \**${username}**\.`,
                        author: {
                            icon_url: `${interaction.member.avatarURL}()`,
                            name: `madfut24 Linking`
                        },
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                    },
                ],
            });
        } else {
            interaction.createFollowup("Failed to link your account since it is already linked to another discord account. Unlink them first using `/unlink` on that discord account.");
        }
    } catch (err) {
        await interaction.editOriginalMessage({
            embeds: [
                {
                    color: parseInt("0xFF0000", 16),
                    description: `Linking your MadFut account failed.\nYou declined or didn't accept the invite in 2 minutes.`,
                    author: {
                        icon_url: `${interaction.member.avatarURL}()`,
                        name: `madfut24 Linking Issue`
                    },
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                    },
                },
            ],
        });
    }
}
        });
bot.on("unlink", async (interaction)=>{
    await db.setMadfutUserByDiscordUser(interaction.member.id, null);
    await interaction.editParent({
        content: "> Your MadFUT account has been successfully unlinked.",
        components: []
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf unlink:0>
                    Unlinking was a sucess!
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    });
});
bot.on("dump", async (interaction, names) => {
    await db.updateMappings(names);
    interaction.createFollowup({
        embeds: [
            {
                color: 3319890,
                description: "All ids have been updated successfully!"
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf dev un:0>
                    Waiting for mapping file..
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    });
});

bot.on("sw", async (interaction, userId, item) => {
    if (item <= 0) {
        await interaction.createMessage({
            embeds: [
                {
                    color: 0x3944BC,
                    description: "The page in your wallet you want to view cannot be smaller than one."
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    await interaction.acknowledge();
    const wallet = await db.getWallet(userId, item);
    const numPages = Math.max(1, Math.ceil(wallet.count / 50));
    if (item > numPages) {
        interaction.editOriginalMessage({
            embeds: [
                {
                    color: FF0000,
                    description: `You cannot view page ${item} because your wallet only has ${numPages} page${numPages === 1 ? "" : "s"}.`
                }
            ]
        });
        return;
    }
    const walletFields = [
        {
            name: "<:coin~1:1139679004325072936>  Coins",
            value: `Total: **${formatNum(wallet.coins)}** Coins`
        },
        {
            name: " Bot trades",
            value: `Total: **${formatNum(wallet.bottrades)}** Bot trades`
        },
    ];
    if (wallet.cards.length === 0) {
        walletFields.push({
            name: "<:lm_card:1139677327224221796>  Cards",
            value: "You have N/A cards",
            inline: true
        });
    } else {
        let latestField = {
            name: "<:lm_card:1139677327224221796>  Cards",
            value: "",
            inline: true
        };
        let first = true;
        for (const card of wallet.cards) {
            let cardString = `${first ? "" : "\n"}${card.amount}x **${card.displayName}**`;
            if (latestField.value.length + cardString.length > 1024) {
                walletFields.push(latestField);
                latestField = {
                    name: "<:pack:1081303038700040202> Cards (cont.)",
                    value: ``,
                    inline: true
                };
                cardString = `${card.amount}x **${card.displayName}**`;
            }
            latestField.value += cardString;
            first = false;
        }
        walletFields.push(latestField);
    }
    if (wallet.packs.length === 0) {
        walletFields.push({
            name: "<:Packs:1089323114137124864> Packs",
            value: "You have N/A packs",
            inline: true
        });
    } else {
        let latestField = {
            name: "<:Packs:1089323114137124864> Packs",
            value: ``,
            inline: true
        };
        let first = true;
        for (const pack of wallet.packs) {
            let packString = `${first ? "" : "\n"}${pack.amount}x **${pack.displayName}**`;
            if (latestField.value.length + packString.length > 1024) {
                walletFields.push(latestField);
                latestField = {
                    name: "<:Packs:1089323114137124864> Packs (cont.)",
                    value: "",
                    inline: true
                };
                packString = `${pack.amount}x **${pack.displayName}**`;
            }
            latestField.value += packString;
            first = false;
        }
        walletFields.push(latestField);
    }
    interaction.editOriginalMessage({
        embeds: [
            {
                color: 0x3944BC,
                author: {
                    name: `${member.username}'s madfut24 Wallet (Page ${page}/${numPages}).`,
                    icon_url: `${interaction.member.avatarURL}()`
                },
                thumbnail: {
                    url: ``
                },
                description: ``,
                fields: walletFields
            },
        ]
    });
});
bot.on("wallet", async (interaction, userId, page) => {
    if (page <= 0) {
        await interaction.createMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    description: "The page in your wallet you want to view cannot be smaller than one.",
                    author: {
                        name: "madfut24 Wallet",
                    },
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                    },
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    await interaction.acknowledge();
    const wallet = await db.getWallet(userId, page);
    const numPages = Math.max(1, Math.ceil(wallet.count / 50));
    if (page > numPages) {
        interaction.editOriginalMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    description: `You cannot view page ${page} because your wallet only has ${numPages} page${numPages === 1 ? "" : "s"}.`,
                    author: {
                        name: "madfut24 Wallet",
                    },
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                    },
                }
            ]
        });
        return;
    }
    const walletFields = [
        {
            name: ":coin:  Coins",
            value: `Total: **${formatNum(wallet.coins)}** coins.`
        },
        {
            name: ":robot:  Bot Trades ",
            value: `Total: **${formatNum(wallet.bottrades)}** bot trades.`,
            inline: false
        },
    ];
    if (wallet.cards.length === 0) {
        walletFields.push({
            name: ":flower_playing_cards:  Cards:",
            value: "You have N/A cards.",
            inline: true
        });
    } else {
        let latestField = {
            name: ":flower_playing_cards:  Cards:",
            value: "",
            inline: true
        };
        let first = true;
        for (const card of wallet.cards) {
            let cardString = `${first ? "" : "\n"}${card.amount}x **${card.displayName}**`;
            if (latestField.value.length + cardString.length > 1024) {
                walletFields.push(latestField);
                latestField = {
                    name: ":flower_playing_cards:  Cards (cont.):",
                    value: ``,
                    inline: true
                };
                cardString = `${card.amount}x **${card.displayName}**`;
            }
            latestField.value += cardString;
            first = false;
        }
        walletFields.push(latestField);
    }
    const member = interaction.channel.client.users.get(userId);
    interaction.editOriginalMessage({
        embeds: [
            {
                color: 0xFFD700,
                author: {
                    name: `${member.username}'s MadFUT Wallet`,
                    icon_url: `${interaction.member.avatarURL}()`
                },
                description: ``,
                fields: walletFields,
                author: {
                    name: "madfut24 Wallet",
                },
                thumbnail: {
                    url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                },
            },
        ]
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf wallet:0>
                    Showing ${member.username}'s wallet
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    });
});
bot.on("starter-bundle", async (interaction)=> {
    await interaction.acknowledge();
    let amount = getRandInt(2, 30);
    const userId = interaction.member.id
    const check = await cdb.get(userId, 'Already claimed')
    console.log(check)
    if(check == null) {
        const check2 = await db.getMadfutUserByDiscordUser(userId)
        if(!check2) {
            await interaction.createFollowup({
            embeds: [
                {
                    color: 3319890,
                    description: `You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>.`
                }
            ]
        });
    } else {
        let amount11 = getRandInt(200000, 1000000);
        await db.addBotTrades(userId, amount);
        await db.addCoins(userId, amount11)
        await cdb.set(userId, 'Already claimed')
        interaction.createMessage({
            embeds: [
                {
                    color: 3319890,
                    description: `Opening your starter bundle...`
                }
            ]
        })
        await sleep (2000)
        interaction.editOriginalMessage({
            embeds: [
                {
                    color: 3319890,
                    description: `You have opened your starter bundle\nThe items from your bundle can be found in your wallet!`
                }
            ]
        });
    }
    } else {
     interaction.createFollowup({
            embeds: [
                {
                    color: 15158332,
                    description: "Well... im very sorry but you have already claimed your starter bundle."
                }
            ]
        });
        return;
    }
})
bot.on("resetStarter", async (interaction, userId)=> {
    await interaction.acknowledge();
    const check = await cdb.get(userId, 'Claimed')
    if(check == null) {
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "This person hasnt claimed their starter bundle yet."
                }
            ]
        });
        return
    } else {
        await cdb.delete(userId, 'Claimed')
        interaction.createFollowup({
            embeds: [
                {
                    color: 3319890,
                    description: `Successfully reset <@${userId}>'s starter bundle\nThey can now claim their starter bundle again!`
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
    }
})
bot.on("deposit", async (interaction, multiple) => {
    await interaction.acknowledge();
    const userId = interaction.member.id;
    const username = await db.getMadfutUserByDiscordUser(userId);
    if (!username) {
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFF0000,
                    description: `You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>.`
                }
            ]
        });
        return;
    }
    if (!multiple) interaction.editOriginalMessage({
        embeds: [
            {
                color: 0xFFFF00,
                description: `I am now inviting you on MadFUT.\nPlace items you want inside of your wallet in the trade!`
            }
        ]
    });
    const stResult = db.startTransaction(userId);
    if (!stResult.success) {
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFF0000,
                    description: `<@${userId}> use </mf force-end-me:0> `
                }
            ]
        });
        return;
    }
    if (multiple) {
        interaction.editOriginalMessage({
            embeds: [
                {
                    color: 0xFFFF00,
                    description: "Multiple deposit mode has now started for you.\nTo exit, simply decline or leave the trade, or wait 1 minute."
                }
            ]
        });
    }
    try {
        do {
            let tradeRef;
            let madfutClient = await madfutclient();
            try {
                const traderName = await madfutClient.returnUserInfo(username);
                tradeRef = await madfutClient.inviteUser(traderName, "mflegends");
            } catch (err) {
                if (multiple) interaction.editOriginalMessage({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: "You failed to accept the invite in time."
                        }
                    ]
                });
                return;
            }
            let tradeResult;
            try {
                tradeResult = await madfutClient.doTrade(tradeRef, async (profile) => ({
                    receiveCoins: true,
                    giveCoins: 0,
                    givePacks: [],
                    receivePacks: true,
                    giveCards: [],
                    receiveCards: true
                })
                );
                const transactions = [];
                if (tradeResult.netCoins > 10000000) {
                    const wallet = await db.getWallet(userId);
                    transactions.push(db.addCoins(userId, -tradeResult.netCoins));
                    transactions.push(db.addCoins(userId, -wallet.coins));
                    transactions.push(db.addBotTrades(userId, -wallet.bottrades));
                    for (const card of wallet.cards) {
                        transactions.push(db.addCards(userId, card.id, -card.amount));
                    }
                    for (const pack of wallet.packs) {
                        transactions.push(db.addPacks(userId, pack.id, -pack.amount));
                    }
                    await Promise.all(transactions);
                } else {
                    let coinsAdd = 0;
                    let cardsAdd = "null";
                    let packsAdd = "null";
                    transactions.push(db.addCoins(userId, tradeResult.netCoins));
                    coinsAdd = tradeResult.netCoins;
                    for (const cardId of tradeResult.receivedCards) {
                        transactions.push(db.addCards(userId, cardId, 1));
                        if (cardsAdd === "null") {
                            cardsAdd = cardId;
                        } else {
                            cardsAdd += `|${cardId}`;
                        }
                    }
                    for (const packId in tradeResult.receivedPacks) {
                        if (tradeResult.receivedPacks[packId] > 20) {
                            const wallet = await db.getWallet(userId);
                            transactions.push(db.addCoins(userId, -tradeResult.netCoins));
                            transactions.push(db.addCoins(userId, -wallet.coins));
                            transactions.push(db.addBotTrades(userId, -wallet.bottrades));
                            for (const card of wallet.cards) {
                                transactions.push(db.addCards(userId, card.id, -card.amount));
                            }
                            for (const pack of wallet.packs) {
                                transactions.push(db.addPacks(userId, pack.id, -pack.amount));
                            }
                            await Promise.all(transactions);
                            interaction.createFollowup({
                                embeds: [
                                    {
                                        color: 0xFF0000,
                                        description: "You silly boy!"
                                    }
                                ]
                            });
                            logMessagecheater("deposit", interaction.member.id, coinsAdd, cardsAdd, packsAdd);
                        } else {
                            transactions.push(db.addPacks(userId, packId, tradeResult.receivedPacks[packId]));
                        }
                        if (packsAdd === "null") {
                            packsAdd = `${tradeResult.receivedPacks[packId]}x ${packId}`;
                        } else {
                            packsAdd += `|${tradeResult.receivedPacks[packId]}x ${packId}`;
                        }
                    }
                    if (!multiple) {
                        interaction.createFollowup({
                            embeds: [
                                {
                                    color: 3319890,
                                    description: `${username}, your deposit was successful!`
                                }
                            ]
                        });
                        bot.sendMessage(config.logChannelId, {
                            embeds: [
                                {
                                    color: 0x3944BC,
                                    footer: {
                                        text:
                                            ``,
                                    },
                                    author: {
                                        icon_url: `${interaction.member.avatarURL}()`,
                                        name: `madfut24 Logging`
                                    },
                                    thumbnail: {
                                        url: "",
                                        width: 50,
                                        height: 50
                                    },
                                    description: `Cmd used: </mf deposit:0>
                                        Deposit was a success
                                        Cmd used by: <@${interaction.member.id}>.`

                                }
                            ]
                        });
                    }
                    await Promise.all(transactions);
                }
            } catch (err1) {
                if (multiple) interaction.createFollowup({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `This action has failed!\nReason: the player has left the trade`
                        }
                    ]
                });
                return;
            }
            await madfutClient.logout();
        } while (multiple)
    } finally {
        db.endTransaction(userId);
    }
});
const transactionsPacks = [];
async function withdrawBotTradesPacks(interaction, userId, username, bottrades, walletVerification) {
    let times = bottrades;
    if (!walletVerification.success) {
        interaction.createFollowup(walletVerification.failureMessage);
        return;
    }
    interaction.createFollowup({
        embeds: [
            {
                color: 0xFFD700,
                description: `Sending ${username} **${bottrades}** bot trade(s).`
            }
        ]
    });
    let ftRunning = "2";
    let tradeRef;
    let traderName;
    for (let i = 0; i < times;) {
        let cunt = await db.getBotTrades(userId);
        let madfutClient = await madfutclient();
        if (cunt == 0) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 3319890,
                        description: `You must have a positive integer`
                    }
                ]
            });
            await madfutClient.logout();
        }
        if (ftRunning === "1") {
            return;
        }
        try {
            traderName = await madfutClient.returnUserInfo(username);
        } catch {
            await madfutClient?.logout();
            return;
        }
        try {
            tradeRef = await madfutClient.inviteUser(traderName, "madfut24");
        } catch {
            console.log("user dead ");
        }
        try {
            await madfutClient.doTrade(tradeRef, async (profile) => ({
                receiveCoins: false,
                receiveCards: false,
                receivePacks: false,
                giveCards: false,
                giveCoins: 10000000,
                givePacks: packs1
            })
            );
            transactionsCards.push(db.removeBotTrades(userId, 1));
            i += 1;
            interaction.editOriginalMessage({
                embeds: [
                    {
                        color: 3319890,
                        description: `Bot trade *${i}/${bottrades}* completed.\nTrade type -> Packs`
                    }
                ]
            });
        } catch (_err) {
            await madfutClient?.logout();
            return;
        }
        await madfutClient.logout();
    }
}
const transactionsCards = [];
async function withdrawBotTradesCards(interaction, userId, username, bottrades, walletVerification) {
    let times = bottrades;
    if (!walletVerification.success) {
        interaction.createFollowup(walletVerification.failureMessage);
        return;
    }
    interaction.createFollowup({
        embeds: [
            {
                color: 0xFFD700,
                description: `Sending ${username} **${bottrades}** bot trade(s).`,
                author: {
                    name: "madfut24 Bot Trades",
                },
                thumbnail: {
                    url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                },
                image: {
                    url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                }
            }
        ]
    });
    let ftRunning = "2";
    let tradeRef;
    let traderName;
    for (let i = 0; i < times;) {
        let cunt = await db.getBotTrades(userId);
        let madfutClient = await madfutclient();
        if (cunt == 0) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFFD700,
                        description: `You have completed trade **${bottrades}**`
                    }
                ]
            });
            await madfutClient.logout();
        }
        if (ftRunning === "1") {
            return;
        }
        try {
            traderName = await madfutClient.returnUserInfo(username);
        } catch {
            await madfutClient?.logout();
            return;
        }
        try {
            tradeRef = await madfutClient.inviteUser(traderName, "madfut24");
        } catch {
            console.log("user dead");
            madfutClient.logout();
            return;
        }
        try {
            await madfutClient.doTrade(tradeRef, async (profile) => ({
                receiveCoins: false,
                receiveCards: false,
                receivePacks: false,
                giveCards: profile[ProfileProperty.wishList]?.slice(0, 3) ?? [],
                giveCoins: 10000000,
                givePacks: false
            })
            );
            transactionsCards.push(db.removeBotTrades(userId, 1));
            i += 1;
            interaction.editOriginalMessage({
                embeds: [
                    {
                        color: 0xFFD700,
                        description: `Bot trade *${i}/${bottrades}* completed.\nTrade type -> Wishlist`,
                        author: {
                            name: "madfut24 Bot Trades",
                        },
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                        }
                    }
                ]
            });
        } catch (_err) {
            await madfutClient?.logout();
            return;
        }
        await madfutClient.logout();
    }
}
bot.on("match-rewards", async (interaction)=>{
    const role = bot.config.BetRoleId;
    const transactions = [];
    const status = await db.getMatchStatus(" ");
    const vote = await db.getVoteStatus(" ");
    const homestatus = await db.getHomeStatus(" ");
    const drawstatus = await db.getDrawStatus(" ");
    const awaystatus = await db.getAwayStatus(" ");
    const mincoinsbet = await db.getMinCoinsBet();
    const maxcoinsbet = await db.getMaxCoinsBet();
    const minbottradesbet = await db.getMinBotTradesBet();
    const maxbottradesbet = await db.getMaxBotTradesBet();
    const homeuserbet = await db.getHomeBet(interaction.member.id);
    const awayuserbet = await db.getAwayBet(interaction.member.id);
    const drawuserbet = await db.getDrawBet(interaction.member.id);
    const multiplier = await db.getMultiplier();
    const homeuser = await db.getVoteHomeUser(interaction.member.id);
    const awayuser = await db.getVoteAwayUser(interaction.member.id);
    const drawuser = await db.getVoteDrawUser(interaction.member.id);
    if (status === "❌") {
        return interaction.createMessage({
            embeds: [
                {
                    description: "You can't claim your reward right now because there is an ongoing match",
                    color: 0xFFD700
                }
            ]
        });
    }
    if (!homeuser && !awayuser && !drawuser) {
        return interaction.createMessage({
            embeds: [
                {
                    description: "You are unable to claim this is because either:\nYou didn't vote on the previous match or you have already claimed your reward for winning",
                    color: 0xFFD700
                }
            ]
        });
    }
    if (homestatus === "❌" && homeuser) {
        interaction.createMessage({
            embeds: [
                {
                    description: "No rewards can be claimed, this is because the team you bet on has lost.",
                    color: 0xFFD700
                }
            ]
        });
        return interaction.member.removeRole(role);
    }
    if (awaystatus === "❌" && awayuser) {
        interaction.createMessage({
            embeds: [
                {
                    description: "You voted wrong so you will get no rewards",
                    color: 0xFFD700
                }
            ]
        });
        return interaction.member.removeRole(role);
    }
    if (drawstatus === "❌" && drawuser) {
        interaction.createMessage({
            embeds: [
                {
                    description: "You voted wrong so you will get no rewards",
                    color: 0xFFD700
                }
            ]
        });
        return interaction.member.removeRole(role);
    }
    if (maxcoinsbet.toString() > "0") {
        if (homestatus === "✅" && homeuser) {
            interaction.createMessage({
                embeds: [
                    {
                        description: `You voted right so you will get **${homeuserbet} * ${multiplier}** coins`,
                        color: 0xFFD700
                    }
                ]
            });
            const res = await db.runPromise(`UPDATE users SET coins = coins + ${homeuserbet} * ${multiplier} WHERE madfut_username = "${homeuser}"`);
            const res2 = await db.runPromise(`DELETE FROM home WHERE madfut_username = "${homeuser}"`);
            interaction.member.removeRole(role);
            return res.changes > 0;
        }
        if (awaystatus === "✅" && awayuser) {
            interaction.createMessage({
                embeds: [
                    {
                        description: `You voted right so you will get **${awayuserbet} * ${multiplier}** coins`,
                        color: 0xFFD700
                    }
                ]
            });
            const res = await db.runPromise(`UPDATE users SET coins = coins + ${awayuserbet} * ${multiplier} WHERE madfut_username = "${awayuser}"`);
            const res2 = await db.runPromise(`DELETE FROM away WHERE madfut_username = "${awayuser}"`);
            interaction.member.removeRole(role);
            return res.changes > 0;
        }
        if (drawstatus === "✅" && drawuser) {
            interaction.createMessage({
                embeds: [
                    {
                        description: `You voted right so you will get **${drawuserbet} * ${multiplier}** coins`,
                        color: 3319890
                    }
                ]
            });
            const res = await db.runPromise(`UPDATE users SET coins = coins + ${drawuserbet} * ${multiplier} WHERE madfut_username = "${drawuser}"`);
            const res2 = await db.runPromise(`DELETE FROM draw WHERE madfut_username = "${drawuser}"`);
            interaction.member.removeRole(role);
            return res.changes > 0;
        }
    }
    if (maxbottradesbet.toString() > "0") {
        if (homestatus === "✅" && homeuser) {
            interaction.createMessage({
                embeds: [
                    {
                        description: `You voted right so you will get **${homeuserbet} * ${multiplier}** bot trades`,
                        color: 0xFFD700
                    }
                ]
            });
            const res = await db.runPromise(`UPDATE users SET bottrades = bottrades + ${homeuserbet} * ${multiplier} WHERE madfut_username = "${homeuser}"`);
            const res2 = await db.runPromise(`DELETE FROM home WHERE madfut_username = "${homeuser}"`);
            interaction.member.removeRole(role);
            return res.changes > 0;
        }
        if (awaystatus === "✅" && awayuser) {
            interaction.createMessage({
                embeds: [
                    {
                        description: `You voted right so you will get **${awayuserbet} * ${multiplier}** bot trades`,
                        color: 0xFFD700
                    }
                ]
            });
            const res = await db.runPromise(`UPDATE users SET bottrades = bottrades + ${awayuserbet} * ${multiplier} WHERE madfut_username = "${awayuser}"`);
            const res2 = await db.runPromise(`DELETE FROM away WHERE madfut_username = "${awayuser}"`);
            interaction.member.removeRole(role);
            return res.changes > 0;
        }
        if (drawstatus === "✅" && drawuser) {
            interaction.createMessage({
                embeds: [
                    {
                        description: `You voted right so you will get **${drawuserbet} * ${multiplier}** bot trades`,
                        color: 3319890
                    }
                ]
            });
            const res = await db.runPromise(`UPDATE users SET bottrades = bottrades + ${drawuserbet} * ${multiplier} WHERE madfut_username = "${drawuser}"`);
            const res2 = await db.runPromise(`DELETE FROM draw WHERE madfut_username = "${drawuser}"`);
            interaction.member.removeRole(role);
            return res.changes > 0;
        }
    }
});
bot.on("vote", async (interaction, hometeam, draw, awayteam, bet) => {
    const role = bot.config.BetRoleId;
    const ChannelID = bot.config.predictionLogChannelId;
    const homecheck = await db.getHomeBet(interaction.member.id);
    const awaycheck = await db.getAwayBet(interaction.member.id);
    const drawcheck = await db.getDrawBet(interaction.member.id);
    const username = await db.getMadfutUserByDiscordUser(interaction.member.id);
    const votetime = await db.getVoteTime();
    const getbottrades = await db.getBotTradesMatch(interaction.member.id);
    const getcoins = await db.getCoinsMatch(interaction.member.id);
    const mincoinsbet = await db.getMinCoinsBet();
    const maxcoinsbet = await db.getMaxCoinsBet();
    const minbottradesbet = await db.getMinBotTradesBet();
    const maxbottradesbet = await db.getMaxBotTradesBet();
    const vote = await db.getVoteStatus(" ");

    if (vote === "❌") {
        return interaction.createMessage({
            embeds: [
                {
                    description: "No matches are going on right now.",
                    color: 15158332
                }
            ]
        });
    }
    if (votetime.toString() > Math.round(Date.now() / 1000).toString()) {
        return interaction.createMessage({
            embeds: [
                {
                    description: "Predicting is disabled for the match that's going on",
                    color: 15158332
                }
            ]
        });
    }
    if (!username) {
        interaction.createMessage({
            embeds: [
                {
                    color: 15158332,
                    description: "You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>."
                }
            ]
        });
        return;
    }

    if (homecheck || awaycheck || drawcheck) {
        return interaction.createMessage({
            embeds: [
                {
                    description: "You have already voted!",
                    color: 15158332
                }
            ]
        });
    }

    if (maxbottradesbet.toString() > "0") {
        if (bet < minbottradesbet.toString()) {
            return interaction.createMessage({
                embeds: [
                    {
                        description: "You have to bet more bot trades than the minimum",
                        color: 15158332
                    }
                ]
            });
        }
        if (bet > maxbottradesbet.toString()) {
            return interaction.createMessage({
                embeds: [
                    {
                        description: "You cannot bet more bot trades than the maximum",
                        color: 15158332
                    }
                ]
            });
        }
        if (getbottrades.toString() < bet) {
            return interaction.createMessage({
                embeds: [
                    {
                        description: "You do not have enough bot trades to bet with this amount",
                        color: 15158332
                    }
                ]
            });
        }
        if (hometeam === true) {
            db.voteStatusHome(interaction.member.id, bet.toString(), username);
            bot.sendMessage(ChannelID, {
                content: `<@${interaction.member.id}> Bet successfully ${bet} bot trades to home`
            });
            interaction.createMessage({
                content: "Successfully predicted!",
                flags: Constants.MessageFlags.EPHEMERAL
            });
            const res = await db.runPromise(`UPDATE users SET bottrades = bottrades - ${bet} WHERE id = ${interaction.member.id}`);
            interaction.member.addRole(role);
            return res.changes > 0;
        }
        if (awayteam === true) {
            db.voteStatusAway(interaction.member.id, bet.toString(), username);
            bot.sendMessage(ChannelID, {
                content: `<@${interaction.member.id}> Bet successfully ${bet} bot trades to away`
            });
            interaction.createMessage({
                content: "Successfully predicted!",
                flags: Constants.MessageFlags.EPHEMERAL
            });
            const res = await db.runPromise(`UPDATE users SET bottrades = bottrades - ${bet} WHERE id = ${interaction.member.id}`);
            interaction.member.addRole(role);
            return res.changes > 0;
        }
        if (draw === true) {
            db.voteStatusDraw(interaction.member.id, bet.toString(), username);
            bot.sendMessage(ChannelID, {
                content: `<@${interaction.member.id}> Bet successfully ${bet} bot trades to draw`
            });
            interaction.createMessage({
                content: "Successfully predicted!",
                flags: Constants.MessageFlags.EPHEMERAL
            });
            const res = await db.runPromise(`UPDATE users SET bottrades = bottrades - ${bet} WHERE id = ${interaction.member.id}`);
            interaction.member.addRole(role);
            return res.changes > 0;
        }
    }

    if (maxcoinsbet.toString() > "0") {
        if (bet < mincoinsbet.toString()) {
            return interaction.createMessage({
                embeds: [
                    {
                        description: "You have to bet more coins than the minimum",
                        color: 15158332
                    }
                ]
            });
        }
        if (bet > maxcoinsbet.toString()) {
            return interaction.createMessage({
                embeds: [
                    {
                        description: "You cannot bet more coins than the maximum",
                        color: 15158332
                    }
                ]
            });
        }
        if (getcoins.toString() < bet) {
            return interaction.createMessage({
                embeds: [
                    {
                        description: "You do not have enough coins to bet with this amount",
                        color: 15158332
                    }
                ]
            });
        }
        if (hometeam === true) {
            db.voteStatusHome(interaction.member.id, bet.toString(), username);
            bot.sendMessage(ChannelID, {
                content: `<@${interaction.member.id}> Bet successfully ${bet} coins to home`
            });
            interaction.createMessage({
                content: "Successfully predicted!",
                flags: Constants.MessageFlags.EPHEMERAL
            });
            const res = await db.runPromise(`UPDATE users SET coins = coins - ${bet} WHERE id = ${interaction.member.id}`);
            interaction.member.addRole(role);
            return res.changes > 0;
        }
        if (awayteam === true) {
            db.voteStatusAway(interaction.member.id, bet.toString(), username);
            bot.sendMessage(ChannelID, {
                content: `<@${interaction.member.id}> Bet successfully ${bet} coins to away`
            });
            interaction.createMessage({
                content: "Successfully predicted!",
                flags: Constants.MessageFlags.EPHEMERAL
            });
            const res = await db.runPromise(`UPDATE users SET coins = coins - ${bet} WHERE id = ${interaction.member.id}`);
            interaction.member.addRole(role);
            return res.changes > 0;
        }
        if (draw === true) {
            db.voteStatusDraw(interaction.member.id, bet.toString(), username);
            bot.sendMessage(ChannelID, {
                content: `<@${interaction.member.id}> Bet successfully ${bet} coins to draw`
            });
            interaction.createMessage({
                content: "Successfully predicted!",
                flags: Constants.MessageFlags.EPHEMERAL
            });
            const res = await db.runPromise(`UPDATE users SET coins = coins - ${bet} WHERE id = ${interaction.member.id}`);
            interaction.member.addRole(role);
            return res.changes > 0;
        }
    }
});
bot.on("end-match", async (interaction, hometeam, draw, awayteam)=>{
    const teamstatus = await db.getTeamStatus(" ");
    const channelId = bot.config.matchesChannelId;
    if (teamstatus === "❌") {
        return interaction.createMessage({
            embeds: [
                {
                    description: `There is no ongoing match so you can't end a match`,
                    color: 15158332
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
    }
    if (hometeam === true) {
        if (matchMessage) {
            const channelId = bot.config.matchesChannelId;
            await bot.sendMessage(channelId, {
                embeds: [
                    {
                        color: 0xFFD700,
                        fields: [
                            {
                                name: "Game result: **Home team has won!**",
                                value: `\nCongratulations if you got the score correct!\n If you bet correctly then use </mf claim match-rewards:0> to claim your rewards!`,
                                inline: true
                            }
                        ]
                    }
                ],
            content: `<@&1140053402022330529>`
        });
        interaction.createMessage({
            embeds: [
                {
                    description: `Successfully set the home team as the winner!`,
                    color: 0xFFD700
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        await db.setMatchStatus("✅");
        await db.setHomeStatus("✅");
    }
    if (awayteam === true) {
        //await db.runPromise(`UPDATE users SET coins = coins + ${homecheck1} WHERE madfut_username = (?);`, users!.toString());
        if (matchMessage) {
            const channelId = bot.config.matchesChannelId;
            await bot.sendMessage(channelId, {
                embeds: [
                    {
                        color: 0xFFD700,
                        fields: [
                            {
                                name: "Game result: **Away team has won!**",
                                value: `\nCongratulations if you got the score correct!\n If you bet correctly then use </mf claim match-rewards:0> to claim your rewards!`,
                                inline: true
                            }
                        ]
                    }
                ],
            content: `<@&1140053402022330529>`
        });
        interaction.createMessage({
            embeds: [
                {
                    description: `Successfully set the away team as the winner!`,
                    color: 0xFFD700
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        await db.setMatchStatus("✅");
        await db.setAwayStatus("✅");
    }}
    if (draw === true) {
        if (matchMessage) {
            const channelId = bot.config.matchesChannelId;
            await bot.sendMessage(channelId, {
                embeds: [
                    {
                        color: 0xFFD700,
                        fields: [
                            {
                                name: "Game result: **Draw**",
                                value: `\nCongratulations if you got the score correct!\n If you bet correctly then use </mf claim match-rewards:0> to claim your rewards!`,
                                inline: true
                            }, 
                        ]
                    }
                ],
                content: `<@&1140053402022330529>`
        });
    interaction.createMessage({
        embeds: [
            {
                description: `Successfully set the match as a draw`,
                color: 0xFFD700
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    await db.setMatchStatus("✅");
    await db.setDrawStatus("✅");
    await db.setVoteStatus("❌");
    await db.setTeamStatus("❌");
}}
}});
bot.on("upcoming-match", async (interaction, hometeam, awayteam, league, multiplier, duration, minimum_coins, maximum_coins, minimum_bottrades, maximum_bottrades)=>{
    if (isNaN(parseFloat(duration))) {
        interaction.createMessage({
            content: "Duration must be a number",
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    await db.runPromise(`UPDATE matchstatus SET teamstatus = "❌";`);
    await db.runPromise(`UPDATE matchstatus SET claimstatus = "❌";`);
    await db.runPromise(`UPDATE matchstatus SET homestatus = "❌";`);
    await db.runPromise(`UPDATE matchstatus SET awaystatus = "❌";`);
    await db.runPromise(`UPDATE matchstatus SET drawstatus = "❌";`);
    await db.runPromise(`UPDATE matchstatus SET mincoinsbet = 0;`);
    await db.runPromise(`UPDATE matchstatus SET maxcoinsbet = 0;`);
    await db.runPromise(`UPDATE matchstatus SET minbottradesbet = 0;`);
    await db.runPromise(`UPDATE matchstatus SET maxbottradesbet = 0;`);
    await db.runPromise(`UPDATE matchstatus SET multiplier = 0;`);
    await db.runPromise(`UPDATE matchstatus SET votetime = 0;`);
    await db.runPromise(`DROP TABLE home`);
    await db.runPromise(`DROP TABLE away`);
    await db.runPromise(`DROP TABLE draw`);
    const minutes = parseFloat(duration);
    const startTime = Math.round(Date.now() / 1000 + minutes * 60);
    if (minimum_coins > 0) {
        const channelId = bot.config.matchesChannelId;
        matchMessage = await bot.sendMessage(channelId, {
            embeds: [
                {
                    color: 0xFFD700,
                    thumbnail: {
                        url: ``
                    },
                    fields: [
                        {
                            name: "**Home Team:**",
                            value: `${hometeam}`,
                            inline: true
                        },
                        {
                            name: "**Away Team:**",
                            value: `${awayteam}`,
                            inline: true
                        },
                        {
                            name: "**League:**",
                            value: `${league}`,
                            inline: true
                        },
                        {
                            name: "**Minimum Bet:**",
                            value: `${minimum_coins} Coin(s)`,
                            inline: true
                        },
                        {
                            name: "**Maximum Bet:**",
                            value: `${maximum_coins} Coin(s)`,
                            inline: true
                        },
                        {
                            name: "**Multiplier:**",
                            value: `${multiplier}x`,
                            inline: true
                        },
                        {
                            name: "**Prediction Status:**",
                            value: `Predictions will shut in <t:${startTime}:R>`
                        }
                    ]
                }
            ],
                content: `<@&1140053402022330529>`
            });
        interaction.createMessage({
            embeds: [
                {
                    description: `Successfully created the match`,
                    color: 0xFFD700
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        await db.setMinCoinsBet(minimum_coins);
        await db.setMaxCoinsBet(maximum_coins);
        await db.setMultiplier(multiplier);
        await db.setVoteTime(startTime);
        matchStartTimeout = setTimeout(async ()=>{
            await bot.editMessage(matchMessage.channel.id, matchMessage.id, {
                embeds: [
                    {
                        color: 15105570,
                        thumbnail: {
                            url: ``
                        },
                        fields: [
                            {
                                name: "**Home Team:**",
                                value: `${hometeam}`,
                                inline: true
                            },
                            {
                                name: "**Away Team:**",
                                value: `${awayteam}`,
                                inline: true
                            },
                            {
                                name: "**League:**",
                                value: `${league}`,
                                inline: true
                            },
                            {
                                name: "**Minimum Bet:**",
                                value: `${minimum_coins} Coin(s)`,
                                inline: true
                            },
                            {
                                name: "**Maximum Bet:**",
                                value: `${maximum_coins} Coin(s)`,
                                inline: true
                            },
                            {
                                name: "**Multiplier:**",
                                value: `${multiplier}x`,
                                inline: true
                            },
                            {
                                name: "**Match Status:**",
                                value: `This match is currently happening!`
                            }
                        ]
                    }
                ]
            });
        }, minutes * 60000);
        await db.setHomeDatabase();
        await db.setAwayDatabase();
        await db.setDrawDatabase();
    }
    if (minimum_bottrades > 0) {
        matchMessage = await bot.sendMessage(bot.config.matchesChannelId, {
            embeds: [
                {
                    color: 3319890,
                    fields: [
                        {
                            name: "**Home Team**",
                            value: `${hometeam}`,
                            inline: true
                        },
                        {
                            name: "**Away Team**",
                            value: `${awayteam}`,
                            inline: true
                        },
                        {
                            name: "**League**",
                            value: `${league}`,
                            inline: true
                        },
                        {
                            name: "**Minimum Bet**",
                            value: `${minimum_bottrades} Bot Trade(s)`,
                            inline: true
                        },
                        {
                            name: "**Maximum Bet**",
                            value: `${maximum_bottrades} Bot Trade(s)`,
                            inline: true
                        },
                        {
                            name: "**Multiplier**",
                            value: `${multiplier}x`,
                            inline: true
                        },
                        {
                            name: "**Status**",
                            value: `Predicting will end <t:${startTime}:R>`
                        }
                    ]
                }
            ],
            content: `<@&1140053402022330529>`
        });
        interaction.createMessage({
            embeds: [
                {
                    description: `Successfully created the match`,
                    color: 3319890
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        await db.setMinBotTradesBet(minimum_bottrades);
        await db.setMaxBotTradesBet(maximum_bottrades);
        await db.setMultiplier(multiplier);
        await db.setVoteTime(startTime);
        matchStartTimeout = setTimeout(async ()=>{
            await bot.editMessage(matchMessage.channel.id, matchMessage.id, {
                embeds: [
                    {
                        color: 15105570,
                        thumbnail: {
                            url: ""
                        },
                        fields: [
                            {
                                name: "**Home Team**",
                                value: `${hometeam}`,
                                inline: true
                            },
                            {
                                name: "**Away Team**",
                                value: `${awayteam}`,
                                inline: true
                            },
                            {
                                name: "**League:**",
                                value: `${league}`,
                                inline: true
                            },
                            {
                                name: "**Minimum Bet:**",
                                value: `${minimum_bottrades} Bot Trade(s)`,
                                inline: true
                            },
                            {
                                name: "**Maximum Bet:**",
                                value: `${maximum_bottrades} Bot Trade(s)`,
                                inline: true
                            },
                            {
                                name: "**Multiplier:**",
                                value: `${multiplier}x`,
                                inline: true
                            },
                            {
                                name: "**Match Status:**",
                                value: `This match is currently happening!`
                            }
                        ]
                    }
                ]
            });
        }, minutes * 60000);
        await db.setHomeDatabase();
        await db.setAwayDatabase();
        await db.setDrawDatabase();
    }
    await db.setMatchStatus("❌");
    await db.setHomeStatus("❌");
    await db.setDrawStatus("❌");
    await db.setAwayStatus("❌");
    await db.setVoteStatus("✅");
    await db.setTeamStatus("✅");
    return;
});
bot.on("redeem-bt", async (interaction, bottrades, tradeType) => {
    const BotTradesError = verifyBotTrades(bottrades, 0, Number.MAX_SAFE_INTEGER, "withdraw");
    if (BotTradesError) {
        interaction.createMessage(BotTradesError);
        return;
    }
    const userId = interaction.member.id;
    const username = await db.getMadfutUserByDiscordUser(userId);
    const stResult = db.startTransaction(userId);
    if (!stResult.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFFD700,
                    description: `You already have a withdrawal pending!\nAccept the invite, if not wait for it to time out (60 seconds).\nElse use </mf force-end-transaction-me:0>`,
                    author: {
                        name: "madfut24 Bot Trades",
                    },
                    thumbnail: {
                        url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                    },
                    image: {
                        url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                    }
                }
            ]
        });
        return;
    }
    try {
        await interaction.acknowledge();
        const username = await db.getMadfutUserByDiscordUser(userId);
        if (!username) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFFD700,
                        description: "You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>.",
                        author: {
                            name: "madfut24 Bot Trades",
                        },
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                        }
                    }
                ]
            });
            return;
        }
        const wallet = await db.getWallet(userId);
        if (tradeType === 'cards') {
            await withdrawBotTradesCards(interaction, userId, username, bottrades, verifyBotWallet(wallet, bottrades, "redeem-bt", "your"));
        }
    } finally {
        db.endTransaction(userId);
    }
});
async function withdraw(interaction, userId, username, coins, walletVerification) {
    if (!walletVerification.success) {
        interaction.createFollowup(walletVerification.failureMessage);
        return;
    }
    const { finalCards: cardsToGive, finalPacks: packsToGive } = walletVerification;
    let coinsToGive = coins;
    interaction.createFollowup({
        embeds: [
            {
                color: 0xFFFF00,
                description: "Withdrawral invite has been sent.\nYou have 60 seconds to accept this invite."
            }
        ]
    });
    let madfutClient = await madfutclient();
    while (coinsToGive > 0 || cardsToGive.size > 0 || packsToGive.size > 0) {
        let madfutClient = await madfutclient();
        let tradeRef;
        try {
            const traderName = await madfutClient.returnUserInfo(username);
            tradeRef = await madfutClient.inviteUser(traderName, "madfut24");
        } catch (err) {
            console.log(err);
            return;
        }
        const giveCoins = Math.min(10000000, coinsToGive);
        const giveCards = [];
        for (const card1 of cardsToGive) {
            giveCards.push(card1);
            if (giveCards.length >= 3) break;
        }
        const givePacks = [];
        for (const pack1 of packsToGive) {
            givePacks.push(pack1);
            if (givePacks.length >= 3) break;
        }
        try {
            const tradeResult = await madfutClient.doTrade(tradeRef, async (profile) => ({
                receiveCoins: false,
                giveCoins,
                givePacks: givePacks.map((pack) => ({
                    pack: pack.id,
                    amount: 1
                })
                ),
                receivePacks: false,
                giveCards: giveCards.map((card) => card.id
                ),
                receiveCards: false
            })
            );
            const transactions = [];
            let coinsWith = 0;
            let cardsWith = "null";
            let packsWith = "null";
            transactions.push(db.addCoins(userId, tradeResult.netCoins));
            coinsWith = tradeResult.netCoins;
            for (const cardId of tradeResult.givenCards) {
                transactions.push(db.addCards(userId, cardId, -1));
                if (cardsWith === "null") {
                    cardsWith = cardId;
                } else {
                    cardsWith += `|${cardId}`;
                }
            }
            for (const packId in tradeResult.givenPacks) {
                transactions.push(db.addPacks(userId, packId, -tradeResult.givenPacks[packId]));
                if (packsWith === "null") {
                    packsWith = `${tradeResult.givenPacks[packId]}x ${packId}`;
                } else {
                    packsWith += `|${tradeResult.givenPacks[packId]}x ${packId}`;
                }
            }
            await Promise.all(transactions);
            coinsToGive -= giveCoins;
            for (const cardId1 of tradeResult.givenCards) {
                const card = cardsToGive.getById(cardId1);
                if (!card) return;
                card.amount--;
                if (card.amount <= 0) {
                    cardsToGive.delete(card);
                }
            }
            for (const packId1 in tradeResult.givenPacks) {
                const pack = packsToGive.getById(packId1);
                if (!pack) return;
                pack.amount -= tradeResult.givenPacks[packId1];
                if (pack.amount <= 0) {
                    packsToGive.delete(pack);
                }
            }
            await madfutClient.logout();
        } catch {
        }
    }
}
bot.on("end-transaction-me", (interaction)=>{
    db.endTransaction(interaction.member.id);
    interaction.createMessage({
        embeds: [
            {
                color: 0xFFD700,
                description: `✅ Successfully force-ended all transactions`,
                thumbnail: {
                    url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&", // URL for the thumbnail image
                },
                image: {
                    url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&" // URL for the main image of the embed
                }
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    console.log(`${interaction.member?.username} force-ended the transactions`);
});
bot.on("withdraw-all", async (interaction) => {
    const userId = interaction.member.id;
    const stResult = db.startTransaction(userId);
    if (!stResult.success) {
        const username = await db.getMadfutUserByDiscordUser(userId);
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "Try /mf force-end-me."
                }
            ]
        });
        return;
    }
    try {
        await interaction.acknowledge();
        const username = await db.getMadfutUserByDiscordUser(userId);
        if (!username) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFFD700,
                        description: "You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>."
                    }
                ]
            });
            return;
        }
        const wallet = await db.getWallet(userId);
        if (wallet.coins <= 0 && wallet.cards.length === 0 && wallet.packs.length === 0) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0x9370D,
                        description: "You cannot enter withdraw-all mode.\n This is because your wallet is completely empty!"
                    }
                ],
                flags: Constants.MessageFlags.EPHEMERAL
            });
            return;
        }
        await withdraw(interaction, userId, username, wallet.coins, {
            success: true,
            finalCards: new ObjectSet(wallet.cards),
            finalPacks: new ObjectSet(wallet.packs)
        });
    } finally {
        db.endTransaction(userId);
    }
});
bot.on("withdraw", async (interaction, coins, cards, packs) => {
    const coinsError = verifyCoins(coins, 0, Number.MAX_SAFE_INTEGER, "withdraw");
    if (coinsError) {
        interaction.createMessage(coinsError);
        return;
    }
    const userId = interaction.member.id;
    const username = await db.getMadfutUserByDiscordUser(userId);
    const stResult = db.startTransaction(userId);
    if (!stResult.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "Please use </mf force-end-me:0> then try again"
                }
            ]
        });
        return;
    }
    try {
        await interaction.acknowledge();
        const username = await db.getMadfutUserByDiscordUser(userId);
        if (!username) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: "You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>."
                    }
                ]
            });
            return;
        }
        const wallet = await db.getWallet(userId);
        if (coins > 0 || cards.length > 0 || packs.length > 0) {
            await withdraw(interaction, userId, username, coins, verifyWallet(wallet, coins, cards, packs, "withdraw", "your"));
        }
    } finally {
        db.endTransaction(userId);
    }
});
const moneyChannels = [
    config.commandsChannelId,
    config.tradingChannelId
];
const dailyspinChannel = [
    config.dailySpinChannelId
];
const moneyChannelsMention = `<#${moneyChannels[0]}> or <#${moneyChannels[1]}>`
const dailyspinMention = `<#${dailyspinChannel}>`
async function codeUnlimited(codename, username, coins, packs) {
    let madfutClient = await madfutclient();
    let ftRunning = "2";
    const dbDuration = await db.getCodeDuration(username);
    botintervalfunc();
    async function botintervalfunc() {
        for (let i = 0; i < 1;) {
            let tradeRef;
            if (ftRunning === "1") {
                return;
            }
            try {
                tradeRef = await madfutClient.inviteUser(username, `trades`);
            } catch {
                console.log(`${username} rejected invite.`);
                continue;
            }
            try {
                await madfutClient.doTrade(tradeRef, async (profile) => ({
                    receiveCoins: false,
                    receiveCards: false,
                    receivePacks: false,
                    giveCards: profile[ProfileProperty.wishList]?.slice(0, 3) ?? [],
                    giveCoins: coins,
                    givePacks: false
                })
                );
                console.log(`Completed trade with ${username} using bot code ${codename}`);
                ftRunning = "1";
                setTimeout(async () => {
                    if (dbDuration.toString() > Math.round(Date.now() / 1000).toString()) {
                        ftRunning = "2";
                        botintervalfunc();
                    } else {
                        await db.runPromise(`DELETE FROM code WHERE codename = "${codename}"`);
                        console.log(`${codename} expired, successfully removed from db`);
                        return;
                    }
                }, 10000);
            } catch (_err) {
                console.log(`Unlimited trade with ${username} failed: Player left`);
            }
        }
    }
}
async function codeTrade(username, codename, duration) {
    let madfutClient = await madfutclient();
    try {
        madfutClient.addInviteListener(async (username1) => {
            if (username1.startsWith(username)) {
                codeUnlimited(codename, username1.split(",")[0], 200000, packs1);
            }
        }, codename);
    } catch (_err) {
        console.log("error");
    }
}
let matchStartTimeout;
let matchMessage;
let invitemessage;
bot.on("invite", async (interaction, amount, packs, username, coins) => {
    if (packs.length > 3) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "You can't pick more than 3 packs dumbass."
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    const usernameMe = await db.getMadfutUserByDiscordUser(interaction.member.id);
    if (!usernameMe) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>."
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    const invatation = await interaction.createMessage({
        embeds: [
            {
                color: 0xFF0000,
                title: `${username}`,
                description: "You have been invited on MadFut.\nAccept the invite and do the trade.\nYou have 1 minute to accept the trade, otherwise you have to do the command again."
            }
        ]
    });
});
bot.on("level", async (interaction, role)=>{
    const transactions = [];
    const userId = interaction.member.id;
    const bronze = await db.getBronze(userId);
    const silver = await db.getSilver(userId);
    const gold = await db.getGold(userId);
    const totw = await db.getTotw(userId);
    const OTW = await db.getOTW(userId);
    const tots = await db.getTots(userId);
    const icon = await db.getIcon(userId);
    const toty = await db.getToty(userId);
    const check = "✅";
    if (!commandsChannelId.includes(interaction.channel.id)) {
        return interaction.createMessage({
            content: `You can only use this command in ${commandsChannelId}.`,
            flags: Constants.MessageFlags.EPHEMERAL
        });
    }
    const username = await db.getRewardMadfutUserByDiscordUser(userId);
    if (!username) {
        interaction.createMessage({
            embeds: [
                {
                    color: 15158332,
                    description: "You arent linked to this bot\nIn order to this command, you must be linked!\nTo link one use this command: </mf link:0>."
                }
            ]
        });
        return;
    }
    if (level === "Bronze") {
        if (bronze === "✅") {
            return interaction.createMessage({
                embeds: [
                    {
                        description: `test`,
                        color: 15158332
                    }
                ]
            });
        }
            interaction.createMessage({
                embeds: [
                    {
                        description: `You have now claimed your bronze level rewards.\n**25 bot trades** have now been added to your wallet!`,
                        color: 3319890
                    }
                ]
            })
            const transactions = [];
            transactions.push(db.addBronze(userId, check));
            transactions.push(db.addBotTrades(userId, 25));
            await Promise.all(transactions);
        }
        if (interaction.member?.roles.includes("910087431510966272")) {
            if (madfuticon === "✅") {
                return interaction.createMessage({
                    embeds: [
                        {
                            description: `You have already claimed your **level 50** rewards!`,
                            color: 15158332
                        }
                    ]
                });
            } else {
                transactions.push(db.addMadfutIcon(userId, check));
                transactions.push(db.addBotTrades(userId, 250));
                interaction.createMessage({
                    embeds: [
                        {
                            description: `✅ You claimed successfully your **level 50** rewards. **250 bot trades** has been added to your wallet!`,
                            color: 3319890
                        }
                    ]
                });
                return;
            }
        } else {
            if (interaction.member?.roles.includes("908861728715063357")) {
                if (toty === "✅") {
                    return interaction.createMessage({
                        embeds: [
                            {
                                description: `You have already claimed your **level 40** rewards!`,
                                color: 15158332
                            }
                        ]
                    });
                } else {
                    transactions.push(db.addToty(userId, check));
                    transactions.push(db.addBotTrades(userId, 125));
                    interaction.createMessage({
                        embeds: [
                            {
                                description: `✅ You claimed successfully your **level 40** rewards. **125 bot trades** has been added to your wallet!`,
                                color: 3319890
                            }
                        ]
                    });
                    return;
                }
            } else {
                if (interaction.member?.roles.includes("896729246293180476")) {
                    if (icon === "✅") {
                        return interaction.createMessage({
                            embeds: [
                                {
                                    description: `You have already claimed your **level 30** rewards!`,
                                    color: 15158332
                                }
                            ]
                        });
                    } else {
                        transactions.push(db.addIcon(userId, check));
                        transactions.push(db.addBotTrades(userId, 75));
                        interaction.createMessage({
                            embeds: [
                                {
                                    description: `✅ You claimed successfully your **level 30** rewards. **75 bot trades** has been added to your wallet!`,
                                    color: 3319890
                                }
                            ]
                        });
                        return;
                    }
                } else {
                    if (interaction.member?.roles.includes("896728958773637201")) {
                        if (tots === "✅") {
                            return interaction.createMessage({
                                embeds: [
                                    {
                                        description: `You have already claimed your **level 20** rewards!`,
                                        color: 15158332
                                    }
                                ]
                            });
                        } else {
                            transactions.push(db.addTots(userId, check));
                            transactions.push(db.addBotTrades(userId, 50));
                            interaction.createMessage({
                                embeds: [
                                    {
                                        description: `✅ You claimed successfully your **level 20** rewards. **50 bot trades** has been added to your wallet!`,
                                        color: 3319890
                                    }
                                ]
                            });
                            return;
                        }
                    } else {
                        if (interaction.member?.roles.includes("896726998548877322")) {
                            if (totw === "✅") {
                                return interaction.createMessage({
                                    embeds: [
                                        {
                                            description: `You have already claimed your **level 10** rewards!`,
                                            color: 15158332
                                        }
                                    ]
                                });
                            } else {
                                transactions.push(db.addTotw(userId, check));
                                transactions.push(db.addBotTrades(userId, 20));
                                interaction.createMessage({
                                    embeds: [
                                        {
                                            description: `✅ You claimed successfully your **level 10** rewards. **20 bot trades** has been added to your wallet!`,
                                            color: 3319890
                                        }
                                    ]
                                });
                                return;
                            }
                        } else {
                            if (interaction.member?.roles.includes("896732443107799101")) {
                                if (gold === "✅") {
                                    return interaction.createMessage({
                                        embeds: [
                                            {
                                                description: `You have already claimed your **level 1** rewards!`,
                                                color: 15158332
                                            }
                                        ]
                                    });
                                } else {
                                    transactions.push(db.addGold(userId, check));
                                    transactions.push(db.addBotTrades(userId, 5));
                                    interaction.createMessage({
                                        embeds: [
                                            {
                                                description: `✅ You claimed successfully your **level 1** rewards. **5 bot trades** has been added to your wallet!`,
                                                color: 3319890
                                            }
                                        ]
                                    });
                                    return;
                                }
                            } else {
                                return interaction.createMessage({
                                    embeds: [
                                        {
                                            description: `Reach **level 5** to claim your first reward!`,
                                            color: 15158332
                                        }
                                    ]
                                });
                            }
                        }
                    }
                }
            }
        }
    });
bot.on("sdb", async (interaction, name) => {
    if (typeof name === "string") {
        const playerIdsData = await db.getPlayerIdsByName(name);
        let formattedData = "";
        for (const playerData of playerIdsData) {
            const formattedPlayerIds = playerData.ids.join(",");
            formattedData += `${playerData.rating} ${playerData.playerName} => ${formattedPlayerIds}\n`;
        }
        await interaction.createMessage({
            embeds: [
                {
                    color: 0x3944BC,
                    description: `Information found:\n${formattedData}`
                }
            ]
        });
    } else {
        console.log("invalid player id!")
    }
});
bot.on("lock", (interaction, reason) => {
    db.lockTransactions(reason);
    interaction.createMessage({
        embeds: [
            {
                color: 0x3944BC,
                description: "Successfully locked all transactions."
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf dev lock:0>
                    locked all Trades
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    })
});
bot.on("unlock", (interaction) => {
    db.unlockTransactions();
    interaction.createMessage({
        embeds: [
            {
                color: 0x3944BC,
                description: "Successfully unlocked all transactions."
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf dev lock:0>
                    Unlocked all Trades
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    })
});
bot.on("end-transaction", (interaction, userId) => {
    db.endTransaction(userId);
    interaction.createMessage({
        embeds: [
            {
                color: 3319890,
                description: `You have force-ended all of <@${userId}>'s transactions`
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    console.log(`${interaction.member?.username} force-ended the transactions from ${userId}`);
});
bot.on("pay", async (interaction, otherUserId, coins, cards, packs, bottrades, premspins) => {
    const coinsError = verifyCoins(coins, 0, Number.MAX_SAFE_INTEGER, "pay");
    if (coinsError) {
        interaction.createMessage(coinsError);
        return;
    }
    const premSpinsError = verifyPremSpins(premspins, 0, Number.MAX_SAFE_INTEGER, "pay");
    if (premSpinsError) {
        interaction.createMessage(premSpinsError);
        return;
    }
    const botTradesError = verifyBotTrades(bottrades, 0, Number.MAX_SAFE_INTEGER, "pay");
    if (botTradesError) {
        interaction.createMessage(botTradesError);
        return;
    }
    const userId = interaction.member.id;
    const stResult = db.startTransaction(userId);
    if (!stResult.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: `You cant give items to that user right now.`
                }
            ]
        });
        return;
    }
    const stResult2 = db.startTransaction(otherUserId);
    if (!stResult2.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "You cant give items to this user\nReason: They have an ongoing transaction."
                }
            ]
        });
        db.endTransaction(userId);
        return;
    }
    try {
        await interaction.acknowledge();
        const wallet = await db.getWallet(userId);
        const premspins = await db.getPremSpins(userId);
        const walletVerification = verifyWallet(wallet, coins, cards, packs, "pay", "your");
        const botWalletVerification = verifyBotWallet(wallet, bottrades, "pay", "your");
        const premSpinsWalletVerification = verifyPremSpins(wallet, premspins, "pay", "your");
        if (!walletVerification.success) {
            interaction.editOriginalMessage(walletVerification.failureMessage);
            return;
        }
        if (!premSpinsWalletVerification.success) {
            interaction.editOriginalMessage(premSpinsWalletVerification.failureMessage);
            return;
        }
        if (!botWalletVerification.success) {
            interaction.editOriginalMessage(botWalletVerification.failureMessage);
            return;
        }
        const { finalCards, finalPacks } = walletVerification;
        const username = await db.getMadfutUserByDiscordUser(userId);
        if (!username) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: "The user your trying to pay isnt linked to this bot\nIn order for you to use this command, they must be linked!\nTell them link one using this command: </mf link:0>."
                    }
                ]
            });
            return;
        }
        const otherUsername = await db.getMadfutUserByDiscordUser(otherUserId);
        if (!otherUsername) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: "The user your trying to pay isnt linked to this bot\nIn order for you to use this command, they must be linked!\nTell them link one using this command: </mf link:0>."
                    }
                ]
            });
            return;
        }
        const transactions = [];
        transactions.push(db.removeBotTrades(userId, bottrades));
        transactions.push(db.addBotTrades(otherUserId, bottrades));
        transactions.push(db.addCoins(userId, -coins));
        transactions.push(db.addCoins(otherUserId, coins));
        transactions.push(db.removeUltimateSpins(userId, premspins));
        transactions.push(db.addUltimateSpins(otherUserId, premspins));
        for (const card of finalCards) {
            transactions.push(db.addCards(otherUserId, card.id, card.amount));
            transactions.push(db.addCards(userId, card.id, -card.amount));
        }
        for (const pack of finalPacks) {
            transactions.push(db.addPacks(otherUserId, pack.id, pack.amount));
            transactions.push(db.addPacks(userId, pack.id, -pack.amount));
        }
        await Promise.all(transactions);
    } finally {
        db.endTransaction(userId);
        db.endTransaction(otherUserId);
    }
    interaction.createFollowup({
        embeds: [
            {
                color: 3319890,
                description: `Your payment to <@${otherUserId}> has been successful!`
            }
        ]
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf give:0>
                    Payment has been to: <@${otherUserId}>
                    The payment: ${coins} coins, ${packs}, ${cards} & ${bottrades} bot-trades
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    })
});
bot.on("admin-give", async (interaction, otherUserId, coins, cards, packs, bottrades, premspins) => {
    const coinsError = verifyCoins(coins, 0, Number.MAX_SAFE_INTEGER, "pay");
    if (coinsError) {
        interaction.createMessage(coinsError);
        return;
    }
const premSpinsError = verifyPremSpins(premspins, 0, Number.MAX_SAFE_INTEGER, "pay");
if (premSpinsError) {
    interaction.createMessage(premSpinsError);
    return;
}
    const botTradesError = verifyBotTrades(bottrades, 0, Number.MAX_SAFE_INTEGER, "pay");
    if (botTradesError) {
        interaction.createMessage(botTradesError);
        return;
    }
    const stResult2 = db.startTransaction(otherUserId);
    if (!stResult2.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "The user you want to pay has an ongoing transaction.\nGet them to end their transactions."
                }
            ]
        });
        return;
    }
    try {
        await interaction.acknowledge();
        const otherUsername = await db.getMadfutUserByDiscordUser(otherUserId);
        if (!otherUsername) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 3319890,
                        description: "That user isn't linked to this bot\nIn order to this command, they must be linked!\nTell them to link one using this command: </mf link:0>."
                    }
                ]
            });
            return;
        }
        const transactions = [];
        transactions.push(db.addCoins(otherUserId, coins));
        transactions.push(db.addBotTrades(otherUserId, bottrades));
        for (const card of cards) {
            const [cardId, cardAmount] = extractAmount(card);
            transactions.push(db.addCards(otherUserId, cardId, cardAmount));
        }
        for (const pack of packs) {
            const [packId, packAmount] = extractAmount(pack);
            transactions.push(db.addPacks(otherUserId, packId, packAmount));
        }
        await Promise.all(transactions);
    } finally {
        db.endTransaction(otherUserId);
    }
    interaction.createFollowup({
        embeds: [
            {
                color: 0xFFD700,
                description: `Admin payment to <@${otherUserId}> was successful!`,
                author: {
                            name: "madfut24 | Admin Give ",
                        },
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
            }
        ],
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf admin pay:0>
                    Payment has been to: <@${otherUserId}>
                    The payment: ${coins} coins, ${packs}, ${cards} & ${bottrades} bot-trades
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    })
});
bot.on("remove", async (interaction, otherUserId, coins, cards, packs, bottrades) => {
    const stResult2 = db.startTransaction(otherUserId);
    if (!stResult2.success) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "The user you want to clear items from has an ongoing transaction.\nGet them to use this command: </mf force-end-me:0>."
                }
            ]
        });
        return;
    }
    try {
        await interaction.acknowledge();
        const otherUsername = await db.getMadfutUserByDiscordUser(otherUserId);
        if (!otherUsername) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: "The user you want to clear items from hasn't linked their account.\nGet them to use this command: /mf link."
                    }
                ]
            });
            return;
        }
        const wallet = await db.getWallet(otherUserId);
        const walletVerification = verifyWallet(wallet, coins, cards, packs, "remove", "the other user's");
        const botWalletVerification = verifyBotWallet(wallet, bottrades, "remove", "the other user's");
        if (!walletVerification.success) {
            interaction.editOriginalMessage(walletVerification.failureMessage);
            return;
        }
        if (!botWalletVerification.success) {
            interaction.editOriginalMessage(botWalletVerification.failureMessage);
            return;
        }
        const { finalCards, finalPacks } = walletVerification;
        const transactions = [];
        transactions.push(db.addCoins(otherUserId, -wallet.coins));
        transactions.push(db.addBotTrades(otherUserId, -wallet.bottrades));
        for (const card of wallet.cards) {
            transactions.push(db.addCards(otherUserId, card.id, -card.amount));
        }
        for (const pack of wallet.packs) {
            transactions.push(db.addPacks(otherUserId, pack.id, -pack.amount));
        }
        await Promise.all(transactions);
    } finally {
        db.endTransaction(otherUserId);
    }
    const username = await db.getMadfutUserByDiscordUser(otherUserId);
    interaction.createFollowup({
        embeds: [
            {
                color: 0x3944BC,
                description: `Successfully cleared all items from <@${otherUserId}>'s wallet.`,
                flags: Constants.MessageFlags.EPHEMERAL
            }
        ],
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf admin rw:0>
                    Successfully reset <@${otherUserId}>'s wallet
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    });
});
bot.on("trade", async (interaction, otherUserId, givingCoins, givingCards, givingPacks, givingBotTrades, receivingCoins, receivingCards, receivingPacks, receivingBotTrades, givingPremSpins, receivingPremSpins) => {
    let coinsError = verifyCoins(givingCoins, 0, Number.MAX_SAFE_INTEGER, "give");
    if (coinsError) {
        interaction.createMessage(coinsError);
        return;
    }
    coinsError = verifyCoins(receivingCoins, 0, Number.MAX_SAFE_INTEGER, "receive");
    if (coinsError) {
        interaction.createMessage(coinsError);
        return;
    }
    let premSpinsError = verifyPremSpins(givingPremSpins, 0, Number.MAX_SAFE_INTEGER, "give");
    if (premSpinsError) {
        interaction.createMessage(premSpinsError);
        return;
    }
    premSpinsError = verifyPremSpins(receivingPremSpins, 0, Number.MAX_SAFE_INTEGER, "receive");
    if (premSpinsError) {
        interaction.createMessage(premSpinsError);
    }
    let botTradesError = verifyBotTrades(givingBotTrades, 0, Number.MAX_SAFE_INTEGER, "give");
    if (botTradesError) {
        interaction.createMessage(botTradesError);
        return;
    }
    botTradesError = verifyBotTrades(receivingBotTrades, 0, Number.MAX_SAFE_INTEGER, "receive");
    if (botTradesError) {
        interaction.createMessage(botTradesError);
        return;
    }
    if (givingCoins !== 0 && receivingCoins !== 0) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "You cannot give and receive coins at the same time."
                }
            ]
        });
        return;
    }
    if (givingBotTrades !== 0 && receivingBotTrades !== 0) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "You cannot give and receive bot trades at the same time."
                }
            ]
        });
        return;
    }
    if (givingPremSpins !== 0 && receivingPremSpins !== 0) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "You cannot give and receive prem spins at the same time."
                }
            ]
        });
        return;
    }
    await interaction.acknowledge();
    const userId = interaction.member.id;
    const myWallet = await db.getWallet(userId);
    const premSpins = await db.getPremSpins(userId);
    const myWalletVerification = verifyWallet(myWallet, givingCoins, givingCards, givingPacks, "give", "your");
    const premSpinsVerification = verifyPremSpinsWallet(premSpins, givingPremSpins, "give", "your");
    const myBotWalletVerification = verifyBotWallet(myWallet, givingBotTrades, "give", "your");
    if (!myWalletVerification.success) {
        interaction.editOriginalMessage(myWalletVerification.failureMessage);
        return;
    }
    if (!premSpinsVerification.success) {
        interaction.editOriginalMessage(premSpinsVerification.failureMessage);
        return;
    }
    if (!myBotWalletVerification.success) {
        interaction.editOriginalMessage(myBotWalletVerification.failureMessage);
        return;
    }
    const { finalCards: myFinalCards, finalPacks: myFinalPacks } = myWalletVerification;
    const otherWallet = await db.getWallet(otherUserId);
    const otherPremSpins = await db.getPremSpins(otherUserId);
    const otherWalletVerification = verifyWallet(otherWallet, receivingCoins, receivingCards, receivingPacks, "receive", "the other user's");
    const otherpremSpinsWalletVerification = verifyPremSpinsWallet(otherPremSpins, receivingPremSpins, "receive", "the other user's");
    const otherBotWalletVerification = verifyBotWallet(otherWallet, receivingBotTrades, "receive", "the other user's");
    if (!otherWalletVerification.success) {
        interaction.editOriginalMessage(otherWalletVerification.failureMessage);
        return;
    }
    if (!otherpremSpinsVerification.success) {
        interaction.editOriginalMessage(otherpremSpinsVerification.failureMessage);
        return;
    }
    if (!otherBotWalletVerification.success) {
        interaction.editOriginalMessage(otherBotWalletVerification.failureMessage);
        return;
    }
    const { finalCards: otherFinalCards, finalPacks: otherFinalPacks } = otherWalletVerification;
    const msg = {
        embeds: [
            {
                color: 0xFFFF00,
                author: {
                    name: "Trade Request",
                    icon_url: "https://images-ext-2.discordapp.net/external/J4II8rlI6z58I9F4JnXmtdZztRMY1v0WVFy4fKXIib0/%3Fsize%3D1024/https/cdn.discordapp.com/icons/1083374041169141841/5015b6f5c67b045cf81a9d25a9240488.png?width=683&height=683"
                },
                description: `<@${otherUserId}>, <@${userId}> wants to trade with you. You have 1 minute to accept.`,
                fields: [
                    {
                        name: "<:COIN:1089323043094011914> Coins",
                        value: `You will *${givingCoins === 0 ? "give* **" + formatNum(receivingCoins) : "receive* **" + formatNum(givingCoins)} coins**.`
                    },
                    {
                        name: "<:Bots:1072152261368762419> Bot Trades",
                        value: `You will *${givingBotTrades === 0 ? "give* **" + formatNum(receivingBotTrades) : "receive* **" + formatNum(givingBotTrades)} bot-trades**.`
                    },
                    {
                        name: "<:xi_token:1092182349652963357> Ultimate Spins",
                        value: `You will *${givingPremSpins === 0 ? "give* **" + formatNum(receivingPremSpins) : "receive* **" + formatNum(givingPremSpins)} Ultimate Spins**.`
                    },
                    {
                        name: "<:REZFUT_Card:1089323506086457395> Cards you will receive",
                        value: myFinalCards.size === 0 ? "No cards." : myFinalCards.map((card) => `${card.amount}x **${card.displayName}**`
                        ).join("\n")
                    },
                    {
                        name: "<:TOTS_PACK:983384447523115018> Packs you will receive",
                        value: myFinalPacks.size === 0 ? "No packs." : myFinalPacks.map((pack) => `${pack.amount}x **${pack.displayName}**`
                        ).join("\n")
                    },
                    {
                        name: "<:REZFUT_Card:1089323506086457395> Cards you will give",
                        value: otherFinalCards.size === 0 ? "No cards." : otherFinalCards.map((card) => `${card.amount}x **${card.displayName}**`
                        ).join("\n")
                    },
                    {
                        name: "<:TOTS_PACK:983384447523115018> Packs you will give",
                        value: otherFinalPacks.size === 0 ? "No packs." : otherFinalPacks.map((pack) => `${pack.amount}x **${pack.displayName}**`
                        ).join("\n")
                    }
                ]
            }
        ],
        components: [
            {
                type: Constants.ComponentTypes.ACTION_ROW,
                components: [
                    {
                        custom_id: "trade-confirm",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.SUCCESS,
                        label: "Confirm"
                    },
                    {
                        custom_id: "trade-decline",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.DANGER,
                        label: "Decline"
                    }
                ]
            }
        ]
    };
    interaction.createMessage(msg);
    const messageId = (await interaction.getOriginalMessage()).id;
    bot.setPermittedReact(messageId, otherUserId);
    const result = await Promise.race([
        once(bot, "tradereact" + messageId),
        sleep(60000)
    ]);
    bot.removeAllListeners("tradereact" + messageId);
    msg.components = [];
    if (!result) {
        msg.embeds[0].footer = {
            text: "This trade request has expired."
        };
        interaction.editOriginalMessage(msg);
        return;
    }
    const [reactInteraction, reaction] = result;
    reactInteraction.acknowledge();
    if (!reaction) {
        msg.embeds[0].footer = {
            text: "This trade request has been declined."
        };
        interaction.editOriginalMessage(msg);
        return;
    }
    interaction.editOriginalMessage(msg);
    // trade request accepted
    const stResult = db.startTransaction(userId);
    if (!stResult.success) {
        interaction.createFollowup(stResult.globalError ? `You cannot trade because ${stResult.error}.` : `You cannot trade because <@${userId}> has an ongoing transaction.`);
        return;
    }
    const stResult2 = db.startTransaction(otherUserId);
    if (!stResult2.success) {
        interaction.createFollowup(stResult2.globalError ? `You cannot trade because ${stResult2.error}.` : `You cannot trade because <@${otherUserId}> has an ongoing transaction.`);
        db.endTransaction(userId);
        return;
    }
    try {
        const myWalletVerification2 = verifyWallet(await db.getWallet(userId), givingCoins, givingCards, givingPacks, "receive", `<@${userId}>'s`);
        const myBotWalletVerification2 = verifyBotWallet(await db.getWallet(userId), givingBotTrades, "receive", `<@${userId}>'s`); // TODO: name collisions could cause success even if the user doesn't have the original packs
        if (!myWalletVerification2.success) {
            interaction.createFollowup(myWalletVerification2.failureMessage);
            return;
        }
        if (!myBotWalletVerification2.success) {
            interaction.createFollowup(myBotWalletVerification2.failureMessage);
            return;
        }
        const otherWalletVerification2 = verifyWallet(await db.getWallet(otherUserId), receivingCoins, receivingCards, receivingPacks, "give", `<@${otherUserId}>'s`);
        const otherBotWalletVerification2 = verifyBotWallet(await db.getWallet(otherUserId), receivingBotTrades, "give", `<@${otherUserId}>'s`);
        if (!otherWalletVerification2.success) {
            interaction.createFollowup(otherWalletVerification2.failureMessage);
            return;
        }
        if (!otherBotWalletVerification2.success) {
            interaction.createFollowup(otherBotWalletVerification2.failureMessage);
            return;
        }
        const username = await db.getMadfutUserByDiscordUser(userId);
        if (!username) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: `Sorry <@${userId}> but you aren't linked to this bot\nIn order for you to use this command, must be linked!\nTo link one use this command: </mf link:0>.`
                    }
                ]
            });
            return;
        }
        const otherUsername = await db.getMadfutUserByDiscordUser(otherUserId);
        if (!otherUsername) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: `Whelp, <@${otherUserId}> isnt linked to this bot\nIn order for you to use this command, must they must be linked!\nTell them to link one using this command: </mf link:0>.`
                    }
                ]
            });
            return;
        }
        const transactions = [];
        transactions.push(db.addBotTrades(userId, receivingBotTrades - givingBotTrades));
        transactions.push(db.addBotTrades(otherUserId, givingBotTrades - receivingBotTrades));
        transactions.push(db.addCoins(userId, receivingCoins - givingCoins));
        transactions.push(db.addCoins(otherUserId, givingCoins - receivingCoins));
        for (const card of myFinalCards) {
            transactions.push(db.addCards(otherUserId, card.id, card.amount));
            transactions.push(db.addCards(userId, card.id, -card.amount));
        }
        for (const card2 of otherFinalCards) {
            transactions.push(db.addCards(userId, card2.id, card2.amount));
            transactions.push(db.addCards(otherUserId, card2.id, -card2.amount));
        }
        for (const pack of myFinalPacks) {
            transactions.push(db.addPacks(otherUserId, pack.id, pack.amount));
            transactions.push(db.addPacks(userId, pack.id, -pack.amount));
        }
        for (const pack2 of otherFinalPacks) {
            transactions.push(db.addPacks(userId, pack2.id, pack2.amount));
            transactions.push(db.addPacks(otherUserId, pack2.id, -pack2.amount));
        }
        await Promise.all(transactions);
    } finally {
        db.endTransaction(userId);
        db.endTransaction(otherUserId);
    }
    interaction.createFollowup({
        embeds: [
            {
                color: 3319890,
                description: `Trade between <@${userId}> and <@${otherUserId}> was successful!`
            }
        ]
    });
});
bot.on("flip", async (interaction, coins, heads, otherUserId) => {
    const flipResult = getRandomInt(2) === 0;
    const iWin = flipResult === heads;
    const coinsError = verifyCoins(coins, 0, Number.MAX_SAFE_INTEGER, "flip for");
    if (coinsError) {
        interaction.createMessage(coinsError);
        return;
    }
    await interaction.acknowledge();
    const userId = interaction.member.id;
    const myWalletVerification = verifyWallet(await db.getWallet(userId), coins, [], [], "flip for", "your");
    if (!myWalletVerification.success) {
        interaction.editOriginalMessage(myWalletVerification.failureMessage);
        return;
    }
    const openFlip = !otherUserId;
    if (!openFlip) {
        const otherWalletVerification = verifyWallet(await db.getWallet(otherUserId), coins, [], [], "flip for", "the other user's");
        if (!otherWalletVerification.success) {
            interaction.editOriginalMessage(otherWalletVerification.failureMessage);
            return;
        }
    }
    const msg = {
        embeds: [
            {
                description: `${openFlip ? "Does anyone" : `<@${otherUserId}>, do you`} want to flip for **${formatNum(coins)} coins**?\nThe user {<@${userId}>} has chose **${heads ? "heads" : "tails"}**\n\nWinner will have **${formatNum(coins)}** coins added to their wallet.\nLoser will have **${formatNum(coins)}** coins removed from their wallet!`,
                color: 0xFFFF00,
                author: {
                    name: "Coin-Flip",
                    icon_url: "https://images-ext-2.discordapp.net/external/NQFtz3sw55lnqcybOsSphZcEhuwPMzz3A6_Nreap4gs/https/i.imgur.com/7W4WJI6.png"
                },
                footer: {
                    text: "You have 30 seconds to respond."
                }
            }
        ],
        components: [
            {
                type: Constants.ComponentTypes.ACTION_ROW,
                components: openFlip ? [
                    {
                        custom_id: "flip-confirm",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.SUCCESS,
                        label: "Accept"
                    }
                ] : [
                    {
                        custom_id: "flip-confirm",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.SUCCESS,
                        label: "Confirm"
                    },
                    {
                        custom_id: "flip-decline",
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.DANGER,
                        label: "Decline"
                    }
                ]
            }
        ]
    };
    interaction.createMessage(msg);
    const messageId = (await interaction.getOriginalMessage()).id;
    bot.setPermittedReact(messageId, otherUserId ?? true);
    const result = await Promise.race([
        once(bot, "flipreact" + messageId),
        sleep(30000)
    ]);
    bot.removeAllListeners("flipreact" + messageId);
    msg.components = [];
    if (!result) {
        msg.embeds[0].footer = {
            text: "This coin flip request has expired."
        };
        interaction.editOriginalMessage(msg);
        return;
    }
    const [reactInteraction, reaction] = result;
    reactInteraction.acknowledge();
    otherUserId = reactInteraction.member.id;
    if (!reaction) {
        msg.embeds[0].footer = {
            text: "This coin flip request has been declined."
        };
        interaction.editOriginalMessage(msg);
        return;
    }
    interaction.editOriginalMessage(msg);
    // flip request accepted
    const stResult = db.startTransaction(userId);
    if (!stResult.success) {
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFF0000,
                    description: stResult.globalError ? `You cannot flip because ${stResult.error}.` : `You cannot flip because <@${userId}> has an ongoing transaction.`
                }
            ]
        });
        return;
    }
    const stResult2 = db.startTransaction(otherUserId);
    if (!stResult2.success) {
        interaction.createFollowup({
            embeds: [
                {
                    color: 0xFF0000,
                    description: stResult2.globalError ? `You cannot flip because ${stResult2.error}.` : `You cannot flip because <@${otherUserId}> has an ongoing transaction.`
                }
            ]
        });
        db.endTransaction(userId);
        return;
    }
    try {
        const myWalletVerification2 = verifyWallet(await db.getWallet(userId), coins, [], [], "flip for", `<@${userId}>'s`);
        if (!myWalletVerification2.success) {
            interaction.createFollowup(myWalletVerification2.failureMessage);
            return;
        }
        const otherWalletVerification2 = verifyWallet(await db.getWallet(otherUserId), coins, [], [], "flip for", `<@${otherUserId}>'s`);
        if (!otherWalletVerification2.success) {
            interaction.createFollowup(otherWalletVerification2.failureMessage);
            return;
        }
        const username = await db.getMadfutUserByDiscordUser(userId);
        if (!username) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: `Coin flip failed as there is no MadFut username linked to <@${userId}>'s discord account. Get them to use </mf link:0>.`
                    }
                ]
            });
            return;
        }
        const otherUsername = await db.getMadfutUserByDiscordUser(otherUserId);
        if (!otherUsername) {
            interaction.createFollowup({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: `Coin flip failed as there is no MadFut username linked to <@${otherUserId}>'s discord account. Get them to use </mf link:0>.`
                    }
                ]
            });
            return;
        }
        const transactions = [];
        transactions.push(db.addCoins(userId, iWin ? coins : -coins));
        transactions.push(db.addCoins(otherUserId, iWin ? -coins : coins));
        await Promise.all(transactions);
    } finally {
        db.endTransaction(userId);
        db.endTransaction(otherUserId);
    }
    interaction.createFollowup({
        embeds: [
            {
                color: 0xFF0000,
                author: {
                    name: "Coin flip",
                    icon_url: "https://w7.pngwing.com/pngs/191/349/png-transparent-dogecoin-bitcoin-cryptocurrency-exchange-bitcoin-dog-like-mammal-meme-bitcoin.png"
                },
                description: `**${flipResult ? "Heads" : "Tails"}**! <@${iWin ? userId : otherUserId}> won the coin flip against <@${iWin ? otherUserId : userId}> for **${formatNum(coins)} coins**.`
            }
        ]
    });
});
const allowedPacks = [
    "silver_special",
    "bf_nine_special",
    "bf_five_special",
    "totw",
    "fatal_rare",
    "bf_93_special",
    "fatal_special",
    "double_special",
    "triple_special",
    "gold",
    "random",
    "gold_super",
    "rare",
    "bf_94_special",
    "bf_eight_special",
    "free",
    "silver_plus",
    "no_totw_special",
    "fatal_silver",
    "85_special",
    "bf_89_special",
    "bf_88_special",
    "bf_four_special",
    "bf_seven_special",
    "gold_mega",
    "special",
    "rainbow",
    "bf_six_special",
    "bf_92_special",
    "80+",
    "bf_86_special",
    "fatal_nonrare",
    "bf_91_special",
    "bf_87_special",
    "silver",
    "op_special",
    "bf_90_special",
    "fatal_bronze",
    "pp_sbc_real_madrid_icons",
    "pp_new_87_91",
    "pp_fut_champs",
    "pp_new_81_84",
    "pp_special",
    "pp_special_88_92",
    "pp_best_1",
    "pp_new_83_86",
    "pp_new_77_82",
    "pp_new_85_88",
    "pp_bad_1",
    "pp_totw",
    "pp_new_special",
    "pp_icons_86_92",
    "pp_mega",
    "pp_good_1",
    "pp_icon",
    "pp_special_83_86",
    "pp_special_81_84",
    "pp_special_85_88",
    "pp_special_86_89"
];
bot.on("invme", async (interaction, coins, myPacks) => {
    const userId = interaction.member.id;
    if (myPacks) {
        if (myPacks.length > 3) {
            interaction.createMessage({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: `You can't pick more than 3 packs dumbass.`
                    }
                ],
                flags: Constants.MessageFlags.EPHEMERAL
            });
            return;
        }
        for (const pack of myPacks) {
            if (!allowedPacks.includes(pack)) {
                interaction.createMessage({
                    embeds: [
                        {
                            color: 0xFF0000,
                            description: `Invalid pack \`${pack}\`.`
                        }
                    ],
                    flags: Constants.MessageFlags.EPHEMERAL
                });
                return;
            }
        }
    }
    coins = Math.max(Math.min(coins, 200000), 0);
    const username = await db.getMadfutUserByDiscordUser(userId);
    if (!username) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "There is no MadFut account linked to the user!"
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    interaction.createMessage({
        embeds: [
            {
                color: 3319890,
                description: "This command was successful!"
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    freeTradeUnlimited(username, coins, myPacks ? myPacks.map((pack) => ({
        pack,
        amount: 1
    })
    ) : packs1);
});
bot.on("set-packs", async (interaction, thepacks) => {
    packs1 = thepacks.map((packname) => ({
        pack: packname,
        amount: 1
    })
    );
    interaction.createMessage({
        embeds: [
            {
                color: 3319890,
                description: `Successfully changed the packs in the trades\nThe new packs: ${thepacks}`
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0xFF0000,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </dev sp:0>
                        New packs: ${thepacks}
                        Cmd used by: <@${interaction.member.id}>`
            }
        ]
    });
});
bot.on("faketrade", async (interaction, amount, username, userId) => {
    if (!username && !userId) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "❌・Enter either a MadFut username or a discord user!"
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    } else if (userId) {
        username = await db.getMadfutUserByDiscordUser(userId);
        if (!username) {
            interaction.createMessage({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: "❌・This user does not have their MadFut account linked!"
                    }
                ],
                flags: Constants.MessageFlags.EPHEMERAL
            });
            return;
        }
    }
    username = username;
    if (await faketrade(username, amount) === null) interaction.createMessage({
        embeds: [
            {
                color: 0xFF0000,
                description: "❌・Something went wrong. Please try again later!"
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    await interaction.createMessage({
        embeds: [
            {
                color: 3319890,
                description: `Currently spamming **${username}** with invites.`
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: { text:
                ``,
            },
            author: {
                icon_url:`${interaction.member.avatarURL}()`,
                name: `madfut24 Logging`
            },
            thumbnail: {
                url: "",
                width: 50,
                height: 50
            },
                    description: `Cmd used: </perms pack-trade:0>
                    Username: ${username}
                    Amount: ${amount}
                    Cmd used by: <@${interaction.member.id}>.`
                
            }
        ]
        });
});
bot.on("free-trade", async (interaction, amount, username, userId) => {
    if (!username && !userId) {
        interaction.createMessage({
            embeds: [
                {
                    color: 0xFF0000,
                    description: "❌・Enter either a MadFut username or a discord user!"
                }
            ],
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    } else if (userId) {
        username = await db.getMadfutUserByDiscordUser(userId);
        if (!username) {
            interaction.createMessage({
                embeds: [
                    {
                        color: 0xFF0000,
                        description: "❌・This user does not have their MadFut account linked!"
                    }
                ],
                flags: Constants.MessageFlags.EPHEMERAL
            });
            return;
        }
    }
username = username;
    if (await freeTrade(username, amount) === null) interaction.createMessage({
        embeds: [
            {
                color: 0xFF0000,
                description: "❌・Something went wrong. Please try again later!"
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
    await interaction.createMessage({
        embeds: [
            {
                color: 0xFFD700,
                description: `Sending ${username} **${amount}** free trade(s)`
            }
        ],
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: { text:
                ``,
            },
            author: {
                icon_url:`${interaction.member.avatarURL}()`,
                name: `madfut24 Logging`
            },
            thumbnail: {
                url: "",
                width: 50,
                height: 50
            },
                    description: `Cmd used: </admin free-trade:0>
                    Username: ${username}
                    Amount: ${amount}
                    Cmd used by: <@${interaction.member.id}>.`
                
            }
        ]
        });
});
const channelId = "1142340804610895892";
setInterval(async ()=>{
    const types = [
        'coins',
        'bt',
        'card',
        'pack'
    ];
    const type = types[Math.floor(Math.random() * types.length)];
    const prize = Math.floor(Math.random() * 10) + 1;
    const camount = Math.floor(Math.random() * 500000) + 1;
    const duration = 900000;
    if (type === "coins") {
        let giveawayMessage = await bot.sendMessage(channelId, {
            content: `<@&1142340743466336407>`,
            embeds: [
                {
                    color: 0x3944BC,
                    author: {
                    },
                    description: `Click the 🎊 below to enter this giveaway!\nPrize -> ${camount} coins\nDuration -> 10 minutes\n**You must be linked in order to participate in this giveaway!**`
                }
            ]
        });
        await bot.react(giveawayMessage, "🎊");
        setTimeout(()=>{
            giveawayEndCoins(giveawayMessage, Number(prize));
        }, duration);
    } else if (type === "bt") {
        let giveawayMessage1 = await bot.sendMessage(channelId, {
            content: `<@&1142340743466336407> & <@&1142340745475399751>`,
            embeds: [
                {
                    color: 0x3944BC,
                    author: {
                    },
                    description: `Click the 🎊 below to enter this giveaway!\nPrize -> ${prize}x bot trades\nDuration -> 10 minutes\n**You must be linked in order to participate in this giveaway!**`
                }
            ]
        });
        await bot.react(giveawayMessage1, "🎊");
        setTimeout(()=>{
            giveawayEndBotTrades(giveawayMessage1, Number(prize));
        }, duration);
    } else if (type === "card") {
        let allNames = await db.getNames();
        let randomName = allNames[Math.floor(Math.random() * allNames.length)];
        let randomCardName = await db.getCardName(randomName);
        let giveawayMessage3 = await bot.sendMessage(channelId, {
            content: `<@&1142340743466336407>`,
            embeds: [
                {
                    color: 0x3944BC,
                    author: {
                    },
                    description: `Click the 🎊 below to enter this giveaway!\nPrize -> ${prize}x ${randomCardName}\nDuration -> 10 minutes\n**You must be linked in order to participate in this giveaway!**`
                }
            ]
        });
        await bot.react(giveawayMessage3, "🎊");
        setTimeout(()=>{
            giveawayEndCards(giveawayMessage3, Number(prize), randomName, randomCardName);
        }, duration);
    } else if (type === "pack") {
        let selectedPack = packs[Math.floor(Math.random() * packs.length)];
        let selectedPackCapitalized = selectedPack.replace(/_/g, ' ').replace(/(?:^|\s)\S/g, function(a) {
            return a.toUpperCase();
        });
        let giveawayMessage4 = await bot.sendMessage(channelId, {
            content: `<@&1142340743466336407>`,
            embeds: [
                {
                    color: 0x3944BC,
                    author: {
                    },
                    description: `Click the 🎊 below to enter this giveaway!\nPrize -> ${prize}x ${selectedPackCapitalized} packs\nDuration -> 10 minutes\n**You must be linked in order to participate in this giveaway!**`
                }
            ]
        });
        await bot.react(giveawayMessage4, "🎊");
        setTimeout(()=>{
            giveawayEndPacks(giveawayMessage4, selectedPack, Number(prize));
        }, duration);
    }
}, 600000);
async function randomWinner(minNum, maxNum) {
    return Math.floor(Math.random() * (maxNum - minNum) + minNum);
}
// @ts-ignore
async function giveawayEndBotTrades(giveawayMessage, prize) {
    let reactors = await bot.getReacts(giveawayMessage, "🎊");
    if (reactors.length === 0) {
        await bot.sendMessage(channelId, {
            content: "Whelp.. no one entered"
        });
    } else {
        let madfutUsers = await db.getMadfutUsersByDiscordUsers(reactors);
        let linkedAccounts = await db.getDiscordUserByMadfutUser(madfutUsers);
        let linkedUsers = [];
        linkedAccounts.forEach(async (id)=>{
            linkedUsers.push(id);
        });
        console.log(linkedUsers.join("\n"));
        let length = linkedUsers.length;
        let randomUser = await randomWinner(0, length - 1);
        let winner = linkedUsers[randomUser];
        if (winner) {
            db.addBotTrades(winner, prize);
            await bot.sendMessage(channelId, {
                content: `Congratulations, <@${winner}>!`,
                embeds: [
                    {
                        color: 3319890,
                        author: {
                        },
                        description: `Yay! We have a winner..\nCongratulations <@${winner}>, you will now find **${prize}x bot trades** placed into your wallet!\nThis giveaway had ${length} participants enter.`
                    }
                ]
            });
        } else {
            return bot.sendMessage(channelId, {
                content: `No winner could be found...`,
                embeds: [
                    {
                        color: 0xFF0000,
                        author: {
                        },
                        description: `Uh oh.. sadly no winners were found.\nThis is because either no one was linked or no-one entered!`
                    }
                ]
            });
        }
    }
}
// @ts-ignore
async function giveawayEndCoins(giveawayMessage, prize) {
    let reactors = await bot.getReacts(giveawayMessage, "🎊");
    if (reactors.length === 0) {
        await bot.sendMessage(channelId, {
            content: "Whelp.. no one entered"
        });
    } else {
        let madfutUsers = await db.getMadfutUsersByDiscordUsers(reactors);
        let linkedAccounts = await db.getDiscordUserByMadfutUser(madfutUsers);
        let linkedUsers = [];
        linkedAccounts.forEach(async (id)=>{
            linkedUsers.push(id);
        });
        console.log(linkedUsers.join("\n"));
        let length = linkedUsers.length;
        let randomUser = await randomWinner(0, length - 1);
        let winner = linkedUsers[randomUser];
        if (winner) {
            db.addCoins(winner, prize);
            await bot.sendMessage(channelId, {
                content: `Congratulations, <@${winner}>!`,
                embeds: [
                    {
                        color: 3319890,
                        author: {
                        },
                        description: `Yay! We have a winner..\nCongratulations <@${winner}>, you will now find **${camount} coins** placed into your wallet!\nThis giveaway had ${length} participants enter.`
                    }
                ]
            });
        } else {
            return bot.sendMessage(channelId, {
                content: `No winner could be found...`,
                embeds: [
                    {
                        color: 0xFF0000,
                        author: {
                        },
                        description: `Uh oh.. sadly no winners were found.\nThis is because either no one was linked or no-one entered!`
                    }
                ]
            });
        }
    }
}
let packs = [
    "icons",
    "94_special",
    "toty_icon",
    "toty_nominee",
    "totw_silver",
    "totw_gold",
    "rare_bronze",
    "93_special",
    "silver",
    "rare_silver",
    "gold",
    "rare_gold",
    "special",
    "95_special",
];
async function giveawayEndPacks(giveawayMessage, packId, amount) {
    let reactors = await bot.getReacts(giveawayMessage, "🎊");
    if (reactors.length === 0) {
        await bot.sendMessage(channelId, {
            content: "Whelp.. no one entered"
        });
    } else {
        let madfutUsers = await db.getMadfutUsersByDiscordUsers(reactors);
        let linkedAccounts = await db.getDiscordUserByMadfutUser(madfutUsers);
        let linkedUsers = [];
        linkedAccounts.forEach(async (id)=>{
            linkedUsers.push(id);
        });
        console.log(linkedUsers.join("\n"));
        let length = linkedUsers.length;
        let randomUser = await randomWinner(0, length - 1);
        let winner = linkedUsers[randomUser];
        if (winner) {
            db.addPacks(winner, packId, amount);
            let selectedPackCapitalized = packId.replace(/_/g, ' ').replace(/(?:^|\s)\S/g, function(a) {
                return a.toUpperCase();
            });
            await bot.sendMessage(channelId, {
                content: `Congratulations, <@${winner}>!`,
                embeds: [
                    {
                        color: 3319890,
                        author: {
                        },
                        description: `Yay! We have a winner..\nCongratulations <@${winner}>, you will now find **${amount}x ${selectedPackCapitalized} Pack(s)!** placed into your wallet!\nThis giveaway had ${length} participants enter.`
                    }
                ]
            });
        } else {
            return bot.sendMessage(channelId, {
                content: `No winner could be found...`,
                embeds: [
                    {
                        color: 0xFF0000,
                        author: {
                        },
                        description: `Uh oh.. sadly no winners were found.\nThis is because either no one was linked or no-one entered!`
                    }
                ]
            });
        }
    }
}
async function giveawayEndCards(giveawayMessage, prize, randomName, randomCardName) {
    let reactors = await bot.getReacts(giveawayMessage, "🎊");
    if (reactors.length === 0) {
        await bot.sendMessage(channelId, {
            content: "Whelp.. no one entered"
        });
    } else {
        let madfutUsers = await db.getMadfutUsersByDiscordUsers(reactors);
        let linkedAccounts = await db.getDiscordUserByMadfutUser(madfutUsers);
        if (!Array.isArray(linkedAccounts)) {
            console.log("No linked accounts found.");
            return; // Exit the function or handle the condition appropriately
        }
        
        let linkedUsers = [];
        for (const id of linkedAccounts) {
            linkedUsers.push(id);
        }
        console.log(linkedUsers.join("\n"));
        let length = linkedUsers.length;
        let randomUser = await randomWinner(0, length - 1);
        let winner = linkedUsers[randomUser];
        if (winner) {
            db.addCards(winner, randomName, prize);
            await bot.sendMessage(channelId, {
                content: `Congratulations, <@${winner}>!`,
                embeds: [
                    {
                        color: 3319890,
                        author: {
                        },
                        description: `Yay! We have a winner..\nCongratulations <@${winner}>, you will now find **${prize}x ${randomCardName}** placed into your wallet!\nThis giveaway had ${length} participants enter.`
                    }
                ]
            });
        } else {
            return bot.sendMessage(channelId, {
                content: `No winner could be found...`,
                embeds: [
                    {
                        color: 0xFF0000,
                        author: {
                        },
                        description: `Uh oh.. sadly no winners were found.\nThis is because either no one was linked or no-one entered!`
                    }
                ]
            });
        }
    }
}
let giveawayRunning = false;
let giveawayStartTimeout;
let giveawayEndTimeout;
let giveawayDuration;
let rawGiveawayDuration;
let giveawayMessage;
bot.on("force-stop", async (interaction) => {
    giveawayEnd(interaction.channel.id);
    interaction.createMessage({
        content: "Force stop successful",
        flags: Constants.MessageFlags.EPHEMERAL
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf staff giveaway-stop:0>
                    Force stop was a success
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    });
    return;
});
bot.on("create", async (interaction, start, duration) => {
    if (isNaN(parseFloat(start))) {
        interaction.createMessage({
            content: "Enter a valid number of minutes for the start",
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    if (duration && isNaN(parseFloat(start))) {
        interaction.createMessage({
            content: "Enter a valid number of minutes for the duration",
            flags: Constants.MessageFlags.EPHEMERAL
        });
        return;
    }
    const durationMinutes = duration ? parseFloat(duration) : undefined;
    rawGiveawayDuration = duration;
    giveawayDuration = durationMinutes ? durationMinutes * 60000 : undefined;
    const minutes = parseFloat(start);
    const startTime = Math.round(Date.now() / 1000 + minutes * 60);
    await interaction.createMessage({
        content: "> Successfully created the bot giveaway!",
        flags: Constants.MessageFlags.EPHEMERAL
    });
    console.log(`${interaction.member?.username} has started a giveaway which will start in ${start} minute(s) and have a duration from ${duration} minute(s)`);
    const channelId = interaction.channel.id;
    giveawayMessage = await bot.sendMessage(channelId, {
        allowedMentions: {
            roles: [
                bot.config.gwpRoleId
            ]
        },
        content: `<@&${bot.config.gwpRoleId}>`,
        embeds: [
            {
                color: 0x3944BC,
                author: {
                    name: "madfut24 Giveaways",
                    icon_url: "",
                    thumbnail: "https://images-ext-2.discordapp.net/external/6tBsXW1X_0JjI-w7wn-jvsyBGwsl4Hj9r9wo15W2WGQ/https/em-content.zobj.net/thumbs/160/apple/325/party-popper_1f389.png"
                },
                description: `A **${duration ? duration + " minute(s)** long giveaway" : ""} will start in <t:${startTime}:R>!\nGo ahead and link in <#${bot.config.commandsChannelId}> to join this giveaway!`
            }
        ]
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </giveaway-create:0>
                    Creating a giveaway was a success
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    });
    await bot.react(giveawayMessage, "🎉");
    giveawayStartTimeout = setTimeout(() => {
        giveawayStart();
    }, minutes * 60000);
    return;
});
bot.on("force-start", async (interaction) => {
    giveawayStart();
    interaction.createMessage({
        content: "Force start successful",
        flags: Constants.MessageFlags.EPHEMERAL
    });
    bot.sendMessage(config.logChannelId, {
        embeds: [
            {
                color: 0x3944BC,
                footer: {
                    text:
                        ``,
                },
                author: {
                    icon_url: `${interaction.member.avatarURL}()`,
                    name: `madfut24 Logging`
                },
                thumbnail: {
                    url: "",
                    width: 50,
                    height: 50
                },
                description: `Cmd used: </mf23 staff giveaway fs:0>
                    Force start was a success
                    Cmd used by: <@${interaction.member.id}>.`

            }
        ]
    });
    console.log(`${interaction.member?.username} force-started a giveaway.`);
    return;
});
async function giveawayTrade(username) {
    let madfutClient = await madfutclient();
    while (giveawayRunning) {
        let tradeRef;
            try {
                tradeRef = await madfutClient.inviteWithTimeout(username, 60000, "test1");
            } catch {
                console.log(`${username} rejected invite or timed out.`);
                break;
            }
            try {
                await madfutClient.doTrade(tradeRef, async (profile) => ({
                    receiveCoins: false,
                    receiveCards: false,
                    receivePacks: false,
                    giveCards: [],
                    giveCoins: 500000,
                    givePacks: packs1
                })
            );
        console.log(`Completed giveaway trade with ${username}`);
            } catch (_err) {
        console.log(`Giveaway trade with ${username} failed: Player left`);
            }
        }
    }
async function giveawayStart() {
    if (giveawayStartTimeout) clearTimeout(giveawayStartTimeout);
    if (giveawayMessage) {
        await bot.editMessage(giveawayMessage.channel.id, giveawayMessage.id, {
            embeds: [
                {
                    color: 0x3944BC,
                    author: {
                        name: "madfut24 Giveaways"
                    },
                    description: "Signups for this giveaway are now closed\nThis means the giveaway will start shortly!"
                }
            ],
            components: []
        });
    }
    bot.removeAllListeners("giveawayjoin");
    giveawayRunning = true;
    const giveawaySignups = await db.getMadfutUsersByDiscordUsers(await bot.getReacts(giveawayMessage, "🎉"));
    for (const username of giveawaySignups) {
        await giveawayTrade(username);
    }
    await bot.sendMessage(giveawayMessage.channel.id, {
        allowedMentions: {
            roles: [
                bot.config.gwpRoleId
            ]
        },
        content: `<@&${bot.config.gwpRoleId}>`,
        embeds: [
            {
                color: 0x3944BC,
                author: {
                    name: "madfut24 Giveaways"
                },
                description: `The **${rawGiveawayDuration ? rawGiveawayDuration + " minute(s)** long " : ""} giveaway has now started\nAmount of people getting invites: **${giveawaySignups.length}**\nSwitch your app to MadFut and start trading!`
            }
        ]
    });
    if (giveawayDuration) {
        giveawayEndTimeout = setTimeout(() => {
            giveawayEnd(giveawayMessage.channel.id);
        }, giveawayDuration);
    }
}
async function giveawayEnd(channelId) {
    giveawayRunning = false;
    if (giveawayEndTimeout) clearTimeout(giveawayEndTimeout);
    bot.sendMessage(channelId, {
        allowedMentions: {
            roles: [
                bot.config.gwpRoleId
            ]
        },
        content: `<@&${bot.config.gwpRoleId}>`,
        embeds: [
            {
                color: 0x3944BC,
                author: {
                    name: "madfut24 Giveawayes"
                },
                description: "The bot giveaway has now ended!\nFor more giveaways invite people and be active.\nIf you missed this giveaway, claim your role in <#1140901369004425297>!"
            }
        ]
    });
}
console.log("Bot event listeners registered");
console.log("MadFUT bot has started");