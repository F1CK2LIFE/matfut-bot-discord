import Eris, { CommandInteraction, ComponentInteraction, Constants, Interaction } from "eris";
import { once, EventEmitter } from "events";
import { readFileFromURL } from "./util.js";
import config from "./config.js";
const bot = Eris(config.botToken, {
    intents: [
        "guilds",
        "guildMessages",
        "FLAGS.GUILDS"
    ]
});
const permittedReacts = {
};
class DiscordBot extends EventEmitter {
    setPermittedReact(messageId, userId1) {
        permittedReacts[messageId] = userId1;
    }
    sendMessage(channelId, content) {
        return bot.createMessage(channelId, content);
    }
    editMessage(channelID, messageID, content1) {
        return bot.editMessage(channelID, messageID, content1);
    }
    getReacts(message2, emoji) {
        return new Promise(async (resolve) => {
            const res = [];
            let after;
            let added = 0;
            do {
                const users = await message2.getReaction(emoji, after ? {
                    after
                } : {
                });
                added = users.length;
                after = users[users.length - 1]?.id;
                res.push(...users.map((user) => user.id
                ));
            } while (added === 100)
            resolve(res);
        });
    }
    async react(message1, emoji1) {
        return message1.addReaction(emoji1);
    }
    constructor() {
        super();
        this.config = config;
    }
}
const exportedBot = new DiscordBot();
bot.on("error", (err) => {
    console.error("[DISCORD BOT ERROR]", err);
});
bot.connect();
await Promise.all([
    once(bot, "ready")
]);
console.log("ayoub Madfut Files")
bot.editStatus({
    name: "MADFUT24",
    type: Constants.ActivityTypes.GAME,
});
const linkCommand = {
    name: "link",
    description: "Link your discord account with a MadFUT account",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "user",
            description: "User?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        }
    ]
};
const buyCommand = {
    name: "buy",
    description: "Buy bot trades for wallet coins!",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "bottrades",
            description: "The amount of bottrades you want to buy",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false,
            choices: [
                {
            		name: "10-bottrades",
            		value: 10
                },
        		{
                    name: "25-bottrades",
                    value: 25
                },
        		{
                    name: "50-bottrades",
                    value: 50
                },
                {
            		name: "100-bottrades",
            		value: 100
                },
                {
                    name: "250-bottrades",
                    value: 250
                },
        		{
                    name: "500-bottrades",
                    value: 500
                },
                {
            		name: "1000-bottrades",
            		value: 1000
                }
            ]
        }
    ]
};
const sellCommand = {
    name: "sell",
    description: "Sell bot trades for wallet coins!",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "bottrades",
            description: "The amount of bottrades you want to sell",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false,
            choices: [
                {
            		name: "10-bottrades",
            		value: 10
                },
        		{
                    name: "25-bottrades",
                    value: 25
                },
        		{
                    name: "50-bottrades",
                    value: 50
                },
                {
            		name: "100-bottrades",
            		value: 100
                },
                {
                    name: "250-bottrades",
                    value: 250
                },
        		{
                    name: "500-bottrades",
                    value: 500
                },
                {
            		name: "1000-bottrades",
            		value: 1000
                }
            ]
        }
    ]
};
const token = {
    name: "token",
    description: "Change The Madfut Refresh Token",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "tokenname",  // Update to lowercase
            description: "The Madfut Refresh Token Name.",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        }
    ]
};
const selectCommand = {
    name: "select",
    description: "Select 3 Cards To Get In Trade",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "username",
            description: "Your Madfut Username",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "id1",
            description: "The First Card In The Trade",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "id2",
            description: "The Second Card In The Trade",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "id3",
            description: "The Third Card In The Trade",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        }
    ]
};
const helpCommand = {
    name: "help",
    description: "Get a brief explaination about our commands",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    flags: Constants.MessageFlags.EPHEMERAL
};
const dailyCommand = {
    name: "dailyspin",
    description: "Spin the wheel",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const spinCommand = {
    name: "spin-the-wheel",
    description: "Spin the wheel",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const rewardsCommand = {
    name: "rewards",
    description: "Find out what our rewards are",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    flags: Constants.MessageFlags.EPHEMERAL
};
const glassesCommand = {
    name: "glasses",
    description: "Play AXR glasses",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
};
const unlinkCommand = {
    name: "unlink",
    description: "Unlink your account",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const freeTradeCommand = {
    name: "free-trade",
    description: "Send someone a free trade",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "a",
            description: "Amount Of Trades?",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: true
        },
        {
            name: "u",
            description: "What MadFut Username?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "type",
            description: "Type Of Trade?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            choices: [
                {
                    name: "Packs",
                    value: "packs"
                },
                {
                    name: "Wishlist",
                    value: "cards"
                }
            ],
            required: true
        },
    ]
};
const UpdateAppCheckCommand = {
    name: "update-act",
    description: "Update the act",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "token",
            description: "New token?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
    ]
};
const appcheckexpCommand = {
    name: "act-exp",
    description: "Find when the act runs out",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
}
const spamInviteCommand = {
    name: "st",
    description: "Spam invite someone on MadFUT",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "user",
            description: "MadFut user?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "a",
            description: "Amount of times?",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: true
        },
    ]
};
const walletCommand = {
    name: "wallet",
    description: "Display your wallet",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
};
const botCodeCommand = {
    name: "botcode",
    description: "Create a botcode",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "codename",
            description: "Set the codename",
type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "type",
            description: "[PACKS OR CARDS] The type of bot code do you want to create!",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            choices: [
                {
                    name: "WISHLIST",
                    value: "wishlist"
}
            ],
            required: true
        },
        {
            name: "duration",
            description: "Time in minutes",
            type: Constants.ApplicationCommandOptionTypes.NUMBER,
            required: true
        }
    ]
};
const freecoinsCommand = {
    name: "free-trades",
    description: "Claim Ur Free Trades",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const matchRewardsCommand = {
    name: "match-rewards",
    description: "Claim your match rewards",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const claimlevelCommand = {
    name: "level-reward",
    description: "Claim your level rewards",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "level",
            description: "What level?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true,
            choices: [
                {
                    name: "Bronze",
                    value: "bronze"
                },
                {
                    name: "Silver",
                    value: "silver"
                },
                {
                    name: "Gold",
                    value: "gold"
                }

                ,
                {
                    name: "TOTW",
                    value: "totw"
                }
                ,
                {
                    name: "Ones to watch",
                    value: "otw"
                }
                ,
                {
                    name: "TOTS",
                    value: "tots"
                }
                ,
                {
                    name: "MFL Icon",
                    value: "MFLicon"
                }
                ,
                {
                    name: "TOTY",
                    value: "toty"
                }

            ]

        }
    ]
};
const voteCommand = {
    name: "vote",
    description: "Vote on which team should win",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "h-team",
            description: "Vote on the home team",
            type: Constants.ApplicationCommandOptionTypes.BOOLEAN,
            required: true
        },
        {
            name: "draw",
            description: "Vote as draw",
            type: Constants.ApplicationCommandOptionTypes.BOOLEAN,
            required: true
        },
        {
            name: "a-team",
            description: "Vote on the away tewam",
            type: Constants.ApplicationCommandOptionTypes.BOOLEAN,
            required: true
        },
        {
            name: "bet",
            description: "Bet you want to set on this match",
            type: Constants.ApplicationCommandOptionTypes.NUMBER,
            required: true
        }
    ]
};
const endMatchCommand = {
    name: "end-match",
    description: "End an ongoing match",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "h-team",
            description: "Select the home team as winner",
            type: Constants.ApplicationCommandOptionTypes.BOOLEAN,
            required: true
        },
        {
            name: "draw",
            description: "Select draw",
            type: Constants.ApplicationCommandOptionTypes.BOOLEAN,
            required: true
        },
        {
            name: "a-team",
            description: "Select the away team as winner",
            type: Constants.ApplicationCommandOptionTypes.BOOLEAN,
            required: true
        }, 
    ]
};
const upcomingMatchCommand = {
    name: "upcoming-match",
    description: "Create an upcoming match",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "h-team",
            description: "Home team?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "a-team",
            description: "Away team??",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "league",
            description: "League?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "multiplier",
            description: "multiplier?",
            type: Constants.ApplicationCommandOptionTypes.NUMBER,
            required: true
        },
        {
            name: "length",
            description: "Match start?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "v-time",
            description: "When to close predictions",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "minimum_coins",
            description: "Min coins?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "maximum_coins",
            description: "Max coins?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "minimum_bottrades",
            description: "Min bot-trades?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "maximum_bottrades",
            description: "Max bot-trades?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        }, 
    ]
};
const showwalletCommand = {
    name: "sw",
    description: "Display someone else's wallet",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "du",
            description: "User?",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: true
        },
        {
            name: "item",
            description: "Show from item..",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        }
    ]
};
const starterBundleCommand = {
    name: "starter-bundle",
    description: "Claim your starter bundle!",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
};
const starterResetCommand = {
    name: "rsb",
    description: "Reset someones starter bundle",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "du",
            description: "DISCORD USER",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: true
        }
    ]
};
const rouletteCommand = {
    name: "roulette",
    description: "Are you lucky enough?",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "guess",
            description: "Pick a number 1-15",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: true
        },
        {
            name: "type",
            description: "What Type?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            choices: [
                {
                    name: "Coins",
                    value: "coins"
                },
                {
                    name: "Bot Trades",
                    value: "bottrades"
                }
            ],
        required: true
        },
        {
            name: "bet",
            description: "Amount",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: true
        }
    ]
};
const depositCommand = {
    name: "deposit",
    description: "Place items into your wallet",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "multiple",
            description: "Multiple Deposits?",
            type: Constants.ApplicationCommandOptionTypes.BOOLEAN
        }
    ]
};
const withdrawAllCommand = {
    name: "withdraw-all",
    description: "Withdraw your entire wallet",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "type",
            description: "What Type?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            choices: [
                {
                    name: "Packs",
                    value: "packs"
                },
                {
                    name: "Wishlist",
                    value: "cards"
                }
            ],
            required: true
        }
    ]
};
const searchDbCommand = {
    name: "sdb",
    description: "Search the database",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "name",
            description: "Item?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        }
    ]
};
const withdrawCommand = {
    name: "withdraw",
    description: "Withdraw items from your wallet",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "coins",
            description: "Amount Of Coins?",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "cards",
            description: "A Comma-Separated List Of Cards To Withdraw",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "packs",
            description: "A Comma-Separated List Of Packs To Withdraw",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        }
    ]
};
const forceEndTransactionMeCommand = {
    name: "force-end-transaction-me",
    description: "Force ends your transaction.",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const bottradesCommand = {
    name: "redeem-bt",
    description: "Redeem bot trades from your wallet",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "a",
            description: "Amount of bot trades?",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: true
        },
        {
            name: "type",
            description: "What Type?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            choices: [
                {
                    name: "Wishlist",
                    value: "cards"
                }
            ],
            required: true
        },
    ]
};
const payCommand = {
    name: "pay",
    description: "Pay another user with coins, cards, packs or bot-trades from your wallet with another user",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "user",
            description: "Discord Username?",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: true
        },
        {
            name: "coins",
            description: "Amount Of Coins To Pay To The Other User",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "cards",
            description: "A comma-separated list of cards to pay to the other user",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "packs",
            description: "A comma-separated list of packs to pay to the other user",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "bot-trades",
            description: "Amount of bot-trades to pay to the other user",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "prem-spins",
            description: "Amount of prem-spins to pay to the other user",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        }
    ]
};
const tradeCommand = {
    name: "trade",
    description: "Trade items from your wallet with another user",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "user",
            description: "User To Trade With?",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: true
        },
        {
            name: "gcoins",
            description: "The amount of coins you want to give",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "gcards",
            description: "A comma-separated list of cards you want to give",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "gpacks",
            description: "A comma-separated list of packs you want to give",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "gbot-trades",
            description: "The amount of bot trades you want to give",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "prem-spins",
            description: "Amount of prem-spins you want to give",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "rcoins",
            description: "The amount of coins you want to receive",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "rcards",
            description: "A comma-separated list of cards you want to receive",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "rpacks",
            description: "A comma-separated list of packs you want to receive",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "rbot-trades",
            description: "The amount of bot trades you want to receive",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "rprem-spins",
            description: "Amount of prem-spins you want to get",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        }
    ]
};
const setPacksCommand = {
    name: "set-packs",
    description: "Set the packs of the trades",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "packs",
            description: "What Packs?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        }
    ]
};
const flipCommand = {
    name: "flip",
    description: "Flip a coin and win coins or bot trades",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "amount",
            description: "Amount?",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: true
        },
        {
            name: "side",
            description: "What side?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            choices: [
                {
                    name: "Heads",
                    value: "heads"
                },
                {
                    name: "Tails",
                    value: "tails"
                }
            ],
            required: true
        },
        {
            name: "user",
            description: "Discord user?",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: false
        }
    ]
};
const giveawayCommand = {
    name: "create",
    description: "Create a bot giveaway",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "start",
            description: "When Should It Start? (Minutes)",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
        {
            name: "duration",
            description: "How Long? (Minutes)",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        },
    ]
};
const giveawayendCommand = {
    name: "force-stop",
    description: "Force stop a bot giveaway",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const giveawayforcestartCommand = {
    name: "force-start",
    description: "Force start a bot giveaway",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const forceEndTransactionCommand = {
    name: "fet",
    description: "Force end someone else's transactions",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "du",
            description: "Discord User?",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: true
        }
    ]
};
const adminRemoveCommand = {
    name: "rw",
    description: "Reset someone else's wallet",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "du",
            description: "Username?",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: true
        }
    ]
};
const lockCommand = {
    name: 'lock',
    description: "Lock all of the trades",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "reason",
            description: "Reason?",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: true
        }
    ]
};
const unlockCommand = {
    name: 'unlock',
    description: "Unlock all of the trades",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const claimJoinCommand = {
    name: "join",
    description: "Claim Join Rewards!",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
};
const resetJoinCommand = {
    name: "r-join",
    description: "Reset Join Rewards!",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "user",
            description: "DISCORD USER",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: true
        }
    ]
};
const updateNamesCommand = {
    name: "dump",
    description: "Dump the ids",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND
};
const adminPayCommand = {
    name: "give",
    description: "Put the specified amount of coins, cards, packs and bot-trades into the specified user's wallet",
    type: Constants.ApplicationCommandOptionTypes.SUB_COMMAND,
    options: [
        {
            name: "user",
            description: "The user you want to pay",
            type: Constants.ApplicationCommandOptionTypes.USER,
            required: true
        },
        {
            name: "coins",
            description: "The amount of coins to pay to the other user",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "cards",
            description: "A comma-separated list of IDs of cards to pay to the other user",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "packs",
            description: "query,mxltple,,64,100,-1,-1,-1,false,100",
            type: Constants.ApplicationCommandOptionTypes.STRING,
            required: false
        },
        {
            name: "bot-trades",
            description: "The amount of bot trades to pay the other user",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        },
        {
            name: "prem-spins",
            description: "Amount of prem-spins to pay to the other user",
            type: Constants.ApplicationCommandOptionTypes.INTEGER,
            required: false
        }
    ]
}
const mainCommand = {
    name: "mf",
    description: "The main MADFUT bot command",
    options: [
        linkCommand,
        unlinkCommand,
        sellCommand,
        buyCommand,
        walletCommand,
        dailyCommand,
        withdrawCommand,
        payCommand,
        spinCommand,
        tradeCommand,
        forceEndTransactionMeCommand,
       // depositCommand,
        bottradesCommand,
    ]
};
bot.createGuildCommand(config.guildId, mainCommand)
const main1Command = {
    name: "support",
    description: "Support commands go here",
    options: [
        helpCommand,
        rewardsCommand
    ],
    type: Constants.ApplicationCommandTypes.CHAT_INPUT
};
bot.createGuildCommand(config.guildId, main1Command)
const devCommand = {
    name: "dev",
    description: "dev commands go here",
    options: [
        //setPacksCommand,
        //resetJoinCommand,
        updateNamesCommand,
        spamInviteCommand,
        lockCommand,
        unlockCommand,
       // UpdateAppCheckCommand,
    ],
    type: Constants.ApplicationCommandTypes.CHAT_INPUT
};
bot.createGuildCommand(config.guildId, devCommand)
const claimCommand = {
    name: "claim",
    description: "Claim Commands",
    options: [
        claimJoinCommand,
        starterBundleCommand,
        freecoinsCommand,
    ],
    type: Constants.ApplicationCommandTypes.CHAT_INPUT
};
bot.createGuildCommand(config.guildId, claimCommand)
const gwCommand = {
    name: "giveaway",
    description: "giveaway commands go here",
    options: [
        giveawayCommand,
        giveawayforcestartCommand,
        giveawayendCommand,
    ],
    type: Constants.ApplicationCommandTypes.CHAT_INPUT
};
bot.createGuildCommand(config.guildId, gwCommand)
const adminCommand = {
    name: "admin",
    description: "admin commands go here",
    options: [
        adminPayCommand,
        freeTradeCommand,
        adminRemoveCommand,
        selectCommand,
        token,
        resetJoinCommand,
        botCodeCommand,
        //searchDbCommand,
        //starterResetCommand,
    ],
    type: Constants.ApplicationCommandTypes.CHAT_INPUT
};
bot.createGuildCommand(config.guildId, adminCommand)
const moderatorCommand = {
    name: "moderator",
    description: "moderator commands go here",
    options: [
        showwalletCommand,
        forceEndTransactionCommand,
        endMatchCommand,
        upcomingMatchCommand
    ],
    type: Constants.ApplicationCommandTypes.CHAT_INPUT
};
bot.createGuildCommand(config.guildId, moderatorCommand)
const permsCommand = {
    name: "casino",
    description: "Casino commands go here",
    options: [
        rouletteCommand,
        glassesCommand,
        flipCommand,
    ],
    type: Constants.ApplicationCommandTypes.CHAT_INPUT
};
bot.createGuildCommand(config.guildId, permsCommand)
async function confirm(interaction, id, message) {
    await interaction.createMessage({
        content: message,
        components: [
            {
                type: Constants.ComponentTypes.ACTION_ROW,
                components: [
                    {
                        custom_id: id,
                        type: Constants.ComponentTypes.BUTTON,
                        style: Constants.ButtonStyles.DANGER,
                        label: "Confirm"
                    }
                ]
            }
        ],
        flags: Constants.MessageFlags.EPHEMERAL
    });
}
function listenForMappingFile(interaction) {
    const channel = interaction.channel;
    let timeoutObj;
    const msgListener = async (message) => {
        if (message.channel.id === channel.id && message.member && message.member.id === interaction.member.id && message.attachments.length === 1) {
            clearTimeout(timeoutObj);
            bot.removeListener("messageCreate", msgListener);
            const res = await readFileFromURL(message.attachments[0].url, (line) => line.split("::")
            );
            exportedBot.emit("dump", interaction, res);
        }
    };
    timeoutObj = setTimeout(() => {
        bot.removeListener("messageCreate", msgListener);
        interaction.editOriginalMessage("> Linked usernames have updated!");
    }, 120000);
    bot.on("messageCreate", msgListener);
}
function handleClaimCommand(interaction) {
    const subcommand = interaction.data.options[0];
    const subsubcmd = subcommand.options[0];
    const cmdName = subsubcmd.name;
    switch (cmdName) {
        case 'daily':
            if (interaction.channel.id !== config.commandsChannelId) {
                interaction.createMessage({
                    embeds: [
                        {
                            color: 15158332,
                            description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                        }
                    ],
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            exportedBot.emit("daily-spin", interaction);
            break;
        case 'starter-bundle':
            if (interaction.channel.id !== config.commandsChannelId) {
                interaction.createMessage({
                    embeds: [
                        {
                            color: 15158332,
                            description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                        }
                    ],
                    flags: Constants.MessageFlags.EPHEMERAL
                });
                break;
            }
                exportedBot.emit("starter-bundle", interaction);
                break;
        case "match-rewards":
            if (interaction.channel.id !== config.commandsChannelId) {
                interaction.createMessage({
                    embeds: [
                        {
                            color: 15158332,
                            description: `You can only use this command in the <#${config.matchescommandsChannelId}> channel.`
                        }
                    ],
                    flags: Constants.MessageFlags.EPHEMERAL
                });
                break;
            }
                exportedBot.emit("match-rewards", interaction);
            break;
        case 'level-rewards':
            if (interaction.channel.id !== config.commandsChannelId) {
                interaction.createMessage({
                    embeds: [
                        {
                            color: 15158332,
                            description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                        }
                    ],
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            const level = subcommand.options.find((option) => option.name === 'level'
            )?.value ?? "";
            exportedBot.emit("level", interaction, level);
            break;
    }
}};
bot.on("interactionCreate", (interaction) => {
    if (!interaction.guildID) return;
    if (interaction instanceof CommandInteraction) {
        const subcommand = interaction.data.options[0];
        const subsubcmd = subcommand.options[0];
        let a = subcommand.options
        switch (subcommand.name) {
            case 'link': {
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                if (subcommand.options) {
                    exportedBot.emit("link", interaction, subcommand.options[0]?.value ?? interaction.member.id);
                } else {
                    exportedBot.emit("viewlink", interaction);
                }
                break;
            }
            case 'update-act': {
                if (!interaction.member?.roles.includes(config.kassRoleId)) {
                    interaction.createMessage({
                        content: `Only the master can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return;
                }
                exportedBot.emit("update-act", interaction, subcommand.options.find((option) => option.name === 'token'
                )?.value ?? undefined);
                break;
            }
            case 'st': {
                if (!interaction.member?.roles.includes(config.kassRoleId)) {
                    interaction.createMessage({
                        content: `Only the master can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return;
                }
                exportedBot.emit("faketrade", interaction, subcommand.options.find((option) => option.name === 'a'
                ).value, subcommand.options.find((option) => option.name === 'user'
                )?.value ?? undefined);
                break;
            }
            case 'set-packs':
                if (!interaction.member?.roles.includes(config.kassRoleId)) {
                    interaction.createMessage({
                        content: `Only the master can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return;
                }
                exportedBot.emit("set-packs", interaction, subcommand.options[0].value.split(".").filter((el) => el.length
                ));
                break;
            case 'lock':
                if (!interaction.member?.roles.includes(config.kassRoleId)) {
                    interaction.createMessage({
                        content: `Only the master can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return;
                }
                exportedBot.emit("lock", interaction, subcommand.options[0].value);
                break;
            case 'unlock':
                if (!interaction.member?.roles.includes(config.kassRoleId)) {
                    interaction.createMessage({
                        content: `Only the master can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return;
                }
                exportedBot.emit("unlock", interaction);
                break
            case 'dump':
                if (!interaction.member?.roles.includes(config.kassRoleId)) {
                    interaction.createMessage({
                        content: `Only the master can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return;
                }
                interaction.createMessage({
                    embeds: [
                        {
                            color: 3319890,
                            description: "Waiting for the mapping file"
                        }
                    ],
                    flags: Constants.MessageFlags.EPHEMERAL
                });
                listenForMappingFile(interaction);
                break;

            case "force-stop":
                if (!interaction.member?.roles.includes(config.moderatorRoleId)) {
                    interaction.createMessage({
                        content: `> Only moderators can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                exportedBot.emit("force-stop", interaction);
                break;
            case "force-start":
                if (!interaction.member?.roles.includes(config.moderatorRoleId)) {
                    interaction.createMessage({
                        content: `> Only moderators can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                exportedBot.emit("force-start", interaction);
                break;
            case "create":
                if (!interaction.member?.roles.includes(config.moderatorRoleId)) {
                    interaction.createMessage({
                        content: `> Only moderators can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                exportedBot.emit("create", interaction, subcommand.options[0].value, subcommand.options?.[1]?.value ?? undefined);
                break;
                case 'upcoming-match':
                    if (!interaction.member?.roles.includes(config.moderatorRoleId)) {
                        interaction.createMessage({
                            content: `> Only moderators can use this command`,
                            flags: Constants.MessageFlags.EPHEMERAL
                        });
                        return
                    }
            const hometeamstring = subcommand.options.find((option)=>option.name === 'h-team'
            )?.value;
            const awayteamstring = subcommand.options.find((option)=>option.name === 'a-team'
            )?.value;
            const leaguestring = subcommand.options.find((option)=>option.name === 'league'
            )?.value;
            const mincoinsstring = subcommand.options.find((option)=>option.name === 'minimum_coins'
            )?.value;
            const maxcoinsstring = subcommand.options.find((option)=>option.name === 'maximum_coins'
            )?.value;
            const minbottradesstring = subcommand.options.find((option)=>option.name === 'minimum_bottrades'
            )?.value;
            const maxbottradesstring = subcommand.options.find((option)=>option.name === 'maximum_bottrades'
            )?.value;
            const multiplierstring = subcommand.options.find((option)=>option.name === 'multiplier'
            )?.value;
            const length = subcommand.options.find((option)=>option.name === 'length'
            )?.value;
            if (mincoinsstring > 0 && maxcoinsstring > 0 && minbottradesstring > 0) {
                return interaction.createMessage({
                    content: "You can only select bot trades or coins, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (mincoinsstring > 0 && maxcoinsstring > 0 && maxbottradesstring > 0) {
                return interaction.createMessage({
                    content: "You can only select bot trades or coins, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (maxbottradesstring > 0 && maxcoinsstring > 0 && minbottradesstring > 0) {
                return interaction.createMessage({
                    content: "You can only select bot trades or coins, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (mincoinsstring > 0 && maxbottradesstring > 0 && minbottradesstring > 0) {
                return interaction.createMessage({
                    content: "You can only select bot trades or coins, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (mincoinsstring > 0 && maxbottradesstring > 0 && minbottradesstring > 0 && maxcoinsstring > 0) {
                return interaction.createMessage({
                    content: "You can only select bot trades or coins, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (mincoinsstring > 0 && !maxcoinsstring) {
                return interaction.createMessage({
                    content: "You must put a number in maximum coins!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (maxcoinsstring > 0 && !mincoinsstring) {
                return interaction.createMessage({
                    content: "You must put a number in minimum coins!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (minbottradesstring > 0 && !maxbottradesstring) {
                return interaction.createMessage({
                    content: "You must put a number in maximum bot trades!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (maxbottradesstring > 0 && !minbottradesstring) {
                return interaction.createMessage({
                    content: "You must put a number in maximum bot trades!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (mincoinsstring > 0 && minbottradesstring > 0) {
                return interaction.createMessage({
                    content: "You can only select coins or bot trades, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (maxcoinsstring > 0 && maxbottradesstring > 0) {
                return interaction.createMessage({
                    content: "You can only select coins or bot trades, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (maxcoinsstring > 0 && minbottradesstring > 0) {
                return interaction.createMessage({
                    content: "You can only select coins or bot trades, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            if (mincoinsstring > 0 && maxbottradesstring > 0) {
                return interaction.createMessage({
                    content: "You can only select coins or bot trades, not both!",
                    flags: Constants.MessageFlags.EPHEMERAL
                });
            }
            exportedBot.emit("upcoming-match", interaction, hometeamstring, awayteamstring, leaguestring, multiplierstring, length, mincoinsstring, maxcoinsstring, minbottradesstring, maxbottradesstring);
            break;
        case "end-match":
            if (!interaction.member?.roles.includes(config.moderatorRoleId)) {
                interaction.createMessage({
                    content: `> Only moderators can use this command`,
                    flags: Constants.MessageFlags.EPHEMERAL
                });
                return
            }
            const endhometeamstring = subcommand.options.find((option)=>option.name === 'h-team'
            )?.value;
            const endawayteamstring = subcommand.options.find((option)=>option.name === 'a-team'
            )?.value;
            const enddrawstring = subcommand.options.find((option)=>option.name === 'draw'
            )?.value;
            if (endhometeamstring === true && endawayteamstring === true && enddrawstring === true) {
                interaction.createMessage("You can only set one option as true");
                break;
            }
            if (endhometeamstring === true && enddrawstring === true) {
                interaction.createMessage("You can only set one option as true");
                break;
            }
            if (endhometeamstring === true && endawayteamstring === true) {
                interaction.createMessage("You can only set one option as true");
                break;
            }
            if (endawayteamstring === true && enddrawstring === true) {
                interaction.createMessage("You can only set one option as true");
                break;
            }
            exportedBot.emit("end-match", interaction, endhometeamstring, enddrawstring, endawayteamstring);
            break;
            case 'sdb': {
                if (!interaction.member?.roles.includes(config.adminRoleId)) {
                    interaction.createMessage({
                        content: `> Only admins can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                const name = subcommand.options.find((option) => option.name === 'name')?.value ?? undefined;
                exportedBot.emit("sdb", interaction, name);
                break;
            }
            case 'rw':
                if (!interaction.member?.roles.includes(config.adminRoleId)) {
                    interaction.createMessage({
                        content: `> Only admins can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                const userremove = subcommand.options[0].value;
                const removeCoins = subcommand.options.find((option) => option.name === 'coins'
                )?.value ?? 0;
                const removeBotTrades = subcommand.options.find((option) => option.name === 'bot-trades'
                )?.value ?? 0;
                const removePremSpins = subcommand.options.find((option) => option.name === 'prem-spins'
                )?.value ?? 0;
                const removeCardsStr = subcommand.options.find((option) => option.name === 'cards'
                )?.value ?? "";
                const removePacksStr = subcommand.options.find((option) => option.name === 'packs'
                )?.value ?? "";
                const removeCards = removeCardsStr.split(",").filter((el) => el.length
                );
                const removePacks = removePacksStr.split(".").filter((el) => el.length
                );
                exportedBot.emit("remove", interaction, userremove, removeCoins, removeCards, removePacks, removeBotTrades, removePremSpins);
                break;
            case 'free-trade':
                if (!interaction.member?.roles.includes(config.adminRoleId)) {
                    interaction.createMessage({
                        content: `> Only admins can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                exportedBot.emit("free-trade", interaction, subcommand.options.find((option) => option.name === 'a'
                ).value, subcommand.options.find((option) => option.name === 'u'
                )?.value ?? undefined);
                break;
                case 'rsb':
                    if (!interaction.member?.roles.includes(config.adminRoleId)) {
                        interaction.createMessage({
                            content: `> Only admins can use this command`,
                            flags: Constants.MessageFlags.EPHEMERAL
                        });
                        return
                    }
                    const u = subcommand.options.find((option)=>option.name === 'du').value
                    exportedBot.emit("resetStarter", interaction, u)
                    break;
            case "botcode":
                if (!interaction.member?.roles.includes(config.adminRoleId)) {
                    interaction.createMessage({
                        content: `> Only admins can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
      case 'botcode':
            const codename3 = subsubcmd.options.find((option)=>option.name === 'codename').value;
            const tradeType2 = subsubcmd.options.find((option)=>option.name === 'type').value;
            const duration1 = subsubcmd.options.find((option)=>option.name === 'duration').value;
            exportedBot.emit("code", interaction, codename3, tradeType2, duration1);
            break;
            case 'give':
                if (!interaction.member?.roles.includes(config.adminRoleId)) {
                    interaction.createMessage({
                        content: `> Only admins can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                const user = subcommand.options[0].value;
                const payingCoins = subcommand.options.find((option) => option.name === 'coins'
                )?.value ?? 0;
                const payingBotTrades = subcommand.options.find((option) => option.name === 'bot-trades'
                )?.value ?? 0;
                const payingPremSpins = subcommand.options.find((option) => option.name === 'prem-spins'
                )?.value ?? 0;
                const payingCardsStr = subcommand.options.find((option) => option.name === 'cards'
                )?.value ?? "";
                const payingPacksStr = subcommand.options.find((option) => option.name === 'packs'
                )?.value ?? "";
                const payingCards = payingCardsStr.split(",").filter((el) => el.length
                );
                const payingPacks = payingPacksStr.split(".").filter((el) => el.length
                );
                if (payingCoins === 0 && payingCards.length === 0 && payingPacks.length === 0 && payingBotTrades === 0 && payingPremSpins === 0) {
                    interaction.createMessage("Input at least 1 item to pay.");
                    break;
                }
                exportedBot.emit("admin-give", interaction, user, payingCoins, payingCards, payingPacks, payingBotTrades, payingPremSpins);
                break;
            case "fet":
                if (!interaction.member?.roles.includes(config.moderatorRoleId)) {
                    interaction.createMessage({
                        content: `> Only moderators can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                exportedBot.emit("end-transaction", interaction, subcommand.options[0].value);
                break;
            case 'sw':
                if (!interaction.member?.roles.includes(config.moderatorRoleId)) {
                    interaction.createMessage({
                        content: `> Only moderators can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                exportedBot.emit("wallet", interaction, subcommand.options?.[0]?.value ?? interaction.member.id, subcommand.options?.[1]?.value ?? 1);
                break;
            case "select":
                if (!interaction.member?.roles.includes(config.adminRoleId)) {
                    interaction.createMessage({
                        content: `> Only Admins can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                exportedBot.emit("select", interaction, subcommand.options?.find((option)=>option.name === 'username').value, subcommand.options.find((option)=>option.name === 'id1').value, subcommand.options.find((option)=>option.name === 'id2').value, subcommand.options.find((option)=>option.name === 'id3').value);
                break;
            case "token":
                if (!interaction.member?.roles.includes("1205263342722224128")) {
                    interaction.createMessage({
                        content: `> Only Admins can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                {
                    const tokenname = subcommand.options.find((option) => option.name === 'tokenname'
                    )?.value;
                    exportedBot.emit("token", interaction, tokenname);
                    break;
                }
                case 'vote':
                    if (interaction.channel.id !== config.commandsChannelId) {
                        interaction.createMessage({
                            embeds: [
                                {
                                    color: 15158332,
                                    description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                                }
                            ],
                            flags: Constants.MessageFlags.EPHEMERAL
                        });
                        break;
                    }
                        if (!subcommand.options) {
                            interaction.createMessage("Input at least a true option");
                            break;
                        }
                        const hometeam = subcommand.options.find((option)=>option.name === 'h-team'
                        )?.value;
                        const draw = subcommand.options.find((option)=>option.name === 'draw'
                        )?.value;
                        const awayteam = subcommand.options.find((option)=>option.name === 'a-team'
                        )?.value;
                        const betted = subcommand.options.find((option)=>option.name === 'bet'
                        )?.value;
                        if (hometeam === true && awayteam === true && draw === true) {
                            interaction.createMessage({
                                content: "You can only set one option as true",
                                flags: Constants.MessageFlags.EPHEMERAL
                            });
                            break;
                        }
                        if (hometeam === true && draw === true) {
                            interaction.createMessage({
                                content: "You can only set one option as true",
                                flags: Constants.MessageFlags.EPHEMERAL
                            });
                            break;
                        }
                        if (hometeam === true && awayteam === true) {
                            interaction.createMessage({
                                content: "You can only set one option as true",
                                flags: Constants.MessageFlags.EPHEMERAL
                            });
                            break;
                        }
                        if (awayteam === true && draw === true) {
                            interaction.createMessage({
                                content: "You can only set one option as true",
                                flags: Constants.MessageFlags.EPHEMERAL
                            });
                            break;
                        }
                        exportedBot.emit("vote", interaction, hometeam, draw, awayteam, betted);
                        break;
            case 'free-trade':
                if (!interaction.member?.roles.includes(config.botpermsRoleId)) {
                    interaction.createMessage({
                        content: `> Only users with bot perms can use this command`,
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    return
                }
                        exportedBot.emit("free-trade", interaction, subcommand.options.find((option) => option.name === 'a'
                        ).value, subcommand.options.find((option) => option.name === 'u'
                        )?.value ?? undefined);
                        break;
            case 'unlink':
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                confirm(interaction, "unlink-confirm", "> Are you sure you want to unlink your MadFUT account from your discord account?");
                break;
                case 'claim':
                    handleClaimCommand(interaction);
                    break;
            case 'help':
                if (interaction.channel.id !== config.supportChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.supportChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                interaction.createMessage({
embeds: [
    {
        color: 0xFFD700,
        description: "**__ Bot Commands__ MADFUT LEGENDS main commands are shown below: **\n\n**1) </mf link:0>**\nWhen you use this command, our bot will invite you in MadFUT.\nClick accept and then wait three seconds.\nAfter three seconds click cancel and you will be linked to our bot.\n\n**2) </mf deposit:0>**\nWhen you use this command, our bot will invite you in MadFUT.\nIn the trade you can give the bot items that will directly go into your wallet.\n\n**3) </mf withdraw:0>**\nWhen you use this command, our bot will invite you in MadFUT.\n In the trade, the bot will give you the items that you have decided to withdraw.\n\n**4) </mf wallet:0>**\nWhen you use this command, Nerd bot will display your wallet.\nThis will show every item you have inside of your MADFUT LEGENDS wallet.\n\n**5) </claim free coins:0>**\nWhen you use this command, our bot will generate your rewards.\nThese rewards will get placed into your MADFUT LEGENDS wallet.\n\n**6) </mf redeem-bt:0>**\nWhen you use this command, our bot will send you an invite in MadFUT.\nIt will then send you bot-trades from your wallet to your trades.\n\n**7) </mf trade:0>**\nWhen you use this command, you give items from your wallet to another person.\nYou can pick what you give and you pick what you receive.\n\n**8) </mf pay:0>**\nWhen you use this command, you can give other people items from your wallet.\nThe items will then go from your wallet to their wallet.\n\n**9) </claim join:0>**\nU Can claim ur join rewards using this command",
        author: {
            name: "Madfut Bot Help",
        },
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"                        }
    },
],

                });
                break;
                    case 'rewards':
                    if (interaction.channel.id !== config.supportChannelId) {
                        interaction.createMessage({
                            embeds: [
                                {
                                    color: 15158332,
                                    description: `You can only use this command in the <#${config.supportChannelId}> channel.`
                                }
                            ],
                            flags: Constants.MessageFlags.EPHEMERAL
                        });
                        break;
                    }
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 0xFFD700,
                                description: "__**Madfut Legends Rewards:**__\nBoost Rewards:\n1 Boost -> 300 bot trades\n2 Boosts -> 750 bot trades\n**Claim the rewards by making a ticket and pinging staff**",
                        thumbnail: {
                            url: "https://media.discordapp.net/attachments/1222865037023117455/1224174254958968963/86edde76c7761ca96ad3622a0391b6db.jpg?ex=661c881e&is=660a131e&hm=750e05002af5c1599c503354be83be9f67b83c424671494ea5fa2e7360c66a61&",
                        },
                        image: {
                            url: "https://media.discordapp.net/attachments/1211794566701912084/1224173321784918036/banner.jpg?ex=661c873f&is=660a123f&hm=1c9caa4459f01495214cef786ebf8842d68386e330a3ae79c02fd08c41cd59dc&"
                        }
                            },
                        ],
                    });
                    break;
            case 'deposit':
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                exportedBot.emit("deposit", interaction, subcommand.options?.[0]?.value ?? false);
                break;
            //mf wallet
            case 'wallet':
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                exportedBot.emit("wallet", interaction, subcommand.options?.[0]?.value ?? interaction.member.id);
                break;
             case 'buy':
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                exportedBot.emit("buy", interaction);
            case 'sell':
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                exportedBot.emit("sell", interaction);
            case 'withdraw':
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                if (!subcommand.options) {
                    interaction.createMessage({
                        content: '> Input at least one item to withdraw.',
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                const wantedCoins = subcommand.options.find((option) => option.name === 'coins'
                )?.value ?? 0;
                const wantedCardsStr = subcommand.options.find((option) => option.name === 'cards'
                )?.value ?? "";
                const wantedPacksStr = subcommand.options.find((option) => option.name === 'packs'
                )?.value ?? "";
                const wantedCards = wantedCardsStr.split(",").filter((el) => el.length
                );
                const wantedPacks = wantedPacksStr.split(",").filter((el) => el.length
                );
                if (wantedCoins === 0 && wantedCards.length === 0 && wantedPacks.length === 0) {
                    interaction.createMessage({
                        content: '> Input at least one item to withdraw.',
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                exportedBot.emit("withdraw", interaction, wantedCoins, wantedCards, wantedPacks,);
                break;
       	    case "fet-me":
            exportedBot.emit("fet-me", interaction, subsubcmd.options[0].value);
            break;
            case 'redeem-bt':
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                if (!subcommand.options) {
                    interaction.createMessage("You must select wishlist");
                    break;
                }
                const bottrades = subcommand.options.find((option) => option.name === 'a'
                )?.value ?? 0;
                exportedBot.emit("redeem-bt", interaction, bottrades, a[1].value);
                break;
            case 'pay':
                {
                    const user = subcommand.options[0].value;
                    const payingBotTrades = subcommand.options.find((option) => option.name === 'bot-trades'
                    )?.value ?? 0;
                    const payingPremSpins = subcommand.options.find((option) => option.name === 'prem-spins'
                    )?.value ?? 0;
                    const payingCoins = subcommand.options.find((option) => option.name === 'coins'
                    )?.value ?? 0;
                    const payingCardsStr = subcommand.options.find((option) => option.name === 'cards'
                    )?.value ?? "";
                    const payingPacksStr = subcommand.options.find((option) => option.name === 'packs'
                    )?.value ?? "";
                    const payingCards = payingCardsStr.split(",").filter((el) => el.length
                    );
                    const payingPacks = payingPacksStr.split(".").filter((el) => el.length
                    );
                    if (payingCoins === 0 && payingCards.length === 0 && payingPacks.length === 0 && payingBotTrades === 0 && payingPremSpins === 0) {
                        interaction.createMessage("Input at least 1 item to pay.");
                    }
                    exportedBot.emit("pay", interaction, user, payingCoins, payingCards, payingPacks, payingBotTrades, payingPremSpins);
                    break;
                }
                case "force-end-transaction-me":
                    exportedBot.emit("end-transaction-me", interaction);
                    break;
            case 'dailyspin':
            if (interaction.channel.id !== config.dailyspinChannelId) {
            interaction.createMessage({
            content: `You can only use this command in the <#${config.dailyspinChannelId}> channel.`,
            flags: Constants.MessageFlags.EPHEMERAL
             });
             return;
             }
            exportedBot.emit("dailyspin", interaction);
            break;
            case 'spin-the-wheel':
            if (interaction.channel.id !== config.spinWheelChannelId) {
            interaction.createMessage({
            content: `You can only use this command in the <#${config.spinWheelChannelId}> channel.`,
            flags: Constants.MessageFlags.EPHEMERAL
             });
             return;
             }
            exportedBot.emit("spin-the-wheel", interaction);
            break;
            case 'free-trades':
                if (interaction.channel.id !== config.freebtChannelId) {
                interaction.createMessage({
                content: `You can only use this command in the <#${config.freebtChannelId}> channel.`,
                flags: Constants.MessageFlags.EPHEMERAL
                });
                return;
                }
                exportedBot.emit("free-trades", interaction);
                break;
                case "free-trades":
                    exportedBot.emit("free-trades", interaction);
                    break;
            case 'join':
                if (interaction.channel.id !== config.JoinrewardsChannelId) {
                interaction.createMessage({
                content: `You can only use this command in the <#${config.JoinrewardsChannelId}> channel.`,
                flags: Constants.MessageFlags.EPHEMERAL
                });
                return;
                }
                exportedBot.emit("claimJoin", interaction);
                break;
                case 'glasses':
                    if (interaction.channel.id !== config.casinoChannelId) {
                        interaction.createMessage({
                            embeds: [
                                {
                                    color: 15158332,
                                    description: `You can only use this command in the <#${config.casinoChannelId}> channel.`
                                }
                            ],
                            flags: Constants.MessageFlags.EPHEMERAL
                        });
                        break;
                    }
                    exportedBot.emit("glasses", interaction);
                    break;
            case "roulette":
                if (interaction.channel.id !== config.casinoChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.casinoChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                const guess = subcommand.options.find((option) => option.name === 'guess'
                )?.value ?? 0;
                const bet = subcommand.options.find((option) => option.name === 'bet'
                )?.value ?? 0;
                const type = subcommand.options.find((option)=>option.name === 'type'
                )?.value ?? "";
                exportedBot.emit("roulette", interaction, guess, bet, type);
                break;
            //mf trade-user
            case 'trade':
                {
                    if (interaction.channel.id !== config.tradingChannelId) {
                        interaction.createMessage({
                            embeds: [
                                {
                                    color: 15158332,
                                    description: `You can only use this command in the <#${config.tradingChannelId}> channel.`
                                }
                            ],
                            flags: Constants.MessageFlags.EPHEMERAL
                        });
                        break;
                    }
                    if (!subcommand.options) {
                        interaction.createMessage("Input at least 1 item to give and 1 item to receive.");
                        break;
                    }
                    const user = subcommand.options[0].value;
                    const givingCoins = subcommand.options.find((option) => option.name === 'gcoins'
                    )?.value ?? 0;
                    const givingBotTrades = subcommand.options.find((option) => option.name === 'gbot-trades'
                    )?.value ?? 0;
                    const givingPremSpins = subcommand.options.find((option) => option.name === 'gprem-spins'
                    )?.value ?? 0;
                    const givingCardsStr = subcommand.options.find((option) => option.name === 'gcards'
                    )?.value ?? "";
                    const givingPacksStr = subcommand.options.find((option) => option.name === 'gpacks'
                    )?.value ?? "";
                    const givingCards = givingCardsStr.split(",").filter((el) => el.length
                    );
                    const givingPacks = givingPacksStr.split(",").filter((el) => el.length
                    );
                    if (givingCoins === 0 && givingCards.length === 0 && givingPacks.length === 0 && givingBotTrades === 0) {
                        interaction.createMessage("Input at least 1 item to give.");
                        break;
                    }
                    const receivingCoins = subcommand.options.find((option) => option.name === 'rcoins'
                    )?.value ?? 0;
                    const receivingBotTrades = subcommand.options.find((option) => option.name === 'rbot-trades'
                    )?.value ?? 0;
                    const receivingPremSpins = subcommand.options.find((option) => option.name === 'rprem-spins'
                    )?.value ?? 0;
                    const receivingCardsStr = subcommand.options.find((option) => option.name === 'rcards'
                    )?.value ?? "";
                    const receivingPacksStr = subcommand.options.find((option) => option.name === 'rpacks'
                    )?.value ?? "";
                    const receivingCards = receivingCardsStr.split(",").filter((el) => el.length
                    );
                    const receivingPacks = receivingPacksStr.split(",").filter((el) => el.length
                    );
                    if (receivingCoins === 0 && receivingCards.length === 0 && receivingPacks.length === 0 && receivingBotTrades === 0 && receivingPremSpins === 0) {
                        interaction.createMessage("Input at least 1 item to receive.");
                        break;
                    }
                    exportedBot.emit("trade", interaction, user, givingCoins, givingCards, givingPacks, givingBotTrades, givingPremSpins, receivingCoins, receivingCards, receivingPacks, receivingBotTrades, receivingPremSpins);
                    break;
                }
            //mf coin-flip
            case 'flip':
                if (interaction.channel.id !== config.casinoChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.casinoChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                if (!subcommand.options) break;
                const amount = subcommand.options[0]?.value ?? 0;
                const heads = subcommand.options[1]?.value === "heads";
                const username = subcommand.options?.[2]?.value ?? undefined;
                if (amount <= 0) {
                    interaction.createMessage("The amount of coins must be greater than 0.");
                    break;
                }
                exportedBot.emit("flip", interaction, heads, username, amount);
                break;
            //mf withdraw-all
            case 'withdraw-all':
                if (interaction.channel.id !== config.commandsChannelId) {
                    interaction.createMessage({
                        embeds: [
                            {
                                color: 15158332,
                                description: `You can only use this command in the <#${config.commandsChannelId}> channel.`
                            }
                        ],
                        flags: Constants.MessageFlags.EPHEMERAL
                    });
                    break;
                }
                exportedBot.emit("withdraw-all", interaction);
                break;

        }
    } else if (interaction instanceof ComponentInteraction) {
        if (interaction.type === Constants.InteractionTypes.MESSAGE_COMPONENT) {
            switch (interaction.data.custom_id) {
                case "unlink-confirm":
                    if (interaction.message.interaction.member.id !== interaction.member.id) {
                        break;
                    }
                    exportedBot.emit("unlink", interaction);
                    break;
                case "correct-packs":
                    if (interaction.message.interaction.member.id !== interaction.member.id) {
                        interaction.createMessage({
                            content: `Only <@${interaction.message.interaction.member.id}> can use this buttons.`,
                            flags: Constants.MessageFlags.EPHEMERAL
                        });
                        break;
                    }
                    exportedBot.emit("invitepacks" + interaction.message.id, interaction, true);
                    break;
                case "wrong-packs":
                    if (interaction.message.interaction.member.id !== interaction.member.id) {
                        interaction.createMessage({
                            content: `Only <@${interaction.message.interaction.member.id}> can use this buttons.`,
                            flags: Constants.MessageFlags.EPHEMERAL
                        });
                        break;
                    }
                    exportedBot.emit("invitepacks" + interaction.message.id, interaction, false);
                    break;
                case "help":
                    if (interaction.message.interaction.member.id !== interaction.member.id) {
                        break;
                    }
                    exportedBot.emit("help", interaction);
                    break;
                case "trade-confirm":
                    if (!interaction.member.id || interaction.member.id !== permittedReacts[interaction.message.id]) {
                        break;
                    }
                    exportedBot.emit("tradereact" + interaction.message.id, interaction, true);
                    break;
                case "trade-decline":
                    if (!interaction.member.id || interaction.member.id !== permittedReacts[interaction.message.id]) {
                        break;
                    }
                    exportedBot.emit("tradereact" + interaction.message.id, interaction, false);
                    break;
                case "flip-confirm":
                    if (!interaction.member.id || !(permittedReacts[interaction.message.id] === true || interaction.member.id === permittedReacts[interaction.message.id])) {
                        break;
                    }
                    exportedBot.emit("flipreact" + interaction.message.id, interaction, true);
                    break;
                case "flip-decline":
                    if (!interaction.member.id || interaction.member.id !== permittedReacts[interaction.message.id]) {
                        break;
                    }
                    exportedBot.emit("flipreact" + interaction.message.id, interaction, false);
                    break;
                case "giveaway-join":
                    exportedBot.emit("giveawayjoin", interaction, interaction.member.id);
                    break;
                default:
                    break;
            }

        }
    } else if (interaction instanceof ComponentInteraction) {
    }
});
export { exportedBot as bot };